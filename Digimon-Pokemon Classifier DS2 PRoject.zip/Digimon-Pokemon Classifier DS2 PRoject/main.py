# Mohamed Adel Mohamed Taha\n
import os

import cv
import numpy
import numpy as np
import cv2 as ocv
import random
from sklearn.model_selection import train_test_split
import tensorflow as tf
import matplotlib as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Input
from IPython.display import Image, display


import warnings
warnings.filterwarnings("ignore")


class BinaryClassifier:
    def __init__(self, directory, classNamesArray, imagesPerClass):
        #initialize variables
        self.dir = directory #Initialize working directory
        self.classes = classNamesArray #Load array of class names
        self.imagesPerClass = imagesPerClass #Initialize how many images from each class should be used. Since the class with the least availability has 721 images, I used 700 of each.

        # Reading data
        data = []
        labels = []
        downscaledImgWidth = 299#These values define what size the dataset images should all be scaled to
        downscaledImgHeight = 299
        classCounter = 1
        for category in os.listdir(directory):#For each folder in the directory...
            if classCounter == 1:
                print("Loading...", end=" ")
            newDirectory = os.path.join(directory, category)#Create a new directory for that folder...
            for img in os.listdir(newDirectory):#Then for every image in that new directory...
                if len(data) < (imagesPerClass * classCounter):#If we haven't maxed how many images per class we've allowed...
                    imgPath = os.path.join(newDirectory, img)#Get a directory reference for the current image...
                    if (np.all(np.array(ocv.imread(imgPath, 0))) == 0):#And add it to the data, along with it's label.
                        data.append(ocv.resize(ocv.imread(imgPath, 0), (downscaledImgWidth, downscaledImgHeight)))
                        labels.append(classes.index(category))
                        if len(data) / (imagesPerClass * 2) * 100 % 20 == 0:
                            print(int(len(data) / (imagesPerClass * 2) * 100), "%", end="  ")
            classCounter = classCounter + 1
            if classCounter == 3:#Only use 2 classes, don't look for a 3rd class.
                print(". Complete.", end=" ")
        combined = list(zip(data, labels))#Combine data-label pairs of all classes
        random.shuffle(combined)#Randomize the order of the data-label pairs so data splitting is random
        data, labels = zip(*combined)
        Data = np.array(data) / 255
        Labels = np.array(labels)

        self.x_train, self.x_test, self.y_train, self.y_test = train_test_split(Data, Labels, train_size=.7)#Training data is 70% of the data per the assignment

        tf.random.set_seed(42)#42 seems to be a common seed.

        self.model = Sequential(#Model architecture
            [tf.keras.layers.Flatten(input_shape=(299, 299)),
             Dense(128, activation='relu', name='L1'),
             Dense(56, activation='relu', name='L2'),
             Dense(24, activation='relu', name='L3'),
             Dense(7, activation='relu', name='L4'),
             Dense(2, name='L5')
             ], name="Binary-Classification-Model")
        self.model.compile(
            loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),#Compute the loss of the model
            optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),#Set optimizer
            metrics=[tf.keras.metrics.SparseCategoricalAccuracy()]#Set model evaluation metrics
        )

        history = self.model.fit(#Train the model
            self.x_train, self.y_train,
            epochs=1)#It seems to be well trained after ~10 epochs, but I kept going until 50.
        print("Finished training")

        #self.model.summary()

    def score(self):
        print("Model scores on test data: ", end=" ")
        test_loss, test_acc = self.model.evaluate(self.x_test, self.y_test, verbose=2)

    def predict(self, x_val):
        probability_model = tf.keras.Sequential([self.model,tf.keras.layers.Softmax()])

        self.prediction = classes[np.argmax(probability_model.predict(self.x_test[x_val - 1:x_val:, :, :]))]
        print("Prediction for photo #", x_val, ": ", self.prediction, end=" ")




dir = './dataset/images'
classes = ['pokemon', 'digimon']
imagesPerClass = 700

model = BinaryClassifier(dir, classes, imagesPerClass)
model.score()
#model.predict(4)

pokemon = ['./dataset/images/pokemon/702.png', './dataset/images/pokemon/703.png', './dataset/images/pokemon/704.png', './dataset/images/pokemon/705.png']
digimon = ['./dataset/images/digimon/50px-Yggdrasill_core.jpg', './dataset/images/digimon/52px-Eater_Adam.jpg',
           './dataset/images/digimon/53px-Eater_Humanoid_Mode.jpg', './dataset/images/digimon/60px-BishopChessmon_Black.png']

model_builder = tf.keras.applications.xception.Xception
img_size = (299, 299)
preprocess_input = tf.keras.applications.xception.preprocess_input
decode_predictions = tf.keras.applications.xception.decode_predictions

last_conv_layer_name = "L5"

# The local path to our target image
img_path = "./dataset/images/pokemon/702.png"

display(Image(img_path))


def get_img_array(img_path, size):
    # `img` is a PIL image of size 299x299
    img = tf.keras.preprocessing.image.load_img(img_path, target_size=size)
    # `array` is a float32 Numpy array of shape (299, 299, 3)
    array = tf.keras.preprocessing.image.img_to_array(img)
    # We add a dimension to transform our array into a "batch"
    # of size (1, 299, 299, 3)
    array = np.expand_dims(array, axis=0)
    return array


def make_gradcam_heatmap(img_array, model, last_conv_layer_name, pred_index=None):
    # First, we create a model that maps the input image to the activations
    # of the last conv layer as well as the output predictions
    grad_model = tf.keras.models.Model(
        [model.inputs], [model.get_layer(last_conv_layer_name).output, model.output]
    )

    # Then, we compute the gradient of the top predicted class for our input image
    # with respect to the activations of the last conv layer
    with tf.GradientTape() as tape:
        last_conv_layer_output, preds = grad_model(img_array)
        if pred_index is None:
            pred_index = tf.argmax(preds[0])
        class_channel = preds[:, pred_index]

    # This is the gradient of the output neuron (top predicted or chosen)
    # with regard to the output feature map of the last conv layer
    grads = tape.gradient(class_channel, last_conv_layer_output)

    # This is a vector where each entry is the mean intensity of the gradient
    # over a specific feature map channel
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))

    # We multiply each channel in the feature map array
    # by "how important this channel is" with regard to the top predicted class
    # then sum all the channels to obtain the heatmap class activation
    last_conv_layer_output = last_conv_layer_output[0]
    heatmap = last_conv_layer_output @ pooled_grads[..., tf.newaxis]
    heatmap = tf.squeeze(heatmap)

    # For visualization purpose, we will also normalize the heatmap between 0 & 1
    heatmap = tf.maximum(heatmap, 0) / tf.math.reduce_max(heatmap)
    return heatmap.numpy()


# Prepare image
img_array = preprocess_input(get_img_array(img_path, size=img_size))

# Remove last layer's softmax
model.model.layers[-1].activation = None

#img_array = numpy.resize(img_array,(299,299))
#img_array = numpy.reshape(img_array,(299,299))



# Print what the top predicted class is
preds = model.model.predict(img_array)
print("Predicted:", decode_predictions(preds, top=1)[0])

# Generate class activation heatmap
heatmap = make_gradcam_heatmap(img_array, model.model, last_conv_layer_name)

# Display heatmap
plt.matshow(heatmap)
plt.show()


