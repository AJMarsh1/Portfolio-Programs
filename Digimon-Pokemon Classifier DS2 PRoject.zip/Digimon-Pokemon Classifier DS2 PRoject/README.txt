!!PLEASE NOTE THAT TO GET THIS TO FIT ON GITHUB I HAD TO DELETE MOST OF THE DATA SAMPLES, SO IF YOU
WISH TO TEST THE MODEL YOU WILL NEED TO ADJUST FROM USING 700 OF EACH CLASS TO 100!!

This project was the final project for my data science 2 course. It trains on labeled images of
pokemon and digimon, and then predicts whether new images are pokemon or digimon.

I am pretty proud of this project, it is just a basic image classifier but I built it while under
a lot of stress with other classes and finals hitting at the same time, while it was supposed to
be a three person project I was the only one in my group who had not dropped the class or ghosted.

If I were to redo this project, I would leave the core components the same, but would try to optimize
the results with calibrations in the number of layers and size of each layer. I would also try to
get the GraphCAM evaluation model to work, as I had issues trying to attach it to the final layers
of the prediction model without matrix dimension mismatches.