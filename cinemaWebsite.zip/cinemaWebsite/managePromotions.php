<?php 
    require('database.php');
    session_start();
    date_default_timezone_set('America/New_York');
    $query = "SELECT code, percentOff, expiration, active FROM promotions";
    $promotions = $db->query($query);
    
    $currentDate = date('Y-m-d');
?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>TT Manage Promotions</title> <!-- decide on name -->
  <!-- <link rel="stylesheet" href="adminStyles.css"> -->
  <link rel="preconnect" href="https://fonts.googleapis.com"> 
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
  <!-- <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,700;1,600&display=swap" rel="stylesheet"> -->

</head>
<body>

  <div class="navBar">
  <div class="leftSideNav">
    <a class="home" href="homepage.php">
      <h1>Turbo <br> Theatres</h1>
    </a>
    <a href="adminHome.php" class="navBookMovie">Admin view</a>
  </div>
  
  <div class="rightSideNav">
      <a href="signout.php" class="logoutButton">Log Out  |</a>
      <a href="editProfilePage.php" class="logoutButton">View Profile</a>
    </div>
  </div>



  <div class="adminBody">

    <h3>Manage Promotions</h3>

      <div class="adminTools">


        <h3>Add Promotion</h3>

        <form class="manageForms" action = "addPromotion.php" method="post">

          <div class="fields">

            <label for="fname">Percent Off:</label>
            <input type="text" id="newPromoPercent" name="newPromoPercent">
            <label for="fname"> Promo Code:</label>
            <input type="text" id="newPromoCode" name="newPromoCode">
            <label for="fname"> Expiration Date:</label>
            <input type="date" id="newExpDate" name="newExpDate"> 
          </div>

          <input type="submit" name="save" value="Submit">
          
        </form>

      </div>
    </div>


    <h3>Active Promotions</h3>

    <div class="promoTable">
      
      <table>

        <tr>
          <th>% Off Value</th>
          <th>Offer Code</th>
          <th>Expiration Date</th>
          <th>Sent Status</th>
          <th>Send Promo</th>
        </tr>
        
        <?php 
        foreach($promotions as $promotion) : ?>
            <tr>
            <?php if ($promotion['expiration'] >= $currentDate) :?>
            	<td><?php echo($promotion['percentOff'])?></td>
          		<td><?php echo($promotion['code'])?></td>
          		<td><?php echo($promotion['expiration'])?></td>
          		<td><?php echo($promotion['active'])?></td>
          		<?php if ($promotion['active'] == 0) :?>
          		<td>
          			<a href = "emailPromotion.php?code=<?php echo $promotion['code']; ?>"> <!-- Could also add expiration date to email -->
                		<button id="send" name="send">Send</button>
              		</a>
    			</td>
    			<?php else :?>
    			<td>Sent</td>
    			<?php endif;?>
          	<?php endif; ?>
            </tr>
        <?php endforeach;?>
      
      </table>

    </div>

    <h3>Inactive Promotions</h3>

    <div class="promoTable">

      <table>
        
        <tr>
          <th>% Off Value</th>
          <th>Offer Code</th>
          <th>Expiration Date</th>
          <th>Sent Status</th>
          <th>Delete Promo</th>
        </tr>
        <?php 
        foreach($promotions as $promotion) : ?>
            <tr>
            <?php if ($promotion['expiration'] < $currentDate) :?>
            	<td><?php echo($promotion['percentOff'])?></td>
          		<td><?php echo($promotion['code'])?></td>
          		<td><?php echo($promotion['expiration'])?></td>
          		<td><?php echo($promotion['active'])?></td>
          		<td>
          			<a href = "removePromotion.php?code=<?php echo $promotion['code']; ?>">
                		<button id="delete" name="delete">Delete</button>
              		</a>
    			</td>
          		<!-- Add another column for if the promotion is sent and display button if it is not sent  -->
          		<!-- Also consider displaying expiration date -->
          	<?php endif; ?>
            </tr>
        <?php endforeach;?>
        
      </table>

    </div>


</body>

<style>

  * {
      margin: 0;
      padding: 0;
    }


    body {
      background-color: black;
      font-family: "Montserrat", sans-serif;
      color: white;
      margin-bottom: 50px;
    }


    h1 {
      /*used on homepage*/
      font-style: italic;
    }

    h3 {
      /*used on homepage & reg confirmation page*/
      font-size: 30px;
      text-align: center;
      margin-top: 30px;
    }

    .home {
      color: white;
      text-decoration: none;
    }

    .home:visited {
      color: white;
    }

  .navBar {
      display: inline-flex;
      flex-direction: row;
      width: 100%;
      justify-content: space-between;
      background: #040194;
      color: white;
      align-items: center;
      padding-bottom: 5px;
    }

    .leftSideNav {
      padding-left: 90px;
      display: inline-flex;
      flex-direction: row;
      align-items: center;
    }

    .rightSideNav {
      padding-right: 20px;
      display: inline-flex;
      flex-direction: row;
      align-items: center;
      gap: 10px;
    }

    .navBookMovie {
      text-decoration: none;
      color: white;
      margin-left: 50px;
    }


  .logoutButton {
    float: right;
    text-decoration: none;
    color: white;

  }

  .logoutButton:visited {
    color: white;
    text-decoration: none;
  }



  .adminTools {
    display: grid;

    justify-content: center;
    /*margin-bottom: 20px;*/
  }

  .manageForms {
    display: inline-flex;
    flex-direction: column;
    padding: 10px 70px 10px 70px;
  }

  .fields {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    margin-bottom: 20px;

  }

  input {
      font-size: 15px;
    }

    input[type=submit] {
      font-size: 20px;
      font-family: "Montserrat", sans-serif;
      width: 100px;
    }

  .promoTable {
    display: inline-flex;
    flex-direction: column;
    width: 100%;
    align-items: center;
    margin-top: 10px;
  }

  th, td {
    text-align: center;
    border-bottom: 1px solid;
    padding: 10px;
  }
  

</style>
</html>











