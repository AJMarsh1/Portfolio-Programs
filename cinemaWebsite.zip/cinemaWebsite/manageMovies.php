<?php
require('database.php');
session_start();
$query = "SELECT showingID, movieID, showDate, showroomID FROM showings";
$showings = $db->query($query);         
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>TT Manage Movies</title> <!-- decide on name -->
  <!-- <link rel="stylesheet" href="adminStyles.css"> -->
  <link rel="preconnect" href="https://fonts.googleapis.com"> 
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">

</head>
<body>

  <!-- Navbar (sit on top) -->
<div class="navBar">
  <div class="leftSideNav">
    <a class="home" href="homepage.php">
      <h1>Turbo <br> Theatres</h1>
    </a>
    <a href="adminHome.php" class="navBookMovie">Admin View</a>
  </div>
  
  <div class="rightSideNav">
      <a href="signout.php" class="logoutButton">Log Out  |</a>
      <a href="editProfilePage.php" class="logoutButton">View Profile</a>
    </div>
  </div>


  <div class="adminBody">

    <h3>Manage Movies</h3>
    <?php
      if(isset($_SESSION["message"])){
        $message = $_SESSION["message"];
        echo "<span>$message</span>";
      }
    ?>
      <div class="adminTools">

        
        <h3>Add Movie</h3>

        <h3>Remove Movie</h3>

        <form class="manageForms" action="addMovie.php" method = "POST">

          <div class="fields">

            <label for="newMovieForm">Title:</label>
            <input type="text" id="movieTitle" name="title" required>
            <label for="newMovieForm">Trailer Link:</label>
            <input type="text" id="trailerLink" name="trailerLink" required>
            <label for="newMovieForm">Description:</label>
            <input type="text" id="description" name="description" required>
            <label for="newMovieForm">Director:</label>
            <input type="text" id="director" name="director" required>
            <label for="newMovieForm">Genre:</label>
            <input type="text" id="genre" name="genre" required>
            <label for="newMovieForm">Cast:</label>
            <input type="text" id="cast" name="cast" required>
            <label for="newMovieForm">Producer:</label>
            <input type="text" id="producer" name="producer" required>
            <label for="newMovieForm">Review:</label>
            <input type="text" id="review" name="review" required>
            <label for="newMovieForm">Rating:</label>
            <input type="text" id="rating" name="rating" required>
            <label for="newMovieForm">Image Path:</label>
            <input type="text" id="image" name="image" required>
            <label for="addShowingForm">Runtime(min):</label>
            <input type="number" id="movieRuntime" name="runtime" required>
            <label for="addShowingForm">Date:</label>
            <input type="date" id="date" name="date" required>

          </div>

          <input type="submit" name="addMovie" value="Submit">
          
        </form>


        <form class="manageForms" action="deletMovie.php" method= "POST">

          <div class="fields">
            <label for="removeMovieForm">Title:</label>
            <input type="text" id="title" name="title" required>
          </div>
          <input type="submit" name= "deleteMovie" value="Submit">
        </form>

        <h3>Add Showing</h3>
        <h3>Remove Showing</h3>


        <form class="manageForms" action="addShowing.php" method= "POST">

          <div class="fields">

            <label for="addShowingForm">Title:</label>
            <input type="text" id="movieTitle" name="movieTitle" required>
            <label for="addShowingForm">Time:</label>
            <input type="datetime-local" name="date" required>
            <label for="addShowingForm">Show Room:</label>
            <input type="number" name="room" required>
            

          </div>

          <input type="submit" name = "addShowing" value="Submit">
          
        </form>




          <!-- <div class="field"> -->
          <table class="showingRemove">
            <tr>
              <th>Showing ID</th>
              <th>Movie</th>
              <th>Show Date</th>
              <th>Show Room</th>
              <?php 
              foreach($showings as $showing) : ?>
                <tr>
                  <td><?php echo($showing['showingID'])?></td>
                  <?php
                    $movieID = $showing['movieID'];
                    $userCheck = $db->prepare("SELECT title FROM movies WHERE movieID = '$movieID'");
                    $userCheck->execute();
                    $result = $userCheck->get_result();
					          while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
						          foreach ($row as $r) {
						          $title = $r;
						          }
					          }
                  ?>
                  <td><?php echo($title)?></td>
                  <td><?php echo($showing['showDate'])?></td>
                  <td><?php echo($showing['showroomID'])?></td>
                  <td>
                    <a href = "deleteShowing.php?delete=<?php echo $showing['showingID']; ?>">
                        <button id="delete" name="delete">Delete</button>
                    </a>
    			        </td>
                </tr>
              <?php endforeach;?>
            </tr>
          </table>
          <!-- </div> -->
          



    </div>
    

  </div>




  
</div>


</body>
<?php
  unset($_SESSION["message"]);
?>

<style>
  
  * {
      margin: 0;
      padding: 0;
    }


    body {
      background-color: black;
      font-family: "Montserrat", sans-serif;
      color: white;
      padding-bottom: 50px;
    }


    h1 {
      /*used on homepage*/
      font-style: italic;
    }

    .home {
      color: white;
      text-decoration: none;
    }

    .home:visited {
      color: white;
    }

    h3 {
      /*used on homepage & reg confirmation page*/
      font-size: 30px;
      text-align: center;
      margin-top: 30px;
    }

    h5 {
      margin-top: 30px;
    }

  .navBar {
      display: inline-flex;
      flex-direction: row;
      width: 100%;
      justify-content: space-between;
      background: #040194;
      color: white;
      align-items: center;
      padding-bottom: 5px;
    }

    .leftSideNav {
      padding-left: 90px;
      display: inline-flex;
      flex-direction: row;
      align-items: center;
    }

    .rightSideNav {
      padding-right: 20px;
      display: inline-flex;
      flex-direction: row;
      align-items: center;
      gap: 10px;
    }

    .navBookMovie {
      text-decoration: none;
      color: white;
      margin-left: 50px;
    }


  .logoutButton {
    float: right;
    text-decoration: none;
    color: white;

  }

  .logoutButton:visited {
    color: white;
    text-decoration: none;
  }

  .adminTools {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    margin-bottom: 50px;
  }

  .manageForms {
    display: inline-flex;
    flex-direction: column;
    padding: 10px 70px 30px 70px;
  }

  .fields {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    margin-bottom: 20px;

  }

  input {
      font-size: 15px;
    }

    input[type=submit] {
      font-size: 20px;
      font-family: "Montserrat", sans-serif;
      width: 100px;
    }

    #delete {
      font-size: 20px;
      font-family: "Montserrat", sans-serif;
      width: 100px;
    }

    .showingRemove {
      padding-left: 30px;
      /*width: 100%;*/
      margin-left: 30px;
      margin-right: 50px;
      text-align: center;
    }





    .nowShowing {
    margin-top: 40px;
  }



  .allMovies {
    display: inline-flex;
    flex-direction: column;
    /*gap: 40px;*/
    width: 100%;
  }

  .homeMovieImg {
    width: 155px;
    height: auto;
  }

  .movieRow {
    display: inline-flex;
    flex-direction: row;
    width: 100%;
    justify-content: space-evenly;   
    /*gap: 30px;*/
    margin-top: 20px;
    margin-bottom: 20px;
  }

  .movie {
    display: inline-flex;
    flex-direction: row;
    gap: 30px;


  }

  .details {
    display: inline-flex;
    flex-direction: column;
  }

  .times {
    display: inline-flex;
    flex-direction: column;
    /*gap: 30px;*/
  }


  .comingSoon {
    display: inline-flex;
    flex-direction: column;
    width: 100%;
    margin-top: 20px;
  }


</style>


</html>










