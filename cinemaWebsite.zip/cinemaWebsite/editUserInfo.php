<?php
require('database.php');
session_start();    

$userID = $_POST['userID'];

if (isset($userID)) {
    $message = "";
    $numCards = 0;
    
    $userCheck = $db->prepare("SELECT subscribed FROM users WHERE userID = '$userID'");
    $userCheck->execute();
    $result = $userCheck->get_result();
    while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
        foreach ($row as $r) {
            $promotions = $r;
        }
    }
    
    if(isset($_POST['promoSubmit'])){
        if(isset($_POST['promotions'])){
            $promotions = 1;
            $message = "Promotions enabled.";
            //header("location: editUser.php?" . $userID);
        }else{
            $promotions = 0;
            $message = "Promotions disabled.";
            //header("location: editUser.php?" . $userID);
        }
        $statement = $db->prepare("UPDATE users SET subscribed=? WHERE userID=?");
        $statement->bind_param("si",$promotions,$userID);
        $statement->execute();
    }
    
    if(isset($_POST['passwordSubmit'])){
        $oldPassword = htmlspecialchars($_POST['oldPassword']);
        $newPassword = htmlspecialchars($_POST['newPassword']);
        $validInput = true;
        if(empty($newPassword)){
            $message.= 'New password is required. Please try again. ';
            $validInput = false;
        }
        if(empty($oldPassword)){
            $message.= 'Current password is required. Please try again. ';
            $validInput = false;
        }
        
        if($validInput){
            $userCheck = $db->prepare("SELECT password FROM users WHERE userID = '$userID'");
            $userCheck->execute();
            $result = $userCheck->get_result();
            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                foreach ($row as $r) {
                    $pw = $r;
                }
            }
            $verify = password_verify($oldPassword, $pw);

            
            if($verify) {
                $null = 0;
                $zero = 0;
                $encryptedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $statement = $db->prepare("UPDATE users SET password=? WHERE userID=?");
                $statement->bind_param("si",$encryptedNewPassword,$userID);
                $statement->execute();
                $message = "Password updated";
            }
        }
        
    }
    
    if(isset($_POST['mailAddressSubmit'])){
        $state = htmlspecialchars($_POST['state']);
        $city = htmlspecialchars($_POST['city']);
        $mailAddress1 = htmlspecialchars($_POST['mailAddress1']);
        $address2 = htmlspecialchars($_POST['mailAddress2']);
        $zip = htmlspecialchars($_POST['zip']);
        $validInput = true;
        if(empty($mailAddress1)){
            $message.= 'New address is required. Please try again. ';
            $validInput = false;
        }
        if(empty($city)){
            $message.= 'City is required. Please try again. ';
            $validInput = false;
        }
        if(empty($state)){
            $message.= 'State is required. Please try again. ';
            $validInput = false;
        }
        if(empty($zip)){
            $message.= 'Zip code is required. Please try again. ';
            $validInput = false;
        }
        if($validInput){
            $null = 0;
            $zero = 0;
            $statement = $db->prepare("DELETE FROM `addresses` WHERE userID=?");
            $statement->bind_param("i",$userID);
            $statement->execute();
            $statement = $db->prepare("INSERT INTO addresses VALUES (?,?,?,?,?,?,?)");
            $statement->bind_param("issssii",$null,$mailAddress1,$address2,$city,$state,$zip,$userID);//null is passed as userID so it is auto incremented, state and isAdmin are initialized to 0.
            $statement->execute();
            $message = "Mailing address updated";
        }
    }
    header('location: editUser.php?userID=' . $userID);
}

header('location: editUser.php?userID=' . $userID);


    ?>