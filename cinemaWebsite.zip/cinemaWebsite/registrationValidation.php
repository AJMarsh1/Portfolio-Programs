<?php
    include ("emailMaker.php");
    require('database.php');
    session_start();

	if(isset($_POST['submit'])){
		$validInput = true;
		$registered = false;

		//login info
		$email = htmlspecialchars($_POST['email']);
		if (isset($_COOKIE['email'])) {
			unset($_COOKIE['email']);
			setcookie('email', '', time() - 3600, '/'); // empty value and old timestamp
		}
		setcookie("email", $email, time() + 3);
		//check if a user with same email or username already exists
		$userCheck = $db->prepare("SELECT email FROM users WHERE email = '$email'");
		$userCheck->execute();
		$user = $userCheck->fetch();
		if($user){
			$_SESSION['emailAlready'] = "Account with that email already exists";
			$validInput = false;
		}

		$fName = htmlspecialchars($_POST['fName']);
		if (isset($_COOKIE['fname'])) {
			unset($_COOKIE['fname']);
			setcookie('fname', '', time() - 3600, '/'); // empty value and old timestamp
		}
		setcookie("fname", $fName, time() + 3);
		if (!preg_match ("/^[a-zA-z]*$/", $fName) ) {  
			$_SESSION['fnameFail'] = "Invalid input.";
			$validInput = false;
		}

		$lName = htmlspecialchars($_POST['lName']);
		if (isset($_COOKIE['lname'])) {
			unset($_COOKIE['lname']);
			setcookie('lname', '', time() - 3600, '/'); // empty value and old timestamp
		}
		setcookie("lname", $lName, time() + 3);
		if (!preg_match ("/^[a-zA-z]*$/", $lName) ) {  
			$_SESSION['lnameFail'] = "Invalid input.";
			$validInput = false;
		}

		$password = htmlspecialchars($_POST['password']);
		$number = preg_match('@[0-9]@', $password);
		$uppercase = preg_match('@[A-Z]@', $password);
		$lowercase = preg_match('@[a-z]@', $password);
		$specialChars = preg_match('@[^\w]@', $password);
		// 8 length, at least 1 number, 1 upposer case, 1 lower case, 1 special
		if(strlen($password) < 8 || !$number || !$uppercase || !$lowercase || !$specialChars) {
			$_SESSION['passwordFail'] = "Password must be at least 8 characters in length and must contain at least one number, one upper case letter, one lower case letter and one special character.";
			$validInput = false;
		}
		$encryptpass = password_hash($password, PASSWORD_DEFAULT);
		$confirmPassword = htmlspecialchars($_POST['confirmPassword']);
		//check if passwords match
		if($password != $confirmPassword){
			$_SESSION['confirmPasswordFail']= "Passwords do not match. Please try again.";
			$validInput = false;
		}

		//mailing info
		$mailAddress1 = htmlspecialchars($_POST['mailAddress1']);
		if (isset($_COOKIE['mailAddress1'])) {
			unset($_COOKIE['mailAddress1']);
			setcookie('mailAddress1', '', time() - 3600, '/'); // empty value and old timestamp
		}
		setcookie("mailAddress1", $mailAddress1, time() + 3);

		if(isset($_POST['mailAddress2'])) {
			$mailAddress2 = htmlspecialchars($_POST['mailAddress2']);
			if (isset($_COOKIE['mailAddress2'])) {
				unset($_COOKIE['mailAddress2']);
				setcookie('mailAddress2', '', time() - 3600, '/'); // empty value and old timestamp
			}
			setcookie("mailAddress2", $mailAddress2, time() + 3);
		}

		$mailCity = htmlspecialchars($_POST['mailCity']);
		if (isset($_COOKIE['mailCity'])) {
			unset($_COOKIE['mailCity']);
			setcookie('mailCity', '', time() - 3600, '/'); // empty value and old timestamp
		}
		setcookie("mailCity", $mailCity, time() + 3);
		if (!preg_match ("/^[a-zA-z]*$/", $mailCity) ) {  
			$_SESSION['mailCityFail'] = "Invalid input.";
			$validInput = false;
		}

		$mailState = htmlspecialchars($_POST['mailState']);
		if (isset($_COOKIE['mailState'])) {
			unset($_COOKIE['mailState']);
			setcookie('mailState', '', time() - 3600, '/'); // empty value and old timestamp
		}
		setcookie("mailState", $mailState, time() + 3);
		if (!preg_match ("/^[a-zA-z]*$/", $mailState) ) {  
			$_SESSION['mailStateFail'] = "Invalid input.";
			$validInput = false;
		}

		$mailZip = htmlspecialchars($_POST['mailZip']);
		if (isset($_COOKIE['mailZip'])) {
			unset($_COOKIE['mailZip']);
			setcookie('mailZip', '', time() - 3600, '/'); // empty value and old timestamp
		}
		setcookie("mailZip", $mailZip, time() + 3);
		if (!preg_match ('/^[0-9]*$/', $mailZip) || $mailZip < 10000) {  
			$_SESSION['mailZipFail'] = "Invalid input.";
			$validInput = false;
		}

		// payment info
		if(!empty($_POST['cardName'])) {
			$cardName = htmlspecialchars($_POST['cardName']);
			if (isset($_COOKIE['cardName'])) {
				unset($_COOKIE['cardName']);
				setcookie('cardName', '', time() - 3600, '/'); // empty value and old timestamp
			}
			setcookie("cardName", $cardName, time() + 3);
			if (!preg_match ("/^[a-zA-z]*$/", $cardName) ) {  
				$_SESSION['cardNameFail'] = "Invalid input.";
				$validInput = false;
			}

			if(empty($_POST['cardNum'])){
				$_SESSION['emptyCard'] = "Please empty field Name on Card or don't leave this field empty. card";
				$validInput = false;
			}
			$cardNum = htmlspecialchars($_POST['cardNum']);
			
			if (isset($_COOKIE['cardNum'])) {
				unset($_COOKIE['cardNum']);
				setcookie('cardNum', '', time() - 3600, '/'); // empty value and old timestamp
			}
			setcookie("cardNum", $cardNum, time() + 3);
			if (!preg_match ('/^[0-9]*$/', $cardNum) || $cardNum < 1000000000000000 || $cardNum > 9999999999999999) {  
				$_SESSION['cardNumFail'] = "Invalid input.";
				$validInput = false;
			}

			if(empty($_POST['expMon'])){
				$_SESSION['emptyMonth'] = "Please empty field Name on Card or don't leave this field empty.";
				$validInput = false;
			}
			$expMonth = htmlspecialchars($_POST['expMon']);
			if (isset($_COOKIE['expMonth'])) {
				unset($_COOKIE['expMonth']);
				setcookie('expMonth', '', time() - 3600, '/'); // empty value and old timestamp
			}
			setcookie("expMonth", $expMonth, time() + 3);
			if (!preg_match ('/^[0-9]*$/', $expMonth) || $expMonth < 1 || $expMonth > 12) {  
				$_SESSION['expMonthFail'] = "Invalid input.";
				$validInput = false;
			}

			if(empty($_POST['expYear'])){
				$_SESSION['emptyYear'] = "Please empty field Name on Card or don't leave this field empty.";
				$validInput = false;
			}
			$year = date("Y");
			$expYear = htmlspecialchars($_POST['expYear']);
			if (isset($_COOKIE['expYear'])) {
				unset($_COOKIE['expYear']);
				setcookie('expYear', '', time() - 3600, '/'); // empty value and old timestamp
			}
			setcookie("expYear", $expYear, time() + 3);
			if (!preg_match ('/^[0-9]*$/', $expYear) || $expYear < $year) {  
				$_SESSION['expYearFail'] = "Invalid input.";
				$validInput = false;
			}

			if(empty($_POST['cvv'])){
				$_SESSION['emptyCvv'] = "Please empty field Name on Card or don't leave this field empty.";
				$validInput = false;
			} else {
				$cvv = htmlspecialchars($_POST['cvv']);
				if (!preg_match ('/^[0-9]*$/', $cvv) || $cvv < 100) {  
					$_SESSION['cvvFail'] = "Invalid input.";
					$validInput = false;
				}
			}

			$sameAddress = 0;
			if (isset($_POST['billAddress'])) {
				$sameAddress = 1;	
			}
			if($sameAddress == 0) {
				echo "$sameAddress";
				if(empty($_POST['address1'])){
					$_SESSION['emptyAddress1'] = "Please empty field Name on Card or check the as same address or don't leave this field empty.";
					$validInput = false;
				} else {
					$address1 = htmlspecialchars($_POST['address1']);
					if (isset($_COOKIE['address1'])) {
						unset($_COOKIE['address1']);
						setcookie('address1', '', time() - 3600, '/'); // empty value and old timestamp
					}
					setcookie("address1", $address1, time() + 3);
				}
			
				$address2 = htmlspecialchars($_POST['address2']);
				if (isset($_COOKIE['address2'])) {
					unset($_COOKIE['address2']);
					setcookie('address2', '', time() - 3600, '/'); // empty value and old timestamp
				}
				setcookie("address2", $address2, time() + 3);

				if(empty($_POST['city'])){
					$_SESSION['emptyCity'] = "Please empty field Name on Card or check the as same address or don't leave this field empty.";
					$validInput = false;
				} else {
					$city = htmlspecialchars($_POST['city']);
					if (isset($_COOKIE['city'])) {
						unset($_COOKIE['city']);
						setcookie('city', '', time() - 3600, '/'); // empty value and old timestamp
					}
					setcookie("city", $city, time() + 3);
					if (!preg_match ("/^[a-zA-z]*$/", $city) ) {  
						$_SESSION['cityFail'] = "Invalid input.";
						$validInput = false;
					}
				} 

				if(empty($_POST['state'])){
					$_SESSION['emptyState'] = "Please empty field Name on Card or check the as same address or don't leave this field empty.";
					$validInput = false;
				} else {
					$state = htmlspecialchars($_POST['state']);
					if (isset($_COOKIE['state'])) {
						unset($_COOKIE['state']);
						setcookie('state', '', time() - 3600, '/'); // empty value and old timestamp
					}
					setcookie("state", $state, time() + 3);
					if (!preg_match ("/^[a-zA-z]*$/", $state) ) {  
						$_SESSION['stateFail'] = "Invalid input.";
						$validInput = false;
					}
				} 

				if(empty($_POST['zip'])){
					$_SESSION['emptyZip'] = "Please empty field Name on Card or check the as same address or don't leave this field empty.";
					$validInput = false;
				} else {
					$zip = htmlspecialchars($_POST['zip']);
					if (isset($_COOKIE['zip'])) {
						unset($_COOKIE['zip']);
						setcookie('zip', '', time() - 3600, '/'); // empty value and old timestamp
					}
					setcookie("zip", $zip, time() + 3);
					if (!preg_match ('/^[0-9]*$/', $zip) || $zip < 10000) {  
						$_SESSION['zipFail'] = "Invalid input.";
						$validInput = false;
					}
				}
			}
		}
		$promos = 0;
		if (isset($_POST['promotions'])) {
			$promos = 1;	
		}
		
		//$validInput=false;
		if($validInput == true){
			//Prepared statement, parameter binding, and execution
			$null = null;
			$zero = 0;
			$NULL = null;
			$statement = $db->prepare("INSERT INTO users VALUES (?,?,?,?,?,?,?,?,?,?)");
			$statement->bind_param("issssiiiss",$null,$email,$encryptpass,$fName,$lName,$zero,$zero,$promos,$NULL,$NULL);//null is passed as userID so it is auto incremented, state and isAdmin are initialized to 0.
			$statement->execute();

			//Check that account was created
			$usernameCheck = mysqli_query($db,"SELECT * FROM users WHERE email ='".$email."';");
			if (empty($usernameCheck)) {
				$accountCreationError = "Error creating account: " . $db->error;
				echo "Error creating account: " . $db->error;
				$db->close();
			} else {
				//Gets UserID of new account
				$userCheck = $db->prepare("SELECT userID FROM users WHERE email = '$email'");
				$userCheck->execute();
				$result = $userCheck->get_result();
				while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
					foreach ($row as $r) {
						$userID = $r;
					}
				}

				//Saves mailing address
				if(empty($mailAddress2)){
					$mailAddress2 = "";
				}
				$statement3=$db->prepare("INSERT INTO addresses VALUES (?,?,?,?,?,?,?)");
				$statement3->bind_param("isssssi",$null,$mailAddress1,$mailAddress2, $mailCity,$mailState,$mailZip,$userID);//null is passed as addressID so it is auto incremented.
				$statement3->execute();
				//echo $null." ".$mailAddress1." ".$mailAddress2." ". $mailCity." ".$mailState." ".$mailZip." ".$userID;

				
				//Saves entered payment info if box is checked
				if (isset($_POST['cardName'])) {
					$ciphering = "AES-128-CTR";
					$iv_length = openssl_cipher_iv_length($ciphering);
					$options = 0;
					$encryption_iv = '1234567891011121';
					$userCheck = $db->prepare("SELECT cardEncryptionKey FROM securityKeys");
						$userCheck->execute();
						$result = $userCheck->get_result();
						while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
							foreach ($row as $r) {
								$encryption_key = $r;
							}
						}
						//echo $encryption_key;
					$encryptionCard = openssl_encrypt($cardNum, $ciphering, $encryption_key, $options, $encryption_iv);
					//echo $encryptionCard;
					$encryptionCvv = openssl_encrypt($cvv, $ciphering, $encryption_key, $options, $encryption_iv);
					//echo $encryptionCvv;
					if($sameAddress){//Uses mailing address as billing address if box is checked
						$statement2 = $db->prepare("INSERT INTO paymentInfo VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
						$statement2->bind_param("issssssssiisi",$null,$encryptionCard,$mailAddress1,$mailAddress2,$mailCity,$mailZip,$mailState,$fName,$lName,$expMonth,$expYear,$encryptionCvv,$userID);//null is passed as userID so it is auto incremented, state and isAdmin are initialized to 0.
						$statement2->execute();
					}else{
						if(empty($address2)){
							$address2 = "";
						}
						$userCheck = $db->prepare("SELECT userID FROM users WHERE email = '$email'");
						$userCheck->execute();
						$result = $userCheck->get_result();
						while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
							foreach ($row as $r) {
								$userID = $r;
							}
						}
						$statement2 = $db->prepare("INSERT INTO paymentInfo VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
						$statement2->bind_param("issssssssiisi",$null,$encryptionCard,$address1,$address2,$city,$zip,$state,$fName,$lName,$expMonth,$expYear,$encryptionCvv,$userID);//null is passed as userID so it is auto incremented, state and isAdmin are initialized to 0.
						$statement2->execute();
					}
				}
			    // Set the activation code and send to the user
				$regCode =  md5(uniqid(mt_rand()));
				
				$regActivation = $db->prepare("UPDATE users SET verificationCode=? WHERE email=?");
				$regActivation->bind_param("ss",$regCode,$email);
				$regActivation->execute();
				$regActivation->close();
				
			    $regConLink = 'http://localhost/turbo-octo-guacamole-main/loginPage.php?regCode=' . $regCode;
			    
			    // Calls facade to hide implementation of the email functionality
			    $emailMaker = new EmailMaker($email, $regConLink);
			    $emailMaker->sendConfirmationEmail();
                
				$db->close();

				header('location: regConfirmationPage.php');

		}
	}else{
			$db->close();
			header('location: registrationPage.php');
		}
	}

?>
