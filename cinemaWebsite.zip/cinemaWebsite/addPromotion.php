<?php
    require('database.php');
    session_start();
    

    if(isset($_POST['save'])) {
        $code = $_POST['newPromoCode'];
        $percentOff = $_POST['newPromoPercent'];
        $expiration = date("Y-m-d", strtotime($_POST['newExpDate']));
        
        $query = $db->prepare("INSERT INTO promotions (code, percentOff, expiration) VALUES (?,?,?)");
        $query->bind_param("sis", $code, $percentOff, $expiration);
        $query->execute();
    }
    
    $db->close();

    header('location: managePromotions.php');
?>