<?php
    require('database.php');
    session_start();

    $userID = $_GET['userID'];
    if($userID) {
	    $query = $db->prepare("UPDATE `users` SET `state` = '1' WHERE `users`.`userID` = $userID");
	    $query->execute();
	    $db->close();
	    header('location: manageUsers.php');
	}
?>