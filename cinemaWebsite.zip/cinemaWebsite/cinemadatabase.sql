-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 04, 2022 at 05:40 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cinemadatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `AddressID` int(11) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `userID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`AddressID`, `address1`, `address2`, `city`, `state`, `zip`, `userID`) VALUES
(1, '123 Main Street', '', 'Loganville', 'Georgia', '30052', 24),
(15, '6001 GROVEGATE LN', '', 'TUCKER', 'Georgia', '30084', 38),
(16, '6001 GROVEGATE LN', '', 'TUCKER', 'Georgia', '30084', 39),
(17, '6001 GROVEGATE LN', '', 'TUCKER', 'Georgia', '30084', 40),
(20, '6001 GROVEGATE LN', '', 'TUCKER', 'Georgia', '30084', 43),
(21, '6001 GROVEGATE LN', '', 'TUCKER', 'Georgia', '30084', 44);

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `bookingID` int(11) NOT NULL,
  `streetAddress` char(64) NOT NULL DEFAULT '',
  `city` char(32) NOT NULL DEFAULT '',
  `zipCode` char(16) NOT NULL DEFAULT '',
  `state` char(16) NOT NULL DEFAULT '',
  `bookerID` int(11) NOT NULL DEFAULT 0,
  `ticketIDs` char(255) NOT NULL DEFAULT '',
  `totalPrice` float(255,2) NOT NULL DEFAULT 0.00,
  `numTickets` int(11) NOT NULL DEFAULT 0,
  `showingID` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `movieID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `trailerLink` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `director` varchar(255) NOT NULL DEFAULT '',
  `genre` varchar(255) NOT NULL DEFAULT '',
  `cast` varchar(255) NOT NULL DEFAULT '',
  `producer` varchar(255) NOT NULL DEFAULT '',
  `review` varchar(255) NOT NULL DEFAULT '0/10',
  `rating` varchar(255) NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL,
  `runtime` int(11) NOT NULL DEFAULT 120,
  `date` date NOT NULL DEFAULT '2022-01-01'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`movieID`, `title`, `trailerLink`, `description`, `director`, `genre`, `cast`, `producer`, `review`, `rating`, `image`, `runtime`, `date`) VALUES
(1, 'Encanto', 'https://www.youtube.com/embed/CaimKeDcudo?start=1', 'A Colombian teenage girl has to face the frustration of being the only member of her family without magical powers.', 'Jared Bush, Byron Howard', 'Animation, Comedy, Family', 'Stephanie Beatriz, María Cecilia Botero, John Leguizamo, 	Mauro Castillo', 'Yvett Merino, Clark Spencer, Jennifer Lee', '7.3/10', 'PG', 'movie5.jpg', 120, '2022-01-01'),
(3, 'Scream', 'https://www.youtube.com/embed/beToTslH17s', '25 years after a streak of brutal murders shocked the quiet town of Woodsboro, Calif., a new killer dons the Ghostface mask and begins targeting a group of teenagers to resurrect secrets from the town\'s deadly past.', 'Matt Bettinelli-Olpin, Tyler Gillett', 'Horror, Mystery, Thriller', 'Neve Campbell, Courteney Cox, David Arquette, Melissa Barrera', 'Paul Neinstein, James Vanderbilt, William Sherak', '6.4/10', 'R', 'movie2.jpg', 120, '2022-01-01'),
(4, 'Blacklight', 'https://www.youtube.com/embed/PE04ESdgnHI', 'Travis Block is a government operative coming to terms with his shadowy past. When he discovers a plot targeting U.S. citizens, Block finds himself in the crosshairs of the FBI director he once helped protect.', 'Mark Williams', 'Action, Thriller', 'Aidan Quinn, Taylor John Smith, Liam Neeson, Claire van der Boom, Emmy Raver-Lampman, Yael Stone', 'Mark Williams, Myles Nestel, Coco Xiaolu Ma, Allie Loh, Paul Currie', '4.7/10', 'PG-13', 'movie3.jpg', 120, '2022-01-01'),
(5, 'Moonfall', 'https://www.youtube.com/embed/ivIwdQBlS10', 'A mysterious force knocks the moon from its orbit around Earth and sends it hurtling on a collision course with life as we know it.', 'Roland Emmerich', 'Action, Adventure, Sci-Fi', 'Halle Berry, Patrick Wilson, John Bradley, Charlie Plummer, Wenwen Yu, Michael Peña', 'Roland Emmerich, Harald Kloser', '5.2/10', 'PG-13', 'movie4.jpg', 120, '2022-01-01'),
(6, 'The Fallout', 'https://www.youtube.com/embed/Gtl-6RCOl84', 'High schooler Vada navigates the emotional fallout she experiences in the wake of a school tragedy. Relationships with her family, friends and view of the world are forever altered.', 'Megan Park', 'Drama', 'Maddie Ziegler, Niles Fitch, Jenna Ortega, Will Ropp, Lumi Pollack, John Ortiz, Julie Bowen', 'David Brown, Todd Lundbohm, Rebecca Miller, Giulia Prenna, Shaun Sanghani, Cara Shine Ballarini', '7.0/10', 'R', 'movie6.jpg', 120, '2022-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `title` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `price` float NOT NULL,
  `userID` int(11) NOT NULL,
  `confirmationNumber` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `paymentinfo`
--

CREATE TABLE `paymentinfo` (
  `paymentMethodID` int(11) NOT NULL,
  `cardNumber` varchar(255) NOT NULL DEFAULT '',
  `streetAddress` char(64) NOT NULL DEFAULT '',
  `streetAddress2` varchar(255) NOT NULL,
  `city` char(32) NOT NULL DEFAULT '',
  `zipCode` char(16) NOT NULL DEFAULT '',
  `state` char(16) NOT NULL DEFAULT '',
  `fName` varchar(255) NOT NULL,
  `lName` varchar(255) NOT NULL,
  `expMonth` int(11) NOT NULL DEFAULT 1,
  `expYear` int(11) NOT NULL DEFAULT 2000,
  `cvv` varchar(255) NOT NULL,
  `ownerID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `paymentinfo`
--

INSERT INTO `paymentinfo` (`paymentMethodID`, `cardNumber`, `streetAddress`, `streetAddress2`, `city`, `zipCode`, `state`, `fName`, `lName`, `expMonth`, `expYear`, `cvv`, `ownerID`) VALUES
(13, 'cOUi+eKMlNJT6V7/', '124 Main Street', ' ', 'Loganville', '30052', 'Georgia', 'Andrew', 'Marsh', 1, 2023, '123', 24),
(26, 'c+Yh+uGPl9FQ6l38JJ5+4w==', '6001 GROVEGATE LN', '', 'TUCKER', '30084', 'Georgia', 'Junyi', 'Pan', 2, 2022, 'c+Yh', 38),
(27, 'cOYg/OaLkttb6F78JZh55w==', '6001 GROVEGATE LN', '', 'TUCKER', '30084', 'Georgia', 'Junyi', 'Pan', 11, 2022, 'cOUi', 39),
(28, 'cOYg/OaLkttb6F78JZh55w==', '6001 GROVEGATE LN', '', 'TUCKER', '30084', 'Georgia', 'Junyi', 'Pan', 11, 2022, 'cOUi', 40),
(31, 'cOYg/OaLkttb6F78JZh55w==', '6001 GROVEGATE LN', '', 'TUCKER', '30084', 'Georgia', 'Junyi', 'Pan', 22, 2022, 'c+Yh', 43),
(32, 'cOYg/OaLkttb6F78JZh55w==', '6001 GROVEGATE LN', '', 'TUCKER', '30084', 'Georgia', 'Junyi', 'Pan', 11, 2022, 'cOUi', 44),
(33, 'cOYg/OaLkttb6F78JZh55w==', '6001 GROVEGATE LN', ' ', 'TUCKER', '30084', 'GA', 'Junyi', 'Pan', 12, 2222, '0', 44);

-- --------------------------------------------------------

--
-- Table structure for table `price`
--

CREATE TABLE `price` (
  `priceID` int(11) NOT NULL,
  `flat` float(255,2) NOT NULL DEFAULT 0.80,
  `adult` float(255,2) NOT NULL,
  `child` float(255,2) NOT NULL,
  `senior` float(255,2) NOT NULL,
  `tax` float(255,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `price`
--

INSERT INTO `price` (`priceID`, `flat`, `adult`, `child`, `senior`, `tax`) VALUES
(1, 0.80, 12.00, 8.00, 10.00, 0.07);

-- --------------------------------------------------------

--
-- Table structure for table `promotions`
--

CREATE TABLE `promotions` (
  `code` char(32) NOT NULL DEFAULT '',
  `percentOff` int(11) NOT NULL DEFAULT 0,
  `expiration` date NOT NULL DEFAULT '2022-03-04',
  `active` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `seatID` varchar(255) NOT NULL,
  `showroomID` int(255) NOT NULL DEFAULT 1,
  `reservationTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`seatID`, `showroomID`, `reservationTime`) VALUES
('E2', 1, '2022-05-04 17:22:30');

-- --------------------------------------------------------

--
-- Table structure for table `securitykeys`
--

CREATE TABLE `securitykeys` (
  `cardEncryptionKey` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `securitykeys`
--

INSERT INTO `securitykeys` (`cardEncryptionKey`) VALUES
('sup3rs3cr3tk3y');

-- --------------------------------------------------------

--
-- Table structure for table `showings`
--

CREATE TABLE `showings` (
  `showingID` int(11) NOT NULL,
  `movieID` int(11) NOT NULL DEFAULT 0,
  `showDate` datetime NOT NULL,
  `showroomID` int(255) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `showings`
--

INSERT INTO `showings` (`showingID`, `movieID`, `showDate`, `showroomID`) VALUES
(1, 1, '2022-05-05 16:00:00', 1),
(2, 1, '2022-05-06 18:30:00', 1),
(3, 1, '2022-05-07 11:00:00', 1),
(4, 1, '2022-05-07 18:30:00', 1),
(5, 4, '2022-05-06 19:30:00', 1),
(6, 4, '2022-05-06 23:00:00', 1),
(7, 6, '2022-05-10 20:00:00', 1),
(8, 6, '2022-05-10 23:30:00', 1),
(9, 6, '2022-05-11 20:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `showrooms`
--

CREATE TABLE `showrooms` (
  `showroomID` int(11) NOT NULL,
  `numSeats` int(11) NOT NULL DEFAULT 10,
  `reservedSeats` char(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `ticketID` int(11) NOT NULL,
  `ticketType` varchar(255) NOT NULL,
  `showingID` int(11) NOT NULL DEFAULT 0,
  `seatNumber` varchar(256) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`ticketID`, `ticketType`, `showingID`, `seatNumber`) VALUES
(1, 'child', 2, 'A3'),
(2, 'adult', 2, 'A4');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `email` char(32) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `firstName` char(32) NOT NULL DEFAULT '',
  `lastName` char(32) NOT NULL DEFAULT '',
  `state` int(11) NOT NULL DEFAULT 1,
  `isAdmin` int(11) NOT NULL DEFAULT 0,
  `subscribed` int(11) NOT NULL DEFAULT 0,
  `reset_password_token` varchar(45) DEFAULT NULL,
  `verificationCode` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `email`, `password`, `firstName`, `lastName`, `state`, `isAdmin`, `subscribed`, `reset_password_token`, `verificationCode`) VALUES
(24, 'ajm36242@uga.edu', '$2y$10$NadF1eh70XOtJNU6bQU9Uu3MDsP1dLPHCQSD6wFb7z92x9noKNxYy', 'Andrew', 'Marsh', 1, 1, 0, NULL, NULL),
(38, 'junyipan8460@gmail.com', '$2y$10$Ytr4r4Vf76dccHaG4L0FpOpIIKjtV3IhOSyyndhtAlmCo3zb7KsaC', 'Junyi', 'Pan', 1, 0, 1, NULL, NULL),
(39, 'abcdefg@gmail.com', '$2y$10$u0kxcfQc.4P7jD8IBCjMwuJt1nsrVUUCHRNmk3CGXQSJ0J2fanrrm', 'Junyi', 'Pan', 0, 0, 0, NULL, NULL),
(40, '123@gmail.com', '$2y$10$nTFFB4vt4Qw4EOv5/AXxce.ku7FfnFCWaFI5VDPfjgmIhaKNTgsDG', 'Junyi', 'Pan', 2, 0, 0, NULL, NULL),
(43, '321@gmail.com', '$2y$10$27bGUxqrEpYN8vfX43O7yeWLXPVoJCxJEorib/VUqVic3cGJrTrci', 'Junyi', 'Pan', 0, 0, 0, NULL, NULL),
(44, '123456789@gmail.com', '$2y$10$3YZ4W9s7pOMQozK7Ui0BXOqqcDcolTEoAuAC0iOwClRyWHd3Oj2SW', 'Junyi', 'Pan', 1, 0, 0, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`AddressID`),
  ADD KEY `Foreign Key` (`userID`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`bookingID`),
  ADD KEY `Person` (`bookerID`),
  ADD KEY `Show` (`showingID`);

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`movieID`);

--
-- Indexes for table `paymentinfo`
--
ALTER TABLE `paymentinfo`
  ADD PRIMARY KEY (`paymentMethodID`),
  ADD KEY `Owner` (`ownerID`);

--
-- Indexes for table `price`
--
ALTER TABLE `price`
  ADD PRIMARY KEY (`priceID`);

--
-- Indexes for table `promotions`
--
ALTER TABLE `promotions`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `showings`
--
ALTER TABLE `showings`
  ADD PRIMARY KEY (`showingID`),
  ADD KEY `Movie` (`movieID`);

--
-- Indexes for table `showrooms`
--
ALTER TABLE `showrooms`
  ADD PRIMARY KEY (`showroomID`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticketID`),
  ADD KEY `wohs` (`showingID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `AddressID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `bookingID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `movieID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `paymentinfo`
--
ALTER TABLE `paymentinfo`
  MODIFY `paymentMethodID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `price`
--
ALTER TABLE `price`
  MODIFY `priceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `showings`
--
ALTER TABLE `showings`
  MODIFY `showingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `showrooms`
--
ALTER TABLE `showrooms`
  MODIFY `showroomID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticketID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `Foreign Key` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `Person` FOREIGN KEY (`bookerID`) REFERENCES `users` (`userID`),
  ADD CONSTRAINT `Show` FOREIGN KEY (`showingID`) REFERENCES `showings` (`showingID`);

--
-- Constraints for table `paymentinfo`
--
ALTER TABLE `paymentinfo`
  ADD CONSTRAINT `Owner` FOREIGN KEY (`ownerID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `showings`
--
ALTER TABLE `showings`
  ADD CONSTRAINT `Movie` FOREIGN KEY (`movieID`) REFERENCES `movies` (`movieID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `wohs` FOREIGN KEY (`showingID`) REFERENCES `showings` (`showingID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
