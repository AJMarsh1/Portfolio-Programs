<?php
    require('database.php');
    session_start();

    $userID = $_GET['userID'];
    $userCheck = $db->prepare("SELECT subscribed FROM users WHERE userID = '$userID'");
    $userCheck->execute();
    $result = $userCheck->get_result();
    while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
        foreach ($row as $r) {
            $promotions = $r;
        }
    }
    
    /*
    if(isset($userID)) {
	    $query = $db->prepare("UPDATE `users` SET `state` = '2' WHERE `users`.`userID` = $userID");
	    $query->execute();
	    $db->close();
	    header('location: manageUsers.php');
	}
	
	if(isset($_REQUEST['edit'])) {
	    header("editProfile.php?" . $userID);
	}
	*/
    /*
    if(isset($_SESSION['admin'])){
        $isAdmin = $_SESSION['admin'];
    }
    if(isset($_SESSION['userID'])) {
        $userID = $_SESSION['userID'];
    } else {
        header("location: loginPage.php");
    }
    */
    ?>
    

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Edit User Profile</title>
</head>
<body>


	<div class="navBar">
	  <div class="leftSideNav">
	    <h1>Turbo <br> Theatres</h1>
	    <a href="homepage.php" class="navBookMovie">Home</a>
	  </div>

	  
	    <div class="rightSideNav">
	      <input type="text" placeholder="Search..">
	      <a href="signout.php" class="logoutButton">Log Out</a>
	    </div>
	  </div>
	</div>
	

	<div class="editProfile">

		<div> 


			<h4>Editting User Profile for: <?php 
								$userCheck = $db->prepare("SELECT firstName FROM users WHERE userID = '$userID'");
								$userCheck->execute();
								$result = $userCheck->get_result();
								while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
									foreach ($row as $r) {
										$fname = $r;
									}
								}
								echo $fname;

								echo " ";

								$userCheck = $db->prepare("SELECT lastName FROM users WHERE userID = '$userID'");
								$userCheck->execute();
								$result = $userCheck->get_result();
								while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
									foreach ($row as $r) {
										$lname = $r;
									}
								}
								echo $lname;
							?></h4>
							

			<div class="fullForm">

				<div>

			<div class="editProfileForm">

				<form class="field" action="editUserInfo.php" method = "POST">
						<h2>Email: </h2>
							<h3><?php 
								$userCheck = $db->prepare("SELECT email FROM users WHERE userID = '$userID'");
								$userCheck->execute();
								$result = $userCheck->get_result();
								while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
									foreach ($row as $r) {
										$email = $r;
									}
								}
								echo $email;
							?></h3>

							<div class="checkField">

								<input class="checkInput" type="checkbox" name="promotions" id="promotions" <?php if($promotions==1) { ?> checked <?php } ?> value="1">      <!-- fix value -->
								<label for="promotions">Recieve promotions</label>
								<input type="hidden" name="userID" value="<?php echo $userID;?>">

							</div>

							<input type="submit" name="promoSubmit" value="Submit">

					</form>


					<form class="field" action="editUserInfo.php" method = "POST">
						<h2>Password: </h2>
							<label for="oldPassword">Old Password:</label>
							<input type="text" name="oldPassword" id="oldPassword" placeholder="Old Password">
							<label for="newPassword">New Password:</label>
							<input type="text" name="newPassword" id="newPassword" placeholder="New Password">
							<input type="hidden" name="userID" value="<?php echo $userID;?>">

							<input type="submit" name="passwordSubmit" value="Submit">
					</form>


					<form class="field" action="editUserInfo.php" method="POST">
						<h2>Mailing Address: </h2>
							<h3><?php 
							  $address = "";
								$userCheck = $db->prepare("SELECT address1 FROM addresses WHERE userID = '$userID'");
								$userCheck->execute();
								$result = $userCheck->get_result();
								while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
									foreach ($row as $r) {
										$address = $r;
									}
								}
								echo $address;
							?></h3>
							<label for="mailAddress1">New Mailing Address:</label>
							<input type="text" name="mailAddress1" id="mailAddress1" placeholder="Address">

							<input type="text" name="mailAddress2" id="mailAddress2" placeholder="Address 2">

							<div class="addressDetails">
								<input type="text" name="city" id="city" placeholder="City">
								<input type="text" name="state" id="state" placeholder="State">   <!-- could make dropdown to look nicer -->
								
							</div>

								<input type="text" name="zip" id="zip" placeholder="Zip Code"> 
								<input type="hidden" name="userID" value="<?php echo $userID;?>">

								<input type="submit" name="mailAddressSubmit" value="Submit">
						
					</form>
					
			</div>

			</div>


			</div>

				
		</div>

	</div>





</body>

<style >


* {
	margin: 0;
	padding: 0;
}


body {
	background-color: black;
	font-family: "Montserrat", sans-serif;
	color: white;
}


h1 {
	font-style: italic;
}

h2 {
	/*font-size: 15px;*/
	margin-bottom: 15px;
}

h3 {
	font-size: 15px;
	margin-bottom: 10px;
}


.navBar {
  display: inline-flex;
  flex-direction: row;
  width: 100%;
  justify-content: space-between;

  background-image: linear-gradient(to right, black , #040194);
  color: white;
  align-items: center;
  padding-bottom: 5px;
}

.leftSideNav {
	padding-left: 90px;
	display: inline-flex;
  flex-direction: row;
  align-items: center;
}

.navBookMovie {
	text-decoration: none;
	color: white;
	margin-left: 50px;
}

.rightSideNav {
	padding-right: 20px;
	display: inline-flex;
  flex-direction: row;
  align-items: center;
  gap: 10px;
}

.rightSideNav input[type=text] {
	float: right;
 	padding: 4px 4px 4px 15px;
 	border: none;
 	margin-right: 50px;
	font-family: "Montserrat", sans-serif; 
	border-radius: 4px;
	background-color: #292791;
	color: white;


}


.logoutButton {
	float: right;
	text-decoration: none;
	color: white;

}

.logoutButton:visited {
	color: white;
	text-decoration: none;
}


.editProfile {
	display: inline-flex;
	flex-direction: column;
	align-items: center;
	width: 100%;
}


.editProfileForm {
	width: 100%;
	display: grid;
	grid-template-columns: repeat(2, 1fr);

}


.field {
	display: inline-flex;
	flex-direction: column;
	margin-top: 10px;
	margin-bottom: 30px;
	margin-right: 40px;
}

.checkField {
			display: inline-flex;
			flex-direction: row;
			align-items: center;
			font-size: 16px;
			margin-top: 20px;
			/*margin-bottom: 10px;*/
}


.checkInput {
			height: 25px;
			width: 25px;
			margin-right: 10px;
}

.fullForm {
	display: inline-flex;
	flex-direction: column;
	align-items: center;
	width: 100%;
}


h4 {
	padding-top: 20px;
	padding-bottom: 20px;
	font-size: 35px;
}


input {
	height: 30px;
	width: 150px;
	font-size: 15px;
}

input[type=submit] {
	font-size: 15px;
	font-family: "Montserrat", sans-serif;
	margin-bottom: 30px;
	margin-top: 20px;
	/*text-align: center;*/
}

label {
	margin-top: 10px;
}



	
</style>


</html>
