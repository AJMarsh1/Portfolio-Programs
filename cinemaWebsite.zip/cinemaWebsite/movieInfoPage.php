<?php
  require('database.php');
  session_start();
?>

  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <title>Movie Info</title>  
    <link rel="preconnect" href="https://fonts.googleapis.com"> 
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
  </head>
  <body>
    <div class="navBar">
      <div class="leftSideNav">
        <a class="home" href="homepage.php">
          <h1>Turbo <br> Theatres</h1>
        </a>
        <a href="searchResultsPage.php" class="navBookMovie">Get Tickets</a>
      </div>
        <!-- <a href="" class="homeButton">Turbo Theatres</a> -->
        <!-- Right-sided navbar links. Hide them on small screens -->
        <div class="rightSideNav">
          <form action="searchResultsPage.php" method="POST">
            <div class="searchForm">
              <div class="searchOptions">
                <input type="text" name="searchTerms" placeholder="Search...">
                <a href="searchResultsPage.php" class="aSearch">Advanced Search</a>
              </div>
              <input type="submit" name="search" value="Go">
              <!-- <p>&#x1F50D</p> -->
            </div>
          </form>

          <?php 
            if(isset($_SESSION['userID'])) {
              if(isset($_SESSION['admin'])) { 
                echo '<a href="adminHome.php" class="logoutButton">Admin Portal |</a>';
              }
              echo '<a href="editProfilePage.php" class="logoutButton">Edit Profile |</a>';
              echo '<a href="signout.php" class="logoutButton">Log Out</a>';
            } else { 
              echo '<a href="loginPage.php" class="loginButton">Log In |</a>';
              echo '<a href="registrationPage.php" class="signUpButton">Sign Up</a>';
            }
          ?>
        </div>
    </div>
    <div class="infoPage">
      <?php
        if(!empty($_GET['movieID'])){
          $movieID = $_GET['movieID'];
        }else{
          $movieID = "1";
        }
        $yes = false;
        $usersArray = $db->prepare("SELECT * FROM showings WHERE movieID = ".$movieID);
        $usersArray->execute();
        $results = $usersArray->get_result();
        while($row2 = $results->fetch_array() ){
          $yes = true;
        }
        $usersArray = $db->prepare("SELECT * FROM movies WHERE movieID = ".$movieID);
        $usersArray->execute();
        $results = $usersArray->get_result();
        echo "<br>";
        while( $row = $results->fetch_array() ){
          echo "<h2>".$row['title']."</h2>";
          if ($yes == false) {
            echo"<h4>Coming Soon</h4>";
          } else {
            echo"<h4>Now Showing</h4>";
          }
          echo "<div class='imgAndVid'>
            <img class='movieImg' src='".$row['image']."'>
            <iframe width='604' height='340' src='".$row['trailerLink']."' title='YouTube video player' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>  
          </div>
          <div class='movie'>
            <h4>".$row['description']."</h4>
            <div class='movieInfo'>
            <div class='details'>
              <h3>Run Time:</h3> <h5> ".$row['runtime']." min</h5>
            </div>
            <div class='details'>
              <h3>Genre:</h3> <h5>".$row['genre']."</h5>
            </div>
            <div class='details'>
              <h3>Rating:</h3> <h5>".$row['rating']."</h5>
            </div>
            <div class='details'>
              <h3>Starring:</h3> <h5>".$row['cast']."</h5>
            </div>
            <div class='details'>
              <h3>Directed by:</h3> <h5>".$row['director']."</h5>
            </div>
            <div class='details'>
              <h3>Produced by:</h3> <h5>".$row['producer']."</h5>
            </div>
          </div>
          <h3>Showtimes</h3>
          <div class='times'> ";
          // <div class='dateLabel'> ";
            $date = date("m-d-Y", strtotime("January 1 1000"));
            // "</div>";
            $usersArray = $db->prepare("SELECT * FROM showings WHERE movieID = ".$movieID);
            $usersArray->execute();
            $results = $usersArray->get_result();
            while($row2 = $results->fetch_array() ){
              "<div class='dateLabel'> ";
              if($date != date("m-d-Y", strtotime($row2['showDate']))){
                $date = date("m-d-Y", strtotime($row2['showDate']));
                // "<div class='dateLabel'> ";
                echo "$date";
                $timeCheck = $db->prepare("SELECT * FROM showings WHERE movieID = ".$movieID);
                $timeCheck->execute();
                $results2 = $timeCheck->get_result();
                "<div> ";
                while($row3 = $results2->fetch_array()){
                  // "<div class='dateLabel'> ";

                  $date2 = date("m-d-Y", strtotime($row3['showDate']));
                  if ($date2 == $date) {
                    // "<div> ";
                    $date3 = date("h:ia", strtotime($row3['showDate']));
                    echo "<a class='showTime' href='ticketSeatPage.php?showingID=".$row2['showingID']."&movieID=".$movieID."''> ".$date3."</a> ";
                    // "</div>";
                    // "</div>";
                  }
                }

                // "</div>";
              }
            }
          echo "</div>
          <div class='details'>
            <h3>Reviews: ".$row['review']."</h3>
          </div>";
        }
      ?>
    </div>
  </body>
    <style>
      
      * {
        margin: 0;
        padding: 0;
      }


      body {
        background-color: black;
        font-family: "Montserrat", sans-serif;
        color: white;
        /*margin-left: 40px;*/
      }

      .home {
        color: white;
        text-decoration: none;
      }

      .home:visited {
        color: white;
      }


      h1 {
        /*used on homepage*/
        font-style: italic;
      }

      h2 {
        /*used on homepage*/
        font-size: 50px;
        margin-top: 10px;
        /*margin-left: 40px;*/
      }

      h3 {
        /*used on homepage & reg confirmation page*/
        font-size: 20px;
        margin-bottom: 10px;
        /*text-align: center;*/
      }

      h4 {
        font-size: 20px;
        margin-bottom: 30px;
      }


      .navBar {
      /*padding: 20px 10px;*/
      display: inline-flex;
      flex-direction: row;
      width: 100%;
      justify-content: space-between;
      /*background: #08014a;*/

      background-image: linear-gradient(to right, black , #040194);

      /*background: #040194;*/
      color: white;
      align-items: center;
      padding-bottom: 5px;

      /*box-shadow: 0px 5px black;*/
    }

    .leftSideNav {
      padding-left: 90px;
      display: inline-flex;
      flex-direction: row;
      align-items: center;
    }

    .navBookMovie {
      text-decoration: none;
      color: white;
      margin-left: 50px;
    }


    /*.homeButton {
      font-size: 30px;
      color: white;
      text-decoration: none;
      
    }*/

    .rightSideNav {
      padding-right: 20px;
      display: inline-flex;
      flex-direction: row;
      align-items: center;
      gap: 10px;
    }

    .rightSideNav input[type=text] {
      float: right;
      padding: 4px 4px 4px 15px;
      border: none;
      /*margin-right: 50px;*/
      font-family: "Montserrat", sans-serif; 
      border-radius: 4px;
      /*background-color: #3f34d1;*/
      background-color: #292791;
      color: white;

    }
    

    
    .searchForm {
      display: inline-flex;
      flex-direction: row;
      margin-right: 50px;
      gap: 10px;
      margin-top: 10px;

    }

    .searchOptions {
      display: inline-flex;
      flex-direction: column;
      gap: 10px;
    }

    .searchForm input[type=submit] {
      height: 47px;
      width: 47px;
      font-family: "Montserrat", sans-serif; 
      border-radius: 4px;
      /*float: left;*/
    }

    .aSearch {
      font-size: 12px;
      /*margin-right: 50px;*/
      /*text-decoration: none;*/
      color: white;
      margin-left: 10px;
    }

    .aSearch:visited {
      /*text-decoration: none;*/
      color: white;
    }

    .loginButton {
      float: right;
      text-decoration: none;
      color: white;

    }

    .loginButton:visited {
      color: white;
      text-decoration: none;
    }


    .signUpButton {
      float: right;
      text-decoration: none;
      color: white;
      margin-right: 10px;

    }

    .signUpButton:visited {
      color: white;
      text-decoration: none;
    }
      
  .logoutButton {
    float: right;
    text-decoration: none;
    color: white;

  }

  .logoutButton:visited {
    color: white;
    text-decoration: none;
  }
      
    input {
    height: 40px;
    width: 200px;
    font-size: 15px;
  }

  .infoPage {
    margin-left: 40px;
    display: inline-flex;
    flex-direction: column;
    gap: 20px;
  }

  .imgAndVid {
    display: inline-flex;
    flex-direction: row;
    gap: 20px;
  }

  .movieImg {
      width: 225px;
      height: auto;
      margin-bottom: 20px;
    }

    .movieInfo {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      grid-column-gap: 50px;
    }

    .details {
      margin: 10px 10px 40px 0px;
    }

    .times {
      display: inline-flex;
      flex-direction: column;
      gap: 30px;
      margin-bottom: 20px;
      margin-top: 10px;
    }

    .dateLabel {
      /*background-color: pink;*/
      display: inline-flex;
      flex-direction: column;
    }

    .showTime {
      text-decoration: none;
      background-color: white;
      color: #08014a;
      text-align: center;
      padding: 10px 40px;
      border-radius: 3px;
    }



    

    </style>

  </html>







