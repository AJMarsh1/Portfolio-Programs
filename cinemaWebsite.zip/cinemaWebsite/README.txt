This project was from my software engineering class, and was done as a group project with three other
people. I am pretty proud of the result, as the website is fast, functional, well designed from a UI/UX
perspective, has a ton of features, and when we presented to our instructor she complimented it a lot.

While every member helped everyone else out when needed, we worked in a scrum model of development
and I was personally responsible for the seat selection, checkout, search functionality, movie info
pages, and parts of the admin pages.

If I did this project again, I would focus on making my code cleaner and make better use of OOP principles.
I was ot super comfortable with PHP, and learned msot of it on my own, so I made a lot of mistakes
like not using functions instead of just beginning to end blocks of code in places.