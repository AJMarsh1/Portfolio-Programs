<?php
    require('database.php');
    session_start();

	if(isset($_POST['submit'])){
        $fp_code = $_POST['fp_code'];
		$password = htmlspecialchars($_POST['password']);
		$confirmPassword = htmlspecialchars($_POST['confirmPassword']);
		$encryptpass = password_hash($password, PASSWORD_DEFAULT);
		$validInput = true;

		if(empty($password)){
			$_SESSION['message'] = 'New password is required. Please try again.';
			$validInput = false;
		}
		
		if($password !== $confirmPassword){
		    $_SESSION['message'] = 'Passwords do not match. Please try again.';
			$validInput = false;
		}
		
		
		/*
		if($fp_code !== $reset_password_token) {
		    $validInput = false;
		}
		*/
		

		if($validInput){
    		$statement = $db->prepare("UPDATE users SET password=? WHERE reset_password_token=?");
    		$statement->bind_param("ss",$encryptpass,$fp_code);
    		$statement->execute();
    		$_SESSION['message'] = 'Password updated';
    		header('location: loginPage.php');
		} else {
		    // Occurs if there is no such fp_code
		    $_SESSION['message'] = 'Incorrect validation token';
		    header('location: forgotPassword.php?fp_code=' . $fp_code);
		}
	}
?>
