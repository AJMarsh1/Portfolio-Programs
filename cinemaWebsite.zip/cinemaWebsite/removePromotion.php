<?php
    require('database.php');
    session_start();
    
    $sql = "DELETE FROM promotions WHERE code='" . $_GET['code'] . "'";
    if (mysqli_query($db, $sql)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($db);
    }
    mysqli_close($db);

    header('location: managePromotions.php');
?>
