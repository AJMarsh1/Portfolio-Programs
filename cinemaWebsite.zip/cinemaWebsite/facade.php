<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require '/Applications/XAMPP/xamppfiles/htdocs/turbo-octo-guacamole-main/PHPMailer/src/PHPMailer.php';
require '/Applications/XAMPP/xamppfiles/htdocs/turbo-octo-guacamole-main/PHPMailer/src/Exception.php';
require '/Applications/XAMPP/xamppfiles/htdocs/turbo-octo-guacamole-main/PHPMailer/src/SMTP.php';

// Declare the interface 'Template'
interface EmailTemplate
{
    public function sendEmail();
}

// Implement the interface to create the email promotion template
class EmailForgotPassword implements EmailTemplate
{
    private $email;
    private $link;
    
    public function EmailForgotPassword($email, $link) {
        $this->email = $email;
        $this->link = $link;
    }
    
    
    public function sendEmail() {
        
        $mail = new PHPMailer(true);
        try {
            //Server settings
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'turbooctoguac@gmail.com';                     //SMTP username
            $mail->Password   = 'turboocto5';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
            
            //Recipients
            $mail->setFrom('no-reply@turbooctoguac.com', 'Turbo Theaters');
            
            $mail->addAddress($this->email);
            
            //Content
            $mail->isHTML(true);
            $mail->Subject = 'Reset Password Request';
            $mailConent = 'Dear Turbo Theaters User,
                <br/> There has been a request to reset your password for your account. </b> If this is an error please contact customer support.
                <br/>To reset your password, visit the following link: <a href="'. $this->link .'">'. $this->link .'</a>
                <br/><br/>Best,
                <br/>The Turbo Theaters Team';
            $mail->Body = $mailConent;
            $mail->AltBody = 'There has been a request to reset your password for your account. If this is an error please contact customer support. To reset your password, visit the following link: <a href="'. $this->link .'">'. $this->link .'</a> Best, The Turbo Octo Guac Team';
            
            $mail->send();
            echo 'Message has been sent';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }

        header('location: loginPage.php'); // modified line 280 of SMTP.php to get this working
    }
}


class EmailConfirmation implements EmailTemplate
{
    private $email;
    private $link;
    
    public function EmailConfirmation($email, $link) {
        $this->email = $email;
        $this->link = $link;
    }
    
    
    public function sendEmail() {
        
        $mail = new PHPMailer(true);
        try {
            //Server settings
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'turbooctoguac@gmail.com';                     //SMTP username
            $mail->Password   = 'turboocto5';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
            
            //Recipients
            $mail->setFrom('no-reply@turbooctoguac.com', 'Turbo Theaters');
            
            $mail->addAddress($this->email);
            
            //Content
            $mail->isHTML(true);
            $mail->Subject = 'Account Successfully Created!';
            $mailConent = 'Dear Turbo Theaters User,
                <br/>To activate your account, visit the following link: <a href="'. $this->link .'">'. $this->link .'</a>
                <br/><br/>Best,
                <br/>The Turbo Theaters Team';
            $mail->Body = $mailConent;
            $mail->AltBody = 'To activate your account, visit the following link: <a href="'. $this->link .'">'. $this->link .'</a>Turbotheaters.com Best, The Turbo Octo Guac Team';
            
            $mail->send();
            echo 'Message has been sent';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
        
        header('location: loginPage.php'); // modified line 280 of SMTP.php to get this working
    }
}



class EmailPromotion implements EmailTemplate
{
    private $emailset;
    private $code;
    
    public function EmailPromotion($emailset, $code) {
        $this->emailset = $emailset;
        $this->code = $code;
    }
    
    public function sendEmail() {
        
        $mail = new PHPMailer(true);      
        try {
            //Server settings
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'turbooctoguac@gmail.com';                     //SMTP username
            $mail->Password   = 'turboocto5';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
            
            //Recipients
            $mail->setFrom('no-reply@turbooctoguac.com', 'Turbo Theaters');
            //$mail->addAddress('joe@example.net', 'Joe User');     //Add a recipient
            foreach ($this->emailset as $email) {
                $mail->addAddress($email);
            }
            
            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'New Promo Inbound!!!';
            $mail->Body    = 'To all movie lovers,
                <br/>There\'s a new promotion avaiable on your favorite movies!!! Use promo code <b>' .  $this->code . '</b> on your next order!
                <br/>To go to our website, visit the following link: <a href="localhost/turbo-octo-guacamole-main/loginPage.php">Turbotheaters.com</a>
                <br/><br/>Best,
                <br/>The Turbo Theaters Team';
            $mail->AltBody = 'New promotion avaiable on your favorite movies!!! Use promo code ' .  $this->code . ' on your next order!';
            
            $mail->send();
            echo 'Message has been sent';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }
}

  
class EmailCheckout implements EmailTemplate {
        private $email;
        private $confirmationNumber;
        
        public function EmailCheckout($email, $confirmationNumber) {
            $this->email = $email;
            $this->confirmationNumber = $confirmationNumber;
        }
        
        
        public function sendEmail() {
            
            $mail = new PHPMailer(true);
            try {
                //Server settings
                $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                $mail->isSMTP();                                            //Send using SMTP
                $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                $mail->Username   = 'turbooctoguac@gmail.com';                     //SMTP username
                $mail->Password   = 'turboocto5';                               //SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
                
                //Recipients
                $mail->setFrom('no-reply@turbooctoguac.com', 'Turbo Theaters');
                
                $mail->addAddress($this->email);
                
                //Content
                $mail->isHTML(true);
                $mail->Subject = 'Successful Ticket Purchase';
                $mailConent = 'Dear Turbo Theaters User,
                <br/> We have successfully processed your payment. Your confirmation number is: ' . $this->confirmationNumber . ' </b>
                <br/> If this is an error please contact customer support.
                <br/><br/>Best,
                <br/>The Turbo Theaters Team';
                $mail->Body = $mailConent;
                $mail->AltBody = 'We have successfully processed your payment. Your confirmation number is: ' . $this->confirmationNumber . '. If this is an error please contact customer support. Best,
                The Turbo Theaters Team';
                $mail->send();
                echo 'Message has been sent';
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
            
            header('location: homepage.php'); // modified line 280 of SMTP.php to get this working
        }
}
?>
