<?php
    require('database.php');
    session_start();
    

    if(isset($_POST['save'])) {
        if(!empty($_POST['Flat'])) {
			$flat = htmlspecialchars($_POST['Flat']);
            $statement = $db->prepare("UPDATE price SET Flat=? WHERE priceID=1");
		    $statement->bind_param("d",$flat);
		    $statement->execute();
        }
        if(!empty($_POST['Adult'])) {
			$adult = htmlspecialchars($_POST['Adult']);
            $statement = $db->prepare("UPDATE price SET Adult=? WHERE priceID=1");
		    $statement->bind_param("d",$adult);
		    $statement->execute();
        }
        if(!empty($_POST['Child'])) {
			$child = htmlspecialchars($_POST['Child']);
            $statement = $db->prepare("UPDATE price SET Child=? WHERE priceID=1");
		    $statement->bind_param("d",$child);
		    $statement->execute();
        }
        if(!empty($_POST['Senior'])) {
			$senior = htmlspecialchars($_POST['Senior']);
            $statement = $db->prepare("UPDATE price SET Senior=? WHERE priceID=1");
		    $statement->bind_param("d",$senior);
		    $statement->execute();
        }
        if(!empty($_POST['Tax'])) {
			$tax = htmlspecialchars($_POST['Tax']);
            $statement = $db->prepare("UPDATE price SET Tax=? WHERE priceID=1");
		    $statement->bind_param("d",$tax);
		    $statement->execute();
        }
    }
    
    $db->close();

    header('location: managePrice.php');
?>