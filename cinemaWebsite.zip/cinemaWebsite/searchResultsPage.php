

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Search Results</title>
	<link rel="preconnect" href="https://fonts.googleapis.com"> 
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
</head>
<body>


	<div class="navBar">
  <div class="leftSideNav">
    <a class="home" href="homepage.php">
      <h1>Turbo <br> Theatres</h1>
    </a>
    <a href="searchResultsPage.php" class="navBookMovie">Get Tickets</a>
  </div>

  
  
    <!-- <a href="" class="homeButton">Turbo Theatres</a> -->
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="rightSideNav">
      <form action="searchResultsPage.php" method="POST">
        <div class="searchForm">
          <div class="searchOptions">
            <input type="text" name="searchTerms" placeholder="Search...">
            <a href="searchResultsPage.php" class="aSearch">Advanced Search</a>
          </div>
          <input type="submit" name="search" value="Go">
          <!-- <p>&#x1F50D</p> -->
        </div>
      </form>

      <?php 
    if(isset($_SESSION['userID'])) {
      
      if(isset($_SESSION['admin'])) { 
        echo '<a href="adminHome.php" class="logoutButton">Admin Portal |</a>';
      }
      
      echo '<a href="editProfilePage.php" class="logoutButton">Edit Profile |</a>';
      echo '<a href="signout.php" class="logoutButton">Log Out</a>';
    } else { 
      echo '<a href="loginPage.php" class="loginButton">Log In |</a>';
      echo '<a href="registrationPage.php" class="signUpButton">Sign Up</a>';
    }?>

    </div>
  </div>
</div>

  <div class="searchForm">
    <form class="advanceSearchForm" action="searchResultsPage.php" method="POST">

      <div class="searchCheck">

        <div class="searchFields">
           <?php
          
           if(!isset($_POST['searchTerms'])){
            $searchTerms="";
          }else{
            $searchTerms = htmlspecialchars($_POST['searchTerms']);
          }
          echo "<input type='text' name='searchTerms' placeholder='Search...' value='".$searchTerms."'>";
          ?>

          <label for="genre">Genre:</label>
          <input list="genre" name="genre" <?php
            if(!empty($_POST['genre'])){
             echo "value='".$_POST['genre']."'";
            }
           ?>multiple>
            <datalist id="genre">
              <option value="Horror"></option>
              <option value="Action"></option>
              <option value="Drama"></option>
              <option value="Sci-Fi"></option>
              <option value="Comedy"></option>
              <option value="Romance"></option>
              <option value="International"></option>
              <option value="Childrens"></option>
            </datalist>
            <label for="date">Date:</label>
            <input type="date" id="date" name="date" <?php
            if(!empty($_POST['date'])){
             echo "value='".$_POST['date']."'";
            }
           ?>>

         </div>

         <div class="checkStuff">
          
            <label for="onlyShowing"><h5>Only see movies that are currently showing?</h5></label>
            <input class="checkInput" type="checkbox" name="onlyShowing" id="onlyShowing" <?php
            if(!empty($_POST['onlyShowing'])){
             echo "value='".$_POST['onlyShowing']."'";
            }
           ?>> 

         </div>     
       </div>
        <br>
      <input type="submit" name="search" value="Go">
  </form>
  </div>

  
<?php
    require('database.php');
    session_start();

	if(!empty($_POST['searchTerms'])){
    echo "<div class='resultsFor'>
    <h3>Showing results for: </h3>";
    echo "<h3>".$searchTerms."</h3>";
    if(!empty($_POST['date'])){
      echo "<h3>with date ".$_POST['date']."</h3>";
    }
    if(!empty($_POST['genre'])){
      echo "<h3>with genre ".$_POST['genre']."</h3>";
    }

		echo "<div class='allResults'>";
		$tokenTerms = strtok($searchTerms, " ");
		$foundResults = false;
		$break = false;


    $usersArray = $db->prepare("SELECT * FROM movies ORDER BY title ASC");
    $usersArray->execute();
    $results = $usersArray->get_result();

    while( $row = $results->fetch_array() ){
        $print = true;
        $searchedField = $row['title'];
        $tokenTerms = strtok($searchTerms, " ");
        while ($tokenTerms !== false){
          if(!empty($_POST['searchTerms'])){
            if(!str_contains($searchedField, $tokenTerms)){
              $print = false;
              $foundResults = true;
            }
          }
          if(!empty($_POST['genre'])){
              if(!str_contains($row['genre'], $_POST['genre'])){
                $print=false;
              }
            }/**
            if(!empty($_POST['date'])){
              if($row['date']!=$_POST['date']){
                $print=false;
              }
            }*/
            if($onlyShowing){
              $showingsArray = $db->prepare("SELECT * FROM showings WHERE movieID = ".$row['movieID']);
              $showingsArray->execute();
              $results2 = $showingsArray->get_result();
              if(! ($showingRow = $results2->fetch_array()) ){
                $print = false;
              }

            }
            if($print){
              $foundResults = true;

            echo "<div class='movie'>
            <img class='movieImg' src='".$row['image']."'>
            <div class='movieInfo'>
              <h2>".$row['title']."</h2>
            <div class='details'>
              <h4>Rating: </h4>
              <h5>".$row['rating']."</h5>
              <h4>Runtime: </h4>
              <h5>".$row['runtime']."</h5>
              <h4>Genre: </h4>
              <h5>".$row['genre']."</h5>
            </div>
            <a class='bookMovie' href='movieInfoPage.php?movieID=".$row['movieID']."'>Book Movie</a>
            </div>
            </div>";
            echo "<br>";



            break;
          }
          $tokenTerms = strtok(" ");
        }
    }

		if(!$foundResults){
			echo "No matching results found.";
		}
	}else{
		if(isset($_POST['searchTerms'])){
      $searchTerms = htmlspecialchars($_POST['searchTerms']);
    }
    echo "<div class='resultsFor'>
    <h3>Showing all movies matching filters: </h3>";
    /**
    if(!empty($_POST['date'])){
      echo "<h3>with date ".$_POST['date']."</h3>";
    }
    if(!empty($_POST['genre'])){
      echo "<h3>with genre ".$_POST['genre']."</h3>";
    }
    */

    echo "<div class='allResults'>";

    if(!empty($_POST['genre'])&&!empty($_POST['date'])){//Genre and date

      $usersArray = $db->prepare("SELECT * FROM movies WHERE genre LIKE '%".$_POST['genre']."%' AND date LIKE '".$_POST['date']."' ORDER BY title ASC");
      $filterSelect = "\nGenre and date";
    }else
    if(!empty($_POST['genre'])&&empty($_POST['date'])){//Genre only
      $usersArray = $db->prepare("SELECT * FROM movies WHERE genre LIKE '%".$_POST['genre']."%' ORDER BY title ASC;");
      $filterSelect = "Genre";
    }else
    if(empty($_POST['genre'])&&!empty($_POST['date'])){//Date only
      $usersArray = $db->prepare("SELECT * FROM movies WHERE date LIKE '%".$_POST['date']."%' ORDER BY title ASC;");
      $filterSelect = "Date";
    }else{//All empty fields
      $usersArray = $db->prepare("SELECT * FROM movies");
      $filterSelect = "All results";
    }
    
    echo $filterSelect;
    $usersArray->execute();
    $results = $usersArray->get_result();

    $foundResults = false;
    $break = false;
    while( $row = $results->fetch_array() ){//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            $showingsArray = $db->prepare("SELECT * FROM showings WHERE movieID = ".$row['movieID']);
            $showingsArray->execute();
            $showingsResults = $showingsArray->get_result();
            if($showingRow = $showingsResults->fetch_array()){
              $hasShowing = true;
              $bookingMessage = "Book Movie";
            }else{
              $hasShowing = false;
              $bookingMessage = "Coming Soon";
            }
        if(!empty($_POST['onlyShowing'])){
            if($hasShowing){//if movie has a showing...
              $foundResults = true;

              echo "<div class='movie'>
              <img class='movieImg' src='".$row['image']."'>
              <div class='movieInfo'>
                <h2>".$row['title']."</h2>
              <div class='details'>
                <h4>Rating: </h4>
                <h5>".$row['rating']."</h5>
                <h4>Runtime: </h4>
                <h5>".$row['runtime']."</h5>
                <h4>Genre: </h4>
                <h5>".$row['genre']."</h5>
              </div>
              <a class='bookMovie' href='movieInfoPage.php?movieID=".$row['movieID']."'>".$bookingMessage."</a>
              </div>
              </div>";
              echo "<br>";
            }
          }else{
            $foundResults = true;

              echo "<div class='movie'>
              <img class='movieImg' src='".$row['image']."'>
              <div class='movieInfo'>
                <h2>".$row['title']."</h2>
              <div class='details'>
                <h4>Rating: </h4>
                <h5>".$row['rating']."</h5>
                <h4>Runtime: </h4>
                <h5>".$row['runtime']."</h5>
                <h4>Genre: </h4>
                <h5>".$row['genre']."</h5>
              </div>
              <a class='bookMovie' href='movieInfoPage.php?movieID=".$row['movieID']."'>".$bookingMessage."</a>
              </div>
              </div>";
              echo "<br>";
          }

        
    }

    if(!$foundResults){
      echo "No matching results found.";
    }
	}
?>

  </div>

</body>

<style>
	* {
      margin: 0;
      padding: 0;
    }


    body {
      background-color: black;
      font-family: "Montserrat", sans-serif;
      color: white;
      padding-bottom: 80px;
    }

    .home {
      color: white;
      text-decoration: none;
    }

    .home:visited {
      color: white;
    }


    h1 {
      /*used on homepage*/
      font-style: italic;
    }

    h2 {
      /*used on homepage*/
      font-size: 40px;
     /* margin-top: 20px;
      margin-left: 40px;*/
    }

    h3 {
      /*used on homepage & reg confirmation page*/
      font-size: 20px;
      /*margin-top: 20px;*/
      /*text-align: center;*/
    }


    .navBar {
    /*padding: 20px 10px;*/
    display: inline-flex;
    flex-direction: row;
    width: 100%;
    justify-content: space-between;
    /*background: #08014a;*/

    background-image: linear-gradient(to right, black , #040194);

    /*background: #040194;*/
    color: white;
    align-items: center;
    padding-bottom: 5px;

    /*box-shadow: 0px 5px black;*/
  }

  .leftSideNav {
    padding-left: 90px;
    display: inline-flex;
    flex-direction: row;
    align-items: center;
  }

  .navBookMovie {
    text-decoration: none;
    color: white;
    margin-left: 50px;
  }


 .searchForm {
    display: inline-flex;
    flex-direction: row;
    margin-right: 50px;
    gap: 10px;
    margin-top: 10px;

  }

  .searchOptions {
    display: inline-flex;
    flex-direction: column;
    gap: 10px;
  }

  .searchForm input[type=submit] {
    height: 47px;
    width: 47px;
    font-family: "Montserrat", sans-serif; 
    border-radius: 4px;
    /*float: left;*/
  }

  .aSearch {
    font-size: 12px;
    /*margin-right: 50px;*/
    /*text-decoration: none;*/
    color: white;
    margin-left: 10px;
  }

  .aSearch:visited {
    /*text-decoration: none;*/
    color: white;
  }

  .rightSideNav {
    padding-right: 20px;
    display: inline-flex;
    flex-direction: row;
    align-items: center;
    gap: 10px;
  }

  .rightSideNav input[type=text] {
    float: right;
    padding: 4px 4px 4px 15px;
    border: none;
    /*margin-right: 50px;*/
    font-family: "Montserrat", sans-serif; 
    border-radius: 4px;
    /*background-color: #3f34d1;*/
    background-color: #292791;
    color: white;

  }

  /*.searchForm {
    display: inline-flex;
    flex-direction: row;
    margin-right: 50px;
    margin-left: 50px;
    margin-top: 30px;
    gap: 10px;
    align-items: center;

  }*/


  .advanceSearchForm {
    display: inline-flex;
    flex-direction: row;
    margin-right: 50px;
    margin-left: 50px;
    /*margin-top: 30px;*/
    /*gap: 50px;*/
    align-items: center;

  }

  .searchFields {
    display: inline-flex;
    flex-direction: row;
    margin-right: 50px;
    margin-top: 30px;
    gap: 20px;
    align-items: center;
  }

  .searchCheck {
    display: inline-flex;
    flex-direction: column;
    /*align-items: center;*/
  }

  .checkStuff {
    display: inline-flex;
    flex-direction: row;
    margin-top: 15px;
    /*margin-bottom: 10px;*/
    gap: 10px;

  }

  input[type=checkbox] {
    height: 20px;
    width: 20px;
    /*width: 200px;*/
    /*font-size: 5px;*/

  }



  .loginButton {
    float: right;
    text-decoration: none;
    color: white;

  }

  .loginButton:visited {
    color: white;
    text-decoration: none;
  }


  .signUpButton {
    float: right;
    text-decoration: none;
    color: white;
    margin-right: 10px;

  }

  .signUpButton:visited {
    color: white;
    text-decoration: none;
  }
    
.logoutButton {
	float: right;
	text-decoration: none;
	color: white;

}

.logoutButton:visited {
	color: white;
	text-decoration: none;
}
    
  input {
  height: 40px;
  width: 200px;
  font-size: 15px;
}

.resultsFor {
  display: inline-flex;
  flex-direction: column;
  align-items: baseline;
  margin-left: 40px;
  gap: 20px;
  margin-top: 30px;
  width: 100%;
}

.allResults {
  display: inline-flex;
  flex-direction: column;
  margin-top: 10px;
  gap: 30px;
  margin-left: 50px;
}


.matchName {
  display: inline-flex;
  flex-direction: column;
  margin-top: 50px;
  gap: 30px;
  /*margin-left: 150px;*/
  margin-right: 25px;
  padding-right: 25px;
  border-right: white solid 0.5px;
}


.matchGenre {
  display: inline-flex;
  flex-direction: column;
  margin-top: 50px;
  gap: 30px;
  /*margin-left: 150px;*/
  margin-right: 50px;
}

.movie {
  display: inline-flex;
  flex-direction: row;
  gap: 55px;

}

.movieImg {
  width: 225px;
  height: auto;
}

.movieInfo {
  display: inline-flex;
  flex-direction: column;
  gap: 20px;
  width: 100%;
}

.bookMovie {
    text-decoration: none;
    background-color: white;
    color: #08014a;
    text-align: center;
    padding: 10px 40px;
    border-radius: 3px;
  }

  .details {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-row-gap: 10px;
  }




</style>

</html>
