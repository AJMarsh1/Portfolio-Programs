<?php
require('database.php');
session_start();

if(isset($_POST['addMovie'])){
    $title = htmlspecialchars($_POST['title']);
    $trailer = htmlspecialchars($_POST['trailerLink']);
    $description = htmlspecialchars($_POST['description']);
    $director = htmlspecialchars($_POST['director']);
    $genre = htmlspecialchars($_POST['genre']);
    $cast = htmlspecialchars($_POST['cast']);
    $producer = htmlspecialchars($_POST['producer']);
    $review = htmlspecialchars($_POST['review']);
    $rating = htmlspecialchars($_POST['rating']);
    $image = htmlspecialchars($_POST['image']);
    $runtime = htmlspecialchars($_POST['runtime']);
    $date = htmlspecialchars($_POST['date']);

    $null = 0;
    $statement = $db->prepare("INSERT INTO movies VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
    //echo $null ', ' $title ', ' $trailer ', ' $description ', ' $director ', ' $genre ', ' $cast ', ' $producer ', ' $review ', ' $rating ', ' $image;
	$statement->bind_param("issssssssssis",$null,$title,$trailer,$description,$director,$genre,$cast,$producer,$review,$rating,$image,$runtime,$date);
	$statement->execute();
    $_SESSION['message'] = "movie added";
    header('location: manageMovies.php');
}


?>