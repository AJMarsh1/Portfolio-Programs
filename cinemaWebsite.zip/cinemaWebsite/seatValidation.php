<?php
require('database.php');
session_start();

$showingID = $_GET['showingID'];
$movieID = $_GET['movieID'];
$showroomID = $_GET['showroomID'];

$reservedSeatIDs = "";

foreach (range('A', 'E') as $seatRow){//For each row  
	for ($x = 1; $x <= 8; $x++) {       //For each seat in the row
		$seatID = $seatRow.$x."check";
		if(isset($_POST[$seatID])){
			$seatID = $seatRow.$x;
			echo $seatID;
			$reservedSeatIDs = $reservedSeatIDs.$seatID;
		
        $query = $db->prepare("INSERT INTO reservations (seatID, showroomID, reservationTime) VALUES (?,?,?)");
        $date = date("Y-m-d H:i:s");
        $query->bind_param("sis", $seatID, $showroomID, $date);
        $query->execute();

		}
	}		
}

header("location: ticketTypePage.php?reservedSeatIDs=".$reservedSeatIDs."&movieID=".$movieID."&showingID=".$showingID);

/*
MovieInfo -> Click on Showing -> Select Seats -> (Reserve Selected Seats) -> Select Ticket Types -> Go to checkout -> (Final seat availability check right as payment goes through)

//Reserve seat:
Check if reservation exists. If reservation is valid, return "Seat unavailable".
If reservation is expired, delete previous reservation, and create new reservation.*/


?>