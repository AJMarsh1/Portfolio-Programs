<?php
require('database.php');
session_start();

if(isset($_POST['addShowing'])){
    date_default_timezone_set('America/New_York');
    $title = htmlspecialchars($_POST['movieTitle']);
    $time1 = htmlspecialchars($_POST['date']);
    $time = date("Y-m-d H:i:s",strtotime($time1));
    $currentDate = date("Y-m-d H:i:s");
    if(strtotime($time) < strtotime($currentDate)) {
        //echo"$time ";
        //echo"$currentDate";
        $_SESSION['message'] = "cannot add showing to a past time";
        header('location: manageMovies.php');
    } else {
        $room = htmlspecialchars($_POST['room']);

        $movieID = 0;

        $movieCheck = $db->prepare("SELECT movieID FROM movies WHERE title = '$title'");
        $movieCheck->execute();
        $result = $movieCheck->get_result();
        while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
            foreach ($row as $r) {
                $movieID = $r;
            }
        }

        $durationCheck1 = $db->prepare("SELECT movieID FROM showings WHERE showroomID = '$room'");
        $durationCheck1->execute();
        $result = $durationCheck1->get_result();
        while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
            foreach ($row as $r) {
                $duration1 = $r;
            }
        }

        $durationCheck = $db->prepare("SELECT runtime FROM movies WHERE movieID = '$duration1'");
        $durationCheck->execute();
        $result = $durationCheck->get_result();
        while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
            foreach ($row as $r) {
                $duration = $r;
            }
        }

        $set = true;
        
        //echo " ";
        $timeCheck = $db->prepare("SELECT showDate FROM showings WHERE showroomID = '$room'");
        $timeCheck -> execute();
        $result = $timeCheck -> get_result();
        while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
            foreach ($row as $r) {
                //echo "showdate $r";
                $frame = date("Y-m-d H:i:s", strtotime("+$duration minutes", strtotime($r)));
                //echo "frame $frame";
                if($time < date("Y-m-d H:i:s", strtotime($frame))) {
                    //echo "hello";
                    $set = false;
                    $_SESSION['message'] = "time overlap";
                    header('location: manageMovies.php');
                }
                else {
                    $set = true;
                }
            }
        }
        
        if($set){
            $null = 0;
            //echo "$null ', ' $movieID ', ' $time ', ' $duration";
            $statement = $db->prepare("INSERT INTO showings VALUES (?,?,?,?)");
            $statement->bind_param("iisi", $null, $movieID, $time, $room);
            $statement->execute();
            $_SESSION['message'] = "showing added";
            header('location: manageMovies.php');
        }
    }

}


?>