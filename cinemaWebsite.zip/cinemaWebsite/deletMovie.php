<?php
	require('database.php');
    session_start();
	

	if(isset($_POST['deleteMovie'])){
        $title = htmlspecialchars($_POST['title']);
        $sql=$db->prepare("DELETE FROM movies WHERE title = ?");
        $stmt = $sql->bind_param('s', $title);
        $result = $sql->execute();
        $_SESSION['message'] = "movie deleted";
        header('location: manageMovies.php');
    }
?>