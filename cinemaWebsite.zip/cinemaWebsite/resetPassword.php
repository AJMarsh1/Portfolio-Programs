<?php
    include('emailMaker.php');

    require('database.php');
    session_start();

	if(isset($_POST['email']) && isset($_POST['submit'])){
		$email = htmlspecialchars($_POST['email']);
		
		$validInput = true;
		if(empty($email)){
		    $_SESSION['message'] = "Email field is empty. Please try again.";
		    $validInput = false;
		} else {
		    $userCheck = $db->prepare("SELECT email FROM users WHERE email=?");
		    $userCheck->bind_param("s",$email);
		    $userCheck->execute();
		    #$result = $userCheck->get_result();
		    $userValid = $userCheck->fetch();
		    
		    if(!$userValid) {
		        $validInput = false;
		        $_SESSION['message'] = "There is no account with that email.";
		    }
		    $userCheck->close();
		}
		
		
		if ($validInput) {
		  $_SESSION['message'] = '';
		  
		  // Updates database with the user's unique forgot password token
		  $uniqidStr = md5(uniqid(mt_rand()));
		  $resetPassLink = 'http://localhost/turbo-octo-guacamole-main/forgotPassword.php?fp_code=' . $uniqidStr;

		  // Consider setting token back to null after 15 minutes
		  $statement = $db->prepare("UPDATE users SET reset_password_token=? WHERE email=?");
          $statement->bind_param("ss",$uniqidStr,$email);
          $statement->execute();
		  
          $emailMaker = new EmailMaker($email, $resetPassLink);
          $emailMaker->sendForgotPassword();
          
		  $db->close();
		  
		  // Possibly add a page that displays this message for a prettier display
		  $_SESSION['message'] = 'Reset password link sent. Please check your email.';
	      header('location: resetPasswordForm.php');
		} else {
		  $_SESSION['message'] = '';
		  $db->close();
		  header('location: resetPasswordForm.php');
		}
		
	}
		
?>
