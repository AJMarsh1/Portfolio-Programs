
<?php
require('database.php');
session_start();

$showingID = $_GET['showingID'];
$movieID = $_GET['movieID'];
$reservedSeatIDs = $_GET['reservedSeatIDs'];
$tickets = strlen($reservedSeatIDs)/2;

$adult = $_POST['adult'];
$child = $_POST['child'];
$senior = $_POST['senior'];

echo $adult+$child+$senior;
echo $tickets;
if($adult+$child+$senior !== $tickets){
	$message = "Incorrect number of tickets selected, please select ".$tickets." tickets.";
	echo $message;
	//echo "ticketTypePage.php/?reservedSeatIDs=".$reservedSeatIDs."&movieID=".$movieID."&showingID=".$showingID."&message=".$message;
	header("location: ticketTypePage.php?reservedSeatIDs=".$reservedSeatIDs."&movieID=".$movieID."&showingID=".$showingID."&message=".$message);
	
}else{
	header("location: orderSummaryPage.php?reservedSeatIDs=".$reservedSeatIDs."&movieID=".$movieID."&showingID=".$showingID."&childTickets=".$child."&adultTickets=".$adult."&seniorTickets=".$senior);
}


/*
MovieInfo -> Click on Showing -> Select Seats -> (Reserve Selected Seats) -> Select Ticket Types -> Go to checkout -> (Final seat availability check right as payment goes through)

//Reserve seat:
Check if reservation exists. If reservation is valid, return "Seat unavailable".
If reservation is expired, delete previous reservation, and create new reservation.*/
die();

?>
