<?php
    require('database.php');
    session_start();
    
    $sql = "DELETE FROM showings WHERE showingID='" . $_GET['delete'] . "'";
    if (mysqli_query($db, $sql)) {
        $_SESSION['message'] = "showing deleted";
        
    } else {
        $_SESSION['message'] = "showing failed to delete";
    }
    mysqli_close($db);
    header('location: manageMovies.php');
    
?>