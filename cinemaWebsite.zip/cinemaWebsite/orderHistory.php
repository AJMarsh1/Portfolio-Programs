<?php 
    require('database.php');
    session_start();

    if(isset($_SESSION['userID'])) {
        $userID = $_SESSION['userID'];
    } else {
        header("location: loginPage.php");
    }
    
    $query = "SELECT `title`, `date`, `price`, `userID` FROM `order` WHERE userID='$userID'";
    $orders = $db->query($query);

?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>TT Order History</title> <!-- decide on name -->
  <!-- <link rel="stylesheet" href="adminStyles.css"> -->
  <link rel="preconnect" href="https://fonts.googleapis.com"> 
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
  <!-- <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,700;1,600&display=swap" rel="stylesheet"> -->

</head>
<body>

  <div class="navBar">
  <div class="leftSideNav">
    <a class="home" href="homepage.php">
      <h1>Turbo <br> Theatres</h1>
    </a>
    <a href="searchResultsPage.php" class="navBookMovie">Get Tickets</a>
  </div>

  
  
    <!-- <a href="" class="homeButton">Turbo Theatres</a> -->
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="rightSideNav">
      <form action="searchResultsPage.php" method="POST">
        <div class="searchForm">
          <div class="searchOptions">
            <input type="text" name="searchTerms" placeholder="Search...">
            <a href="searchResultsPage.php" class="aSearch">Advanced Search</a>
          </div>
          <input type="submit" name="search" value="Go">
          <!-- <p>&#x1F50D</p> -->
        </div>
      </form>

      <?php 
    if(isset($_SESSION['userID'])) {
      
      if(isset($_SESSION['admin'])) { 
        echo '<a href="adminHome.php" class="logoutButton">Admin Portal |</a>';
      }
      
      echo '<a href="editProfilePage.php" class="logoutButton">Edit Profile |</a>';
      echo '<a href="signout.php" class="logoutButton">Log Out</a>';
    } else { 
      echo '<a href="loginPage.php" class="loginButton">Log In |</a>';
      echo '<a href="registrationPage.php" class="signUpButton">Sign Up</a>';
    }?>

    </div>
  </div>

    <h3>Order History</h3>

    <div class="orderTable">
      <?php 
        if ($orders != null) {
            ?>
          <table>
    
            <tr>
              <th>Movie Title</th>
              <th>Date Purchased</th>
              <th>Total Price</th>
            </tr>
            <?php 
            foreach($orders as $order) : ?>
            <tr>
               	<td><?php echo($order['title'])?></td>
           		<td><?php echo($order['date'])?></td>
           		<td><?php echo($order['price'])?></td>
            </tr>
            <?php endforeach;
        } else {
            
            echo "<h3>No orders yet!</h3>";
            echo "<a href='homepage.php'>Check out the movies we have playing</a>";
        }
        ?>
      </table>

    </div>

</body>

<style>

  * {
      margin: 0;
      padding: 0;
    }


    body {
      background-color: black;
      font-family: "Montserrat", sans-serif;
      color: white;
      margin-bottom: 50px;
    }


    h1 {
      /*used on homepage*/
      font-style: italic;
    }

    h3 {
      /*used on homepage & reg confirmation page*/
      font-size: 30px;
      text-align: center;
      margin-top: 30px;
    }

    .home {
      color: white;
      text-decoration: none;
    }

    .home:visited {
      color: white;
    }

  .navBar {
    /*padding: 20px 10px;*/
    display: inline-flex;
    flex-direction: row;
    width: 100%;
    justify-content: space-between;
    /*background: #08014a;*/

    background-image: linear-gradient(to right, black , #040194);

    /*background: #040194;*/
    color: white;
    align-items: center;
    padding-bottom: 5px;

    /*box-shadow: 0px 5px black;*/
  }

  .leftSideNav {
    padding-left: 90px;
    display: inline-flex;
    flex-direction: row;
    align-items: center;
  }

  .navBookMovie {
    text-decoration: none;
    color: white;
    margin-left: 50px;
  }


  /*.homeButton {
    font-size: 30px;
    color: white;
    text-decoration: none;
    
  }*/

  .rightSideNav {
    padding-right: 20px;
    display: inline-flex;
    flex-direction: row;
    align-items: center;
    gap: 10px;
  }

  .rightSideNav input[type=text] {
    float: right;
    padding: 4px 4px 4px 15px;
    border: none;
    /*margin-right: 50px;*/
    font-family: "Montserrat", sans-serif; 
    border-radius: 4px;
    /*background-color: #3f34d1;*/
    background-color: #292791;
    color: white;

  }
  

  
  .searchForm {
    display: inline-flex;
    flex-direction: row;
    margin-right: 50px;
    gap: 10px;
    margin-top: 10px;

  }

  .searchOptions {
    display: inline-flex;
    flex-direction: column;
    gap: 10px;
  }

  .searchForm input[type=submit] {
    height: 47px;
    width: 47px;
    font-family: "Montserrat", sans-serif; 
    border-radius: 4px;
    /*float: left;*/
  }

  .aSearch {
    font-size: 12px;
    /*margin-right: 50px;*/
    /*text-decoration: none;*/
    color: white;
    margin-left: 10px;
  }

  .aSearch:visited {
    /*text-decoration: none;*/
    color: white;
  }

  .loginButton {
    float: right;
    text-decoration: none;
    color: white;

  }

  .loginButton:visited {
    color: white;
    text-decoration: none;
  }


  .signUpButton {
    float: right;
    text-decoration: none;
    color: white;
    margin-right: 10px;

  }

  .signUpButton:visited {
    color: white;
    text-decoration: none;
  }
    
.logoutButton {
  float: right;
  text-decoration: none;
  color: white;

}

.logoutButton:visited {
  color: white;
  text-decoration: none;
}
    
  input {
  height: 40px;
  width: 200px;
  font-size: 15px;
}


  .manageForms {
    display: inline-flex;
    flex-direction: column;
    padding: 10px 70px 10px 70px;
  }

  .fields {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    margin-bottom: 20px;

  }

  input {
      font-size: 15px;
    }

    input[type=submit] {
      font-size: 20px;
      font-family: "Montserrat", sans-serif;
      width: 100px;
    }

  .orderTable {
    display: inline-flex;
    flex-direction: column;
    width: 100%;
    align-items: center;
    margin-top: 10px;
  }

  th, td {
    text-align: center;
    border-bottom: 1px solid;
    padding: 10px;
  }
  

</style>
</html>
