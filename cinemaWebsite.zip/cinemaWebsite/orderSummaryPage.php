<?php 
    require('database.php');
    session_start();
    
    // Get order info
    $reservedSeatIDs = $_GET['reservedSeatIDs'];
    $movieID = $_GET['movieID'];
    $showingID = $_GET['showingID'];
    
    // Get movie info
    $movie = $db->prepare("SELECT * FROM movies WHERE movieID=?");
    $movie->bind_param("i", $movieID);
    $movie->execute();
    $result = $movie->get_result();
    $movie->close();
    $movie = $result->fetch_array();
    
    // Get showing info
    $showing = $db->prepare("SELECT * FROM showings WHERE showingID=?");
    $showing->bind_param("i", $showingID);
    $showing->execute();
    $result = $showing->get_result();
    $showing->close();
    $showing = $result->fetch_array();
    
    
    // Calculate pricing
    $numChildTickets = $_GET['childTickets'];
    $numAdultTickets = $_GET['adultTickets'];
    $numSeniorTickets = $_GET['seniorTickets'];
    
    $prices = $db->prepare("SELECT * FROM price");
    $prices->execute();
    $result = $prices->get_result();
    $prices = $result->fetch_array();
    $adultPrice = $prices['adult'];
    $childPrice = $prices['child'];
    $seniorPrice = $prices['senior'];
  
    $subtotal = ($numAdultTickets*$adultPrice) + ($numChildTickets*$childPrice) + ($numSeniorTickets*$seniorPrice);
    $taxRate = $prices['tax'];
    $taxes = $subtotal * $taxRate;
    $feePerTicket = $prices['flat'];
    $fees = ($numAdultTickets+$numChildTickets+$numSeniorTickets)*$feePerTicket;
    $total = $subtotal + $taxes + $fees;
    
    
    // Promotions
    $query = "SELECT code, percentOff, expiration, active FROM promotions";
    $promotions = $db->query($query);
    $currentDate = date('Y-m-d');
    $promo = 0;
    $numPromos = 0;
    if (isset($promotions) && isset($_GET['promoCode']) && $numPromos < 1) {
        foreach($promotions as $promotion) {
            if ($_GET['promoCode'] == $promotion['code'] && $promotion['expiration'] >= $currentDate &&
                $promotion['active'] == 1) {
                    $promo = $promotion['percentOff'] * 0.01;
                    $promoCode = $promotion['code'];
                    $numPromos++;
                    $_SESSION["message"] = "Successfully Added Promo";
                }
        }
        if ($promo == 0) {
            $_SESSION["message"] = "Invalid Promo Code";
        }
    }
    
    if (isset($_GET['removePromo'])) {
        $promo = 0;
    }

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Order Summary</title>
	<link rel="preconnect" href="https://fonts.googleapis.com"> 
  	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
  	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
</head>
<body>


	<div class="navBar">
  <div class="leftSideNav">
    <a class="home" href="homepage.php">
      <h1>Turbo <br> Theatres</h1>
    </a>
    <a href="searchResultsPage.php" class="navBookMovie">Get Tickets</a>
  </div>

  
  
    <!-- <a href="" class="homeButton">Turbo Theatres</a> -->
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="rightSideNav">
      <form action="searchResultsPage.php" method="POST">
        <div class="searchForm">
          <div class="searchOptions">
            <input type="text" name="searchTerms" placeholder="Search...">
            <a href="searchResultsPage.php" class="aSearch">Advanced Search</a>
          </div>
          <input type="submit" name="search" value="Go">
          <!-- <p>&#x1F50D</p> -->
        </div>
      </form>

      <?php 
    if(isset($_SESSION['userID'])) {
      
      if(isset($_SESSION['admin'])) { 
        echo '<a href="adminHome.php" class="logoutButton">Admin Portal |</a>';
      }
      
      echo '<a href="editProfilePage.php" class="logoutButton">Edit Profile |</a>';
      echo '<a href="signout.php" class="logoutButton">Log Out</a>';
    } else { 
      echo '<a href="loginPage.php" class="loginButton">Log In |</a>';
      echo '<a href="registrationPage.php" class="signUpButton">Sign Up</a>';
    }?>

    </div>
  </div>


	<div class="ticketMovieInfo">
	    <!-- <img class="bookMovieImg" src="movie6.jpg"> -->
	    <img class="bookMovieImg" src=<?php echo $movie['image'];?>>
	    <div class="bookDetails">
	    	<p class="bookMovieTitle"><?php echo $movie['title'];?></p>
	        <p><?php echo $movie['rating'];?> | <?php echo $movie['genre'];?> | <?php echo $movie['runtime'];?> minutes</p>
	        <p><?php echo $showing['showDate']?></p>
	    </div>
	</div>

	<div class="orderSummary">

		<div class="orderDetails">

			<h2>Order Summary</h2>

			<div class="ticketDetails">

				<div>

				<div class="ticket">
					<div>
					<?php 
					if ($numAdultTickets > 0) :
					    echo "<h3>Adult Ticket x" . $numAdultTickets . "</h3><br>";
					?>
					</div>
					<?php 
					echo "<h4>$" . ($adultPrice*$numAdultTickets) . "</h4>";
					endif;
					?>
				</div>

				</div>

				<div>

				<div class="ticket">
					<div>
					<?php 
					if ($numChildTickets > 0) :
					    echo "<h3>Child Ticket x" . $numChildTickets . "</h3><br>";
                    ?>
					</div>
					<?php 
					echo "<h4>$" . ($childPrice*$numChildTickets) . "</h4>";
                    endif;
					?>
				</div>


				</div>


				<div>
				
				<div class="ticket">
					<div>
					<?php 
					if ($numSeniorTickets > 0) :
					    echo "<h3>Senior Ticket x" . $numSeniorTickets . "</h3><br>";
                    ?>
					</div>
					<?php 
					echo "<h4>$" . ($seniorPrice*$numSeniorTickets) . "</h4>";
                    endif;
					?>
				</div>


				</div>


				<div>
				
				<div class="ticket">
					<div>
					<?php 
					if ($numPromos > 0) :
					    echo "<h3>" . $promoCode . "</h3>";
                    ?>
					</div>
					<?php 
					$promo = ($subtotal*$promo);
					echo "<h4>$" . $promo . "</h4>";
                    endif;
					?>
				</div>

				</div>
				

			<!-- </div> -->
		</div>

			</div>

			<div class="totalCalculation">
				<!-- <h2>Subtotal</h2> -->

				<div class="subtotals">
					<h3>Subtotal</h3>
					<h4><?php echo "$" . $subtotal;?></h4>
				</div>

				<div class="subtotals">
					<h3>Tax</h3>
					<h4><?php echo "$" . $taxes;?></h4>
				</div>
				
				<div class="subtotals">
					<h3>Fees</h3>
					<h4><?php echo "$" . $fees;?></h4>
				</div>

				<div class="subtotals">
					<h3>Promos</h3>
					<h4>$<?php echo $promo;?></h4>
				</div>

				<div class="total">

					<h2>Total</h2>
					<h2>$<?php echo $total;?></h2>

				</div>

		</div>

		</div>

		<div class="promoStuff">
		
			<label>Promo Code</label>
			
			<?php
                if(isset($_SESSION["message"])){
                    $error = $_SESSION["message"];
                    echo "<span>$error</span>";
                }
            ?>
            
			<form method="GET">
				<div class="addPromo">
				<?php 
				if ($promo == 0) { ?>
					<input type="text" name="promoCode" placeholder="Promo Code">
					<input class="checkOutSubmit" type="submit" name="submitPromo">
					<?php 
				} else {
			         ?>
			         <input class="checkOutSubmit" type="submit" name="removePromo" value="Remove Promo">
			    <?php 
				}
				?>
					<input type="hidden" name="reservedSeatIDs" value="<?php echo $reservedSeatIDs?>">
    				<input type="hidden" name="movieID" value="<?php echo $movieID?>">
    				<input type="hidden" name="showingID" value="<?php echo $showingID?>">
    				<input type="hidden" name="childTickets" value="<?php echo $numChildTickets?>">
    				<input type="hidden" name="adultTickets" value="<?php echo  $numAdultTickets?>">
    				<input type="hidden" name="seniorTickets" value="<?php echo $numSeniorTickets?>">
    			
				</div>

			</form>

			</div>

			

			<?php
		echo "<form action='cancelOrder.php?reservedSeatIDs=".$reservedSeatIDs."' method='POST'>";
		echo "<input class='checkOutSubmit' type='submit' name='cancel' value='Cancel Order'>";
    ?>
    </form>
		<?php echo "<form action='checkoutPage.php?reservedSeatIDs=".$reservedSeatIDs."' method='POST'>"?>
    		<div class="submitOrder">
    			<input class="checkOutSubmit" type="submit" name="confirm" value="Confirm Order">
    			<input class="checkOutSubmit" type="hidden" name="total" value="<?php echo $total;?>">
    			<input class="checkOutSubmit" type="hidden" name="title" value="<?php echo $movie['title'];?>">
    		</div>
		</form>


		

	</div>





</body>
<?php
    unset($_SESSION["message"]);
?>

<style>

* {
	margin: 0;
	padding: 0;
}


body {
	background-color: black;
	font-family: "Montserrat", sans-serif;
	color: white;
}

.home {
      color: white;
      text-decoration: none;
    }

    .home:visited {
      color: white;
    }


h1 {
	/*used on homepage*/
	font-style: italic;
}

h3 {
	/*used on homepage & reg confirmation page*/
	font-size: 30px;
	text-align: center;
	}


.navBar {
  /*padding: 20px 10px;*/
  display: inline-flex;
  flex-direction: row;
  width: 100%;
  justify-content: space-between;
  /*background: #08014a;*/

  background-image: linear-gradient(to right, black , #040194);

  /*background: #040194;*/
  color: white;
  align-items: center;
  padding-bottom: 5px;

  /*box-shadow: 0px 5px black;*/
}

.leftSideNav {
	padding-left: 90px;
	display: inline-flex;
  flex-direction: row;
  align-items: center;
}

.navBookMovie {
	text-decoration: none;
	color: white;
	margin-left: 50px;
}

.rightSideNav {
	padding-right: 20px;
	display: inline-flex;
  flex-direction: row;
  align-items: center;
  gap: 10px;
}

.rightSideNav input[type=text] {
	float: right;
 	padding: 4px 4px 4px 15px;
 	border: none;
 	/*margin-right: 50px;*/
	font-family: "Montserrat", sans-serif; 
	border-radius: 4px;
	/*background-color: #3f34d1;*/
	background-color: #292791;
	color: white;


}

.searchForm {
    display: inline-flex;
    flex-direction: row;
    margin-right: 50px;
    gap: 10px;
    margin-top: 10px;

  }

  .searchOptions {
    display: inline-flex;
    flex-direction: column;
    gap: 10px;
  }

  .searchForm input[type=submit] {
    height: 47px;
    width: 47px;
    font-family: "Montserrat", sans-serif; 
    border-radius: 4px;
    /*float: left;*/
  }

  .aSearch {
    font-size: 12px;
    /*margin-right: 50px;*/
    /*text-decoration: none;*/
    color: white;
    margin-left: 10px;
  }

  .aSearch:visited {
    /*text-decoration: none;*/
    color: white;
  }

input {
	height: 40px;
	width: 200px;
	font-size: 15px;
}


.loginButton {
	float: right;
	text-decoration: none;
	color: white;

}

.loginButton:visited {
	color: white;
	text-decoration: none;
}


.signUpButton {
	float: right;
	text-decoration: none;
	color: white;
	margin-right: 10px;

}

.signUpButton:visited {
	color: white;
	text-decoration: none;
}

.logoutButton {
	float: right;
	text-decoration: none;
	color: white;

}

.logoutButton:visited {
	color: white;
	text-decoration: none;
}




.ticketMovieInfo {
	display: inline-flex;
	flex-direction: row;
	gap: 30px;
	justify-content: center;
	width: 100%;
	background-color: white;
	color: black;
	padding: 30px 0px 30px 0px;

}


.bookMovieImg {
	width: 150px;
	height: auto;
}

.bookDetails {
	display: inline-flex;
	flex-direction: column;
	gap: 20px;
}

.bookMovieTitle {
	font-size: 30px;
}

.orderSummary {
	display: inline-flex;
	flex-direction: column;
	align-items: center;
	/*background-color: pink;*/
	width: 100%;
}


.orderDetails {
	display: inline-flex;
	flex-direction: column;
	/*width: 40%;*/
	/*justify-content: center;*/
	align-items: center;
	/*background-color: pink;*/
	margin-top: 20px;

}

h2 {
	font-size: 25px;
	align-self: center;
	margin-bottom: 10px;
}

h3  {
	font-size: 18px;
}

h4 {
	font-size: 15px;
	font-style: italic;
}


.ticketDetails {
	display: inline-flex;
	flex-direction: column;
	width: 100%;
	justify-content: center;
	border-width: 0px 0px 1px 0px;
	border-color: white;
	border-style: solid;
	padding-bottom: 15px;
	gap: 10px;
}

.ticket {
	display: inline-flex;
	width: 100%;
	flex-direction: row;
	justify-content: space-between;
	/*padding-left: 40px;
	padding-right: 90px;*/
}

/*.totalCalculation {
	display: inline-flex;
	flex-direction: column;
	width: 100%;
	justify-content: center;

}*/

.totalCalculation {
	display: inline-flex;
	flex-direction: column;
	width: 100%;
	justify-content: center;
	border-width: 0px 0px 1px 0px;
	border-color: white;
	border-style: solid;
	padding-bottom: 15px;
	gap: 10px;

}

.subtotals {
	display: inline-flex;
	width: 100%;
	flex-direction: row;
	justify-content: space-between;
	margin-top: 15px;
}

.total {
	display: inline-flex;
	width: 100%;
	flex-direction: row;
	margin-top: 30px;
	justify-content: space-between;
}

label {
	font-size: 18px;
	margin-top: 20px;
	/*margin-bottom: 10px;*/
}

.promoStuff {
	display: inline-flex;
	/*width: 100%;*/
	flex-direction: column;
}

.addPromo {
	display: inline-flex;
	flex-direction: row;
	align-items: center;
	gap: 20px;
	/*justify-content: space-between;*/
	margin-bottom: 30px;
}

.submitOrder {
	padding-bottom: 40px;
	padding-top: 20px;
}

/*input[type=submit] {
	padding: 50px;
	font-size: 80px;
}*/

/*input[type=submit] {
			font-size: 20px;
			font-family: "Montserrat", sans-serif;
			margin-bottom: 20px;
			margin-top: 20px;
			margin-right: 10px;
			margin-left: 5px;
		}*/

		.checkOutSubmit {
			font-size: 20px;
			font-family: "Montserrat", sans-serif;
			margin-bottom: 20px;
			margin-top: 20px;
			margin-right: 10px;
			margin-left: 5px;
		}


</style>


</html>
