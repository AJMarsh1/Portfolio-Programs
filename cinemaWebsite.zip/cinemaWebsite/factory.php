<?php
require ('database.php');

interface Ticket {

    public function sendTicket();
}

class Adult implements Ticket {
    private $type;
    private $showID;
    private $seatNumber;

    public function Adult($type, $showID, $seatNumber)
    {
        $this->type = $type;
        $this->showID = $showID;
        $this->seatNumber = $seatNumber;
    }
    public function sendTicket() {
        $statement = $db->prepare("INSERT INTO tickets VALUES (?,?,?,?)");
		$statement->bind_param("isis",$null,$type,$showID,$seatNumber);
		$statement->execute();
    }
}

class Senior implements Ticket {
    private $type;
    private $showID;
    private $seatNumber;

    public function Senior($type, $showID, $seatNumber)
    {
        $this->type = $type;
        $this->showID = $showID;
        $this->seatNumber = $seatNumber;
    }
    public function sendTicket() {
        $statement = $db->prepare("INSERT INTO tickets VALUES (?,?,?,?)");
		$statement->bind_param("isis",$null,$type,$showID,$seatNumber);
		$statement->execute();
    }
}

class Child implements Ticket {
    private $type;
    private $showID;
    private $seatNumber;

    public function Child($type, $showID, $seatNumber)
    {
        $this->type = $type;
        $this->showID = $showID;
        $this->seatNumber = $seatNumber;
    }
    public function sendTicket() {
        $statement = $db->prepare("INSERT INTO tickets VALUES (?,?,?,?)");
		$statement->bind_param("isis",$null,$type,$showID,$seatNumber);
		$statement->execute();
    }
}
