<?php
    include('emailMaker.php');

    require('database.php');
    session_start();
    
    $code = $_GET['code'];
    
    $query = "SELECT email FROM users WHERE subscribed='1'";
    $emails = $db->query($query);
    
    while ($row = $emails->fetch_assoc()) {
        $emailset[] = $row['email'];
    }
    
    $emailMaker = new EmailMaker($emailset, $code);
    $emailMaker->sendPromotion();
    
    $sql = $db->prepare("UPDATE `promotions` SET `active` = '1' WHERE `promotions`.`code` = '$code'");
    $sql->execute();
    mysqli_close($db);
    header('location: managePromotions.php');
    
?>
