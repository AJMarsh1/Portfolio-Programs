<?php 
    require('database.php');
    session_start();    
    
    if(isset($_SESSION['userID'])) {
        $userID = $_SESSION['userID'];
    } else {
        header("location: loginPage.php");
    }
    
    // Get user info
    $user = $db->prepare("SELECT email, firstName, lastName FROM users WHERE userID=" . $userID);
    $user->execute();
    $result = $user->get_result();
    $user = $result->fetch_array();
    
    
    // Get card info
    $userCheck2 = $db->prepare("SELECT cardEncryptionKey FROM securityKeys");
    $userCheck2->execute();
    $result2 = $userCheck2->get_result();
    while ($row = mysqli_fetch_array($result2, MYSQLI_NUM)) {
        foreach ($row as $r) {
            $decryption_key = $r;
        }
    }
    $cardCheck = $db->prepare("SELECT cardNumber, streetAddress, streetAddress2, city, zipCode, state, fName, lName, expMonth, expYear, cvv FROM paymentInfo WHERE ownerID = '$userID'");
    $cardCheck->execute();
    $result = $cardCheck->get_result();
    $cardCheck = $result->fetch_array();
    
    $ciphering = "AES-128-CTR";
    $iv_length = openssl_cipher_iv_length($ciphering);
    $options = 0;
    $decryption_iv = '1234567891011121';
    
    $decryption=openssl_decrypt ($cardCheck['cardNumber'], $ciphering, $decryption_key, $options, $decryption_iv);
    $displayCard = "************".substr($decryption,-4);//displays last 4 digits of card
    
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Checkout</title>
	<link rel="preconnect" href="https://fonts.googleapis.com"> 
  	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
  	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
	<!-- <link rel="stylesheet" href="checkoutPage.css"> -->
	<!-- <script defer src="checkoutScript.js"></script>-->
</head>
<body class="gradientBody">

	<div class="regLogContainer">

		<div class="regLogForm">

			<h3>Checkout</h3>

			<form name="checkoutForm" id="checkoutForm" action="orderConfirmationPage.php" method="POST"> 

			<div class="formFields">

				<div class="outerField">

					<div class="field">
						<label for="fName">First Name *</label>
						<?php
						if (isset($user['firstName'])) {
							echo $user['firstName'];
						} else {
						?>
						<input type="text" name="fName" id="fName" placeholder="First Name">
						<?php 
						} 
						?>
						<p>Error Message</p>
					</div>

					<div class="field">

						<label for="lName">Last Name *</label>
						<?php
						if (isset($user['lastName'])) {
							echo $user['lastName'];
						} else {
						?>
						<input type="text" name="lName" id="lName" placeholder="Last Name">
						<?php 
						} 
						?>
						<p>Error Message</p>
					</div>

				</div>

				<div class="field">

					<label for="email">Email *</label>
						<?php
						if (isset($user['email'])) {
							echo $user['email'];
						} else {
						?>
						<input type="text" name="email" id="email" placeholder="Email">
						<?php 
						} 
						?>
						<p>Error Message</p>
				</div>


				<div class="field">

					<label for="lName">Billing Address *</label>
					<div class="outerField">
					<?php
					if (!empty($cardCheck['streetAddress'])) {
						    echo $cardCheck['streetAddress'];
						} else {
						?>
					<input type="text" name="address1" id="address1" placeholder="Address">
					<?php 
						}
					?>
					<p>Error Message</p>
				<!-- </div> -->
				<?php
				    if (!empty($cardCheck['streetAddress2'])) {
				        echo $cardCheck['streetAddress2'];
					} else {
				?>
				<input type="text" name="address2" id="address2" placeholder="Address 2">

				<?php 
					}
				?>

				</div>

				<!-- </div> -->



				<div class="addressDetails">
				  	<div class="field">
				  	  <?php
    				    if (!empty($cardCheck['city'])) {
    				        echo $cardCheck['city'];
    					} else {
				      ?>
					  <input type="text" name="city" id="city" placeholder="City">
					  <?php 
    					}
					  ?>
					  <p>Error Message</p>
					</div>
					<div class="field">
					<?php
    				    if (!empty($cardCheck['state'])) {
    				        echo $cardCheck['state'];
    					} else {
				      ?>
					  <input type="text" name="state" id="state" placeholder="State">
					  <?php 
    					}
					  ?>
					  <p>Error Message</p>
					</div>
					<div class="field">
					<?php
    				    if (!empty($cardCheck['zipCode'])) {
    				        echo $cardCheck['zipCode'];
    					} else {
				      ?>
					  <input type="text" name="zip" id="zip" placeholder="Zip Code">
					  <?php 
    					}
					  ?>
					  <p>Error Message</p>
					</div>
				<!-- </div> -->

				</div>


				<!-- payment info -->

				<form name="checkoutForm" id="checkoutForm" action="orderConfirmationPage.php" method="POST">

					<div class="formFields">
					
					<label for="cards">Payment Info</label>
					<select id="cards" name="cards">
					  <?php
						$SQL = "SELECT * FROM paymentInfo WHERE ownerID = ".$userID.";";    
						  
						$paymentArray = $db->prepare($SQL);
						$paymentArray->execute();
						$paymentResults = $paymentArray->get_result();
						
						while($paymentRow = $paymentResults->fetch_array()){
							$userCheck2 = $db->prepare("SELECT cardEncryptionKey FROM securityKeys");
						    $userCheck2->execute();
						    $result2 = $userCheck2->get_result();
						    while ($row = mysqli_fetch_array($result2, MYSQLI_NUM)) {
						        foreach ($row as $r) {
						            $decryption_key = $r;
						        }
						    }
							$cardCheck = $db->prepare("SELECT paymentMethodID, cardNumber, streetAddress, streetAddress2, city, zipCode, state, fName, lName, expMonth, expYear, cvv FROM paymentInfo WHERE ownerID = '$userID'");
						    $cardCheck->execute();
						    $result = $cardCheck->get_result();
						    $cardCheck = $result->fetch_array();
						    
						    $ciphering = "AES-128-CTR";
						    $iv_length = openssl_cipher_iv_length($ciphering);
						    $options = 0;
						    $decryption_iv = '1234567891011121';
						    
						    $decryption=openssl_decrypt ($cardCheck['cardNumber'], $ciphering, $decryption_key, $options, $decryption_iv);
						    $last4 = substr($decryption,-4);//displays last 4 digits of card

							echo "<option value='".$cardCheck['paymentMethodID']."'>".$cardCheck['fName']."'s card ending with ".$last4." expiring ".$cardCheck['expMonth']."/".$cardCheck['expYear']."</option>";
							
						}

				      ?>
						
					</select>
				
	<!--
				<div class="field">

					<label for="cardName">Name on Card *</label>
					<?php
					//if (!empty($cardCheck['fName']) && !empty($cardCheck['lName'])) {
					   // echo $cardCheck['fName'];
					    //echo " ";
					    //echo $cardCheck['lName'];
    			    //} else {
				      ?>
					<input type="text" name="cardName" id="cardName" placeholder="Name">
					<?php 
    			    //}
					?>
					<p>Error Message</p>

				</div>

				<div class="field">
					
					<label for="cardNum">Card Number *</label>
					<?php 
        				//if (!empty($cardCheck['cardNumber'])) {
        					    //echo $displayCard;
        				//} else {
			        ?>
					<input type="text" name="cardNum" id="cardNum" placeholder="xxxx-xxxx-xxxx-xxxx">
					<?php 
    				    //}
    				?>
					<p>Error Message</p>

				</div>

				<div class="outerField">

					<div class="field">
					<?php
					//if (!empty($cardCheck['expMonth']) && !empty($cardCheck['expYear'])) {
    				        ?>
    				    <label for="expMon">Expiration Date *</label>
    				    <?php 
    				        //echo $cardCheck['expMonth'];
    				        //echo "/";
                            //echo $cardCheck['expYear'];
    					//} else {
				      ?>
						<label for="expMon">Expiration Month *</label>
						
						<input type="text" name="expMon" id="expMon" placeholder="XX">
						<?php 
    					//}
						?>
						<p>Error Message</p>

					</div>

					<div class="field">
        				<?php 
        				//if (empty($cardCheck['expYear'])) {
        				?>
						<label for="expYear">Expiration Year *</label>
						<input type="text" name="expYear" id="expYear" placeholder="XX"> 
						<?php 
        				//}
						?>
						<p>Error Message</p>

					</div>
-->
				</div>

				<div class="field">

					<label for="cvv">CVV</label>
					<?php
    				    if (!empty($cardCheck['cvv'])) {
    				    	$last1 = "**".substr($cardCheck['cvv'],-1);
    				        echo $last1;
    					} else {
				      ?>
					<input type="text" name="cvv" id="cvv" placeholder="XXX">
					<?php 
    					}
					?>
					<p>Error Message</p>

				</div>

			</div>

				



				</div>

					<div class="checkField">

						<input class="checkInput" type="checkbox" name="billAddress" id="billAddress" value="XX">      <!-- fix value -->
						<label for="billAddress">Billing address same as mailing address</label>

					</div>

				<div class="field">
					<input type="submit" name="submit" value="Checkout">
					<input type="hidden" name="email" value="<?php echo $userID?>">
					<input type="hidden" name="email" value="<?php echo $user['email']?>">
					<input type="hidden" name="total" value="<?php echo $_POST['total']?>">
				</div>

				<div class="field">
					<?php
						echo "<form action='cancelOrder.php?reservedSeatIDs=".$_GET['reservedSeatIDs']."' method='POST'>";
						echo "<input class='checkOutSubmit' type='submit' name='cancel' value='Cancel Order'>";
				    ?>
				    </form>
				</div>

			</div>
		</form>

	</div>
		
	</div>
</body>

<style>
	* {
			margin: 0;
			padding: 0;

		}


		body {
			background-color: black;
			font-family: "Montserrat", sans-serif;
			color: white;
		}

		h3 {
			/*used on homepage & reg confirmation page*/
			font-size: 30px;
			text-align: center;
		}


		.gradientBody {
			background-image: linear-gradient(to right, black , #040194);
		}


		.regLogContainer {
			display: inline-flex;
			flex-direction: column;
			align-items: center;
			text-align: center;
			color: black;
			width: 100%;
			height: 100%;

		}



		.regLogForm {
			display: inline-flex;
			flex-direction: column;
			background-color: white;
			border-radius: 10px;
			box-shadow: 5px 0px 10px #120d63, -5px -5px 10px #3a3494;
			align-items: center;
			width: 45%;
			margin-top: 40px;
			padding-top: 20px;
			padding-bottom: 60px;
			margin-bottom: 40px;

		}

		.formFields {
			display: inline-flex;
			flex-direction: column;
			gap: 20px;
			margin-top: 30px;
			align-items: flex-start;

		}

		.outerField {
			display: inline-flex;
			flex-direction: row;
			gap: 20px;
		}

		.field {
			display: inline-flex;
			flex-direction: column;
			align-items: flex-start;
			gap: 10px;
			font-size: 16px;
		}

		.paymentChoice {
			display: inline-flex;
			flex-direction: column;
		}

		.checkField {
			display: inline-flex;
			flex-direction: row;
			/*align-items: flex-start;*/
			align-items: center;
			/*font-size: 15px;*/
		}



		label {
			font-size: 20px;
		}


		input, select {
			height: 40px;
			width: 200px;
			font-size: 15px;
		}



		input[type=submit] {
			font-size: 20px;
			font-family: "Montserrat", sans-serif;
			/*margin-bottom: 20px;*/
			margin-top: 20px;
			margin-right: 10px;
			margin-left: 5px;
		}

		.checkInput {
			height: 40px;
			width: 30px;
			font-size: 15px;
		}
		
		.field p {
			visibility: hidden;
			font-size: 1px;
		}

		.field-error p {
			visibility: visible;
			font-size: 12px;
			color: red;
		}

		.field-valid input {
		    border: 2px solid green;
		}

		.field-valid p {
		    visibility: hidden;
		    font-size: 1px;
		}

</style>

</html>





