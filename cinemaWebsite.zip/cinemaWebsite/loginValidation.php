<?php
    require('database.php');
    session_start();

    if(isset($_POST['regCode'])) {
        $regCode = $_POST['regCode'];
        $query = $db->prepare("UPDATE users SET state = '1' WHERE verificationCode=?");
        $query->bind_param("s",$regCode);
        $query->execute();
        $query->close();
    }

	if(isset($_POST['submit'])){
	    $email = htmlspecialchars($_POST['email']);
		$password = htmlspecialchars($_POST['password']);
		$time = time() + (60*60*24*10);
		$validInput = true;
    	$message = "Login error:";

		//check if any field is empty, and set feedback message if form is missing a field
		$message = "";
		if(empty($email)){
			$message.= 'Email is required. Please try again. ';
			$validInput = false;
		}
		if(empty($password)){
			$message.= 'Username is required. Please try again. ';
			$validInput = false;
		} 

		
		if($validInput){
			$userCheck = $db->prepare("SELECT password FROM users WHERE email = '$email'");
				$userCheck->execute();
				$result = $userCheck->get_result();
				while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
					foreach ($row as $r) {
					$pw = $r;
					}
				}
			$verify = password_verify($password, $pw);
			if ($verify) {
				$userCheck = $db->prepare("SELECT state FROM users WHERE email = '$email'");
				$userCheck->execute();
				$result = $userCheck->get_result();
				while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
					foreach ($row as $r) {
					$state = $r;
					}
				}
				// active account
				if($state == 1) {
					$userCheck = $db->prepare("SELECT userID FROM users WHERE email = '$email'");
					$userCheck->execute();
					$result = $userCheck->get_result();
					while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
						foreach ($row as $r) {
						$userID = $r;
						}
					}
					//START SESSION FOR USER WITH GIVEN USERID
					if (isset($_SESSION['userID'])) {
						unset($_SESSION['userID']);
					}
					$_SESSION['userID'] = $userID;

					// check if account is admin
					$userCheck = $db->prepare("SELECT isAdmin FROM users WHERE email = '$email'");
					$userCheck->execute();
					$result = $userCheck->get_result();
					while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
						foreach ($row as $r) {
						$admin = $r;
						}
					}
					if ($admin == 1) {
						if (isset($_SESSION['admin'])) {
							unset($_SESSION['admin']);
						}
						$_SESSION['admin'] = $admin;
					}

					//remember me cookie
					$time = time() + (60*60*24*10);
					if(isset($_POST['rememberMe'])){
						setcookie('mycookie', TRUE, time() + 3600);
						setcookie("save_email", $email, $time, "/");
						setcookie("save_password", $password, $time, "/");
					} else {
						if (isset($_COOKIE['mycookie'])) {
							unset($_COOKIE['mycookie']);
							setcookie('mycookie', '', time() - 3600, '/'); // empty value and old timestamp
						}
						if (isset($_COOKIE['save_email'])) {
							unset($_COOKIE['save_email']);
							setcookie('save_email', '', time() - 3600, '/'); // empty value and old timestamp
						}
						if (isset($_COOKIE['save_password'])) {
							unset($_COOKIE['save_password']);
							setcookie('save_password', '', time() - 3600, '/'); // empty value and old timestamp
						}
					}
					header('location: homepage.php');
				// inactive account
				} else if ($state == 0) {
					$_SESSION['message'] = "Account not activated, please check your email for a link to activate your account.";
					header('location: loginPage.php');
				// suspended account	
				} else if ($state == 2) {
					$_SESSION['message'] = "Account suspended, please contact customer service if you think this is a mistake.";
					header('location: loginPage.php');
				}

			}else{
				$_SESSION['message'] = "Invalid login, please retry.";
				header('location: loginPage.php');
			}
		}
	}

	//If login was complete/valid, user will have been redirected to homepage. Else, the login page below will load, this time with a feedback message detailing their issue.

	?>





