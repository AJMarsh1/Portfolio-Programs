<?php 
    require('database.php');
    session_start();
    $query = "SELECT * FROM price";
    $prices = $db->query($query);
?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>TT Manage Prices</title> <!-- decide on name -->
  <!-- <link rel="stylesheet" href="adminStyles.css"> -->
  <link rel="preconnect" href="https://fonts.googleapis.com"> 
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
  <!-- <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,700;1,600&display=swap" rel="stylesheet"> -->

</head>
<body>

  <div class="navBar">
  <div class="leftSideNav">
    <a class="home" href="homepage.php">
      <h1>Turbo <br> Theatres</h1>
    </a>
    <a href="adminHome.php" class="navBookMovie">Admin view</a>
  </div>
  
  <div class="rightSideNav">
      <a href="signout.php" class="logoutButton">Log Out  |</a>
      <a href="editProfilePage.php" class="logoutButton">View Profile</a>
    </div>
  </div>



  <div class="adminBody">

    <h3>Manage Prices</h3>

      <div class="adminTools">


        <h3>Change Prices</h3>

        <form class="manageForms" action = "changePrice.php" method="post">

          <div class="fields">

            <label for="fname">Flat:</label>
            <input type="text" id="Flat" name="Flat">
            <label for="fname"> Adult:</label>
            <input type="text" id="Adult" name="Adult">
            <label for="fname"> Child:</label>
            <input type="text" id="Child" name="Child">
            <label for="fname"> Senior:</label>
            <input type="text" id="Senior" name="Senior">
            <label for="fname"> Tax:</label>
            <input type="text" id="Tax" name="Tax"> 
          </div>

          <input type="submit" name="save" value="Submit">
          
        </form>

      </div>
    </div>


    <h3>Current Prices</h3>

    <div class="promoTable">
      
      <table>

        <tr>
          <th>Flat Rate</th>
          <th>Adult</th>
          <th>Child</th>
          <th>Senior</th>
          <th>Tax</th>
        </tr>
        
        <?php 
        foreach($prices as $price) : ?>
            <tr>
            	<td><?php echo($price['flat'])?></td>
          		<td><?php echo($price['adult'])?></td>
          		<td><?php echo($price['child'])?></td>
          		<td><?php echo($price['senior'])?></td>
              <td><?php echo($price['tax'])?></td>
            </tr>
        <?php endforeach;?>
      
      </table>

    </div>

</body>

<style>

  * {
      margin: 0;
      padding: 0;
    }


    body {
      background-color: black;
      font-family: "Montserrat", sans-serif;
      color: white;
      margin-bottom: 50px;
    }


    h1 {
      /*used on homepage*/
      font-style: italic;
    }

    h3 {
      /*used on homepage & reg confirmation page*/
      font-size: 30px;
      text-align: center;
      margin-top: 30px;
    }

    .home {
      color: white;
      text-decoration: none;
    }

    .home:visited {
      color: white;
    }

  .navBar {
      display: inline-flex;
      flex-direction: row;
      width: 100%;
      justify-content: space-between;
      background: #040194;
      color: white;
      align-items: center;
      padding-bottom: 5px;
    }

    .leftSideNav {
      padding-left: 90px;
      display: inline-flex;
      flex-direction: row;
      align-items: center;
    }

    .rightSideNav {
      padding-right: 20px;
      display: inline-flex;
      flex-direction: row;
      align-items: center;
      gap: 10px;
    }

    .navBookMovie {
      text-decoration: none;
      color: white;
      margin-left: 50px;
    }


  .logoutButton {
    float: right;
    text-decoration: none;
    color: white;

  }

  .logoutButton:visited {
    color: white;
    text-decoration: none;
  }



  .adminTools {
    display: grid;

    justify-content: center;
    /*margin-bottom: 20px;*/
  }

  .manageForms {
    display: inline-flex;
    flex-direction: column;
    padding: 10px 70px 10px 70px;
  }

  .fields {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    margin-bottom: 20px;

  }

  input {
      font-size: 15px;
    }

    input[type=submit] {
      font-size: 20px;
      font-family: "Montserrat", sans-serif;
      width: 100px;
    }

  .promoTable {
    display: inline-flex;
    flex-direction: column;
    width: 100%;
    align-items: center;
    margin-top: 10px;
  }

  th, td {
    text-align: center;
    border-bottom: 1px solid;
    padding: 10px;
  }
  

</style>
</html>











