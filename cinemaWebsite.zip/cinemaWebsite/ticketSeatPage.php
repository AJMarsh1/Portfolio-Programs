<?php
    require('database.php');
    session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Choose Your Seat</title>
	<link rel="preconnect" href="https://fonts.googleapis.com"> 
  	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
  	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
</head>
<body>

	<div class="navBar">
	  <div class="leftSideNav">
	    <a class="home" href="homepage.php">
	      <h1>Turbo <br> Theatres</h1>
	    </a>
	    <a href="searchResultsPage.php" class="navBookMovie">Get Tickets</a>
	  </div>

	  
	  
	    <!-- <a href="" class="homeButton">Turbo Theatres</a> -->
	    <!-- Right-sided navbar links. Hide them on small screens -->
	    <div class="rightSideNav">
      <form action="searchResultsPage.php" method="POST">
        <div class="searchForm">
          <div class="searchOptions">
            <input type="text" name="searchTerms" placeholder="Search...">
            <a href="searchResultsPage.php" class="aSearch">Advanced Search</a>
          </div>
          <input type="submit" name="search" value="Go">
          <!-- <p>&#x1F50D</p> -->
        </div>
      </form>

      <?php 
    if(isset($_SESSION['userID'])) {
      
      if(isset($_SESSION['admin'])) { 
        echo '<a href="adminHome.php" class="logoutButton">Admin Portal |</a>';
      }
      
      echo '<a href="editProfilePage.php" class="logoutButton">Edit Profile |</a>';
      echo '<a href="signout.php" class="logoutButton">Log Out</a>';
    } else { 
      echo '<a href="loginPage.php" class="loginButton">Log In |</a>';
      echo '<a href="registrationPage.php" class="signUpButton">Sign Up</a>';
    }?>

    </div>
  </div>
</div>


	<?php

		if(isset($_GET['movieID'])&&isset($_GET['showingID'])){
			$showingID = $_GET['showingID'];
			$movieID = $_GET['movieID'];

			$usersArray = $db->prepare("SELECT * FROM movies WHERE movieID = ".$movieID);
			$usersArray->execute();
			$results = $usersArray->get_result();
			$results = $results->fetch_array();
			echo "
			<div class='ticketMovieInfo'>
			    <img class='bookMovieImg' src='".$results['image']."'>
			    <div class='bookDetails'>
			    	<p class='bookMovieTitle'>".$results['title']."</p>
			        <p>".$results['rating']." | ".$results['genre']." | ".$results['runtime']. "mins</p>";
			$showingsArray = $db->prepare("SELECT * FROM showings WHERE showingID = ".$showingID);
			$showingsArray->execute();
			$results = $showingsArray->get_result();
			$showingsResults = $results->fetch_array();
			$timestamp = $showingsResults['showDate'];
			$splitTimeStamp = explode(" ",$timestamp);//SRC: https://stackoverflow.com/questions/14457250/php-splitting-the-date-and-time-within-a-timestamp-value-in-mysql
			$date = $splitTimeStamp[0];
			$time = $splitTimeStamp[1];
			$time =  date('g:i a', strtotime($time));

			echo "
			        <p>".$date."</p>
			        <p>".$time."</p>
			    </div>
			</div>
			";
		}
	?>

	<div class="seatSelection">
		
		<div class="seatKey">
			<div class="key">
				<h5>Available</h5>
				<div class="availSeat"></div>
			</div>

			<div class="key">
				<h5>Selected</h5>
				<div class="selectSeat"></div>
			</div>

			<div class="key">
				<h5>Booked</h5>
				<div class="bookedSeat"></div>
			</div>

		</div>

		<h3>Select Seats</h3>

		<div class="diagram">

			<h4>Screen</h4>
<?php
			echo "<form class='seatForm' action='seatValidation.php?showingID=".$showingID."&movieID=".$movieID."&showroomID=".$showingsResults['showroomID']."' method='POST'>

				<div class='allSeats'>";
				
				$SQL = "DELETE FROM reservations WHERE reservationTime < (NOW() - INTERVAL 15 MINUTE)";
				$db->query($SQL);

			 foreach (range('A', 'E') as $seatRow){//For each row  
					echo "<div class='row'>";

						echo "<h5>".$seatRow."</h5>";
						for ($x = 1; $x <= 8; $x++) {       //For each seat in the row
							  			$SQL = "SELECT * FROM tickets WHERE showingID = ".$showingID." AND seatNumber = '".$seatRow.$x."';";
							  			$ticketsArray = $db->prepare($SQL);
				              $ticketsArray->execute();
				              $ticketsResults = $ticketsArray->get_result();


				              $SQL = "SELECT * FROM reservations WHERE seatID = '".$seatRow.$x."' AND showroomID = '".$showingsResults['showroomID']."';";
							  			$resArray = $db->prepare($SQL);
				              $resArray->execute();
				              $resResults = $resArray->get_result();
				              /*
											$time = $r;
										$frame = date("Y-m-d H:i:s", strtotime("+ 15 minutes", strtotime($time)));
										//echo "frame $frame";
										if($date > date("Y-m-d H:i:s", strtotime($frame))) {
											//echo "hello";
											$sql=$db->prepare("DELETE FROM reservations WHERE reservationTime = ?");
        									$stmt = $sql->bind_param('s', $time);
        									$result = $sql->execute();

											*/

				              if ($resRow = $resResults->fetch_array()||$ticketsRow = $ticketsResults->fetch_array()) {//if there's a reservation or ticket for seat
												echo "<label class='seat'>
												<input type='checkbox'  onclick='return false;' disabled='disabled' name='".$seatRow.$x."check'> 
												<span class='newBookedSeatCheck'>".$seatRow.$x."</span>
												</label>";
								      }else{//If there is no  reservation or ticket stored for this seat
				                echo "<label class='seat'>
												<input type='checkbox' name='".$seatRow.$x."check'> 
												<span class='newCheck'>".$seatRow.$x."</span>
												</label>";
											}
								      
						
						
						}
					echo "</div>";
					}
				?>
					

				</div>

				<div class="checkoutButton">
					<input type="submit" value="Check Out">
				</div>
			</form>

		</div>
	</div>

</body>



<style>

	* {
		margin: 0;
		padding: 0;
	}


	body {
		background-color: black;
		font-family: "Montserrat", sans-serif;
		color: white;
	}

	.home {
      color: white;
      text-decoration: none;
    }

    .home:visited {
      color: white;
    }

	h1 {
		font-style: italic;
	}


	h3 {
	/*used on homepage & reg confirmation page*/
	font-size: 30px;
	text-align: center;
	}


	.navBar {
  /*padding: 20px 10px;*/
  display: inline-flex;
  flex-direction: row;
  width: 100%;
  justify-content: space-between;
  /*background: #08014a;*/

  background-image: linear-gradient(to right, black , #040194);

  /*background: #040194;*/
  color: white;
  align-items: center;
  padding-bottom: 5px;

  /*box-shadow: 0px 5px black;*/
}

.leftSideNav {
	padding-left: 90px;
	display: inline-flex;
  flex-direction: row;
  align-items: center;
}

.navBookMovie {
	text-decoration: none;
	color: white;
	margin-left: 50px;
}

.rightSideNav {
    padding-right: 20px;
    display: inline-flex;
    flex-direction: row;
    align-items: center;
    gap: 10px;
  }

  .rightSideNav input[type=text] {
    float: right;
    padding: 4px 4px 4px 15px;
    border: none;
    /*margin-right: 50px;*/
    font-family: "Montserrat", sans-serif; 
    border-radius: 4px;
    /*background-color: #3f34d1;*/
    background-color: #292791;
    color: white;

  }

.searchForm {
    display: inline-flex;
    flex-direction: row;
    margin-right: 50px;
    gap: 10px;
    margin-top: 10px;

  }

  .searchOptions {
    display: inline-flex;
    flex-direction: column;
    gap: 10px;
  }

  .searchForm input[type=submit] {
    height: 47px;
    width: 47px;
    font-family: "Montserrat", sans-serif; 
    border-radius: 4px;
    /*float: left;*/
  }

  .aSearch {
    font-size: 12px;
    /*margin-right: 50px;*/
    /*text-decoration: none;*/
    color: white;
    margin-left: 10px;
  }

  .aSearch:visited {
    /*text-decoration: none;*/
    color: white;
  }


.loginButton {
	float: right;
	text-decoration: none;
	color: white;

}

.loginButton:visited {
	color: white;
	text-decoration: none;
}


.signUpButton {
	float: right;
	text-decoration: none;
	color: white;
	margin-right: 10px;

}

.signUpButton:visited {
	color: white;
	text-decoration: none;
}

.logoutButton {
	float: right;
	text-decoration: none;
	color: white;

}

.logoutButton:visited {
	color: white;
	text-decoration: none;
}


	.ticketMovieInfo {
	display: inline-flex;
	flex-direction: row;
	gap: 30px;
	justify-content: center;
	width: 100%;
	background-color: white;
	color: black;
	padding: 30px 0px 30px 0px;

}


	.bookMovieImg {
		width: 150px;
		height: auto;
	}

	.bookDetails {
		display: inline-flex;
		flex-direction: column;
		gap: 20px;
	}

	.bookMovieTitle {
		font-size: 30px;
	}

	.seatKey {
		display: inline-flex;
		flex-direction: row;
		width: 100%;
		/*justify-content: center;*/
		gap: 20px;
		margin-left: 30px;
		margin-top: 10px;
	}

	.key {
		display: inline-flex;
		flex-direction: row;
		align-items: center;
		gap: 10px;
	}

	.availSeat {
	  	height: 30px;
	 	width: 40px;
	  	background-color:  #4946C9;
	  	padding-top: 10px;
	  	border-radius: 5px;
	}

	.selectSeat {
	  	height: 30px;
	 	width: 40px;
	  	/*background-color:  #FF0000;*/
	  	background-color: #bf2304;
	  	padding-top: 10px;
	  	border-radius: 5px;
	}


	.bookedSeat {
	  	height: 30px;
	 	width: 40px;
	  	background-color: #b3b5b4;
	  	padding-top: 10px;
	  	border-radius: 5px;
	}


	.seatSelection {
		display: inline-flex;
		flex-direction: column;
		width: 100%;
		justify-content: center;
		gap: 30px;
		padding-bottom: 100px;
		padding-top: 30px;

	}

	.diagram {
		display: inline-flex;
		flex-direction: column;
		justify-content: center;
		width: 100%;
		gap: 20px;
	}

	.seatForm {

		display: inline-flex;
		flex-direction: column;
		justify-content: center;
		width: 100%;

	}

	h4 {
		text-align: center;
		font-size: 22px;
		/*border: 2px solid white;*/
	}

	.allSeats {
		display: inline-flex;
		flex-direction: column;
		width: 100%;
		gap: 80px;
	}

	.row {
		display: inline-flex;
		flex-direction: row;
		justify-content: center;
		width: 100%;
		gap: 100px;

	}



	.seat {
	  display: block;
	  position: relative;
	  padding-left: 35px;
	  margin-bottom: 12px;
	  cursor: pointer;
	  font-size: 15px;
	  -webkit-user-select: none;
	  -moz-user-select: none;
	  -ms-user-select: none;
	  user-select: none;
	  text-align: center;
	}

	h5 {
		font-size: 20px;
	}

	.seat input {
		position: absolute;
	  	opacity: 0;
	  	cursor: pointer;
	  	height: 0;
	  	width: 0;
	}

	.newCheck {
		position: absolute;
	  	top: 0;
	  	left: 0;
	  	height: 30px;
	 	width: 40px;
	  	background-color:  #4946C9;
	  	padding-top: 10px;
	  	border-radius: 5px;
	}

	.newBookedSeatCheck {
		position: absolute;
	  	top: 0;
	  	left: 0;
	  	height: 30px;
	 	width: 40px;
	  	/*background-color:  #FF0000;*/
	  	background-color: #b3b5b4;
	  	color: black;
	  	padding-top: 10px;
	  	border-radius: 5px;
	}

	.seat input:checked ~ .newCheck {
		background-color: #bf2304;
		/*color: black;*/
	}

	.checkoutButton {
		margin-top: 60px;
		display: inline-flex;
		flex-direction: column;
		align-items: flex-start;
		/*width: 100%;*/
		justify-content: center;
		align-self: center;
	}

	.seatForm {
		align-items: center;
	}

	/*input[type=submit] {
		align-self: center;
		width: 100px;
		font-size: 90px;
	}*/

	input {
	height: 40px;
	width: 200px;
	font-size: 15px;
}

	input[type=submit] {
			font-size: 20px;
			font-family: "Montserrat", sans-serif;
			margin-bottom: 20px;
			text-align: center;
		}





	/*resources for check stuff
	https://www.w3schools.com/howto/tryit.asp?filename=tryhow_css_custom_checkbox*/



	
</style>


</html>


