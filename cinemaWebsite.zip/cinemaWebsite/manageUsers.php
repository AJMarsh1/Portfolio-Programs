<?php 
    require('database.php');
    session_start();

    $query = "SELECT userID, email, firstName, lastName, state, isAdmin FROM users";
    $users = $db->query($query);

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>TT Manage Users</title> <!-- decide on name -->
  <!-- <link rel="stylesheet" href="adminStyles.css"> -->
  <link rel="preconnect" href="https://fonts.googleapis.com"> 
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
  <!-- <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,700;1,600&display=swap" rel="stylesheet"> -->

</head>
<body>

  <div class="navBar">
  <div class="leftSideNav">
    <a class="home" href="homepage.php">
      <h1>Turbo <br> Theatres</h1>
    </a>
    <a href="adminHome.php" class="navBookMovie">Admin view</a>
  </div>
  
  <div class="rightSideNav">
      <a href="signout.php" class="logoutButton">Log Out  |</a>
      <a href="editProfilePage.php" class="logoutButton">View Profile</a>
    </div>
  </div>



  <div class="adminBody">
  
    <h3>Manage Users</h3>

      <div class="adminTools">


        <h3>Add Admin</h3>

		<?php 
			if (isset($_SESSION['message'])) {
				echo $_SESSION['message'];
				unset($_SESSION['message']);
			}
	    ?>

        <form class="manageForms" action = "addAdmin.php" method="post">

          <div class="fields">

			<label for="fname"> First Name:</label>
            <input type="text" id="fName" name="fName">
            <label for="lname"> Last Name:</label>
            <input type="text" id="lName" name="lName">
            <label for="fname">Email:</label>
            <input type="email" id="adminEmail" name="adminEmail">
            <label for="fname"> Password:</label>
            <input type="text" id="password" name="password">
            <label for="lname"> Confirm Password:</label>
            <input type="text" id="confirmPassword" name="confirmPassword">
          </div>

          <input type="submit" name="submit" value="Submit">
          
        </form>

      </div>
    </div>


<h3>Administrators</h3>

    <div class="promoTable">
      
      <table>

        <tr>
          <th>User ID</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Email</th>
          <th>State</th>
          <th>Activate</th>
          <th>Suspend</th>
        </tr>
        
        <?php 
        foreach($users as $user) : ?>
            <tr>
            <?php if ($user['isAdmin'] == 1) :?>
            	<td><?php echo($user['userID'])?></td>
          		<td><?php echo($user['firstName'])?></td>
          		<td><?php echo($user['lastName'])?></td>
          		<td><?php echo($user['email'])?></td>
          		<td><?php echo($user['state'])?></td>
          		<td>
          			<a href = "activateUser.php?userID=<?php echo $user['userID']; ?>">
                		<button id="activate" name="activate" value="activate">Activate</button>
              		</a>
    			</td>
    			<td>
          			<a href = "suspendUser.php?userID=<?php echo $user['userID']; ?>">
                		<button id="suspend" name="suspend">Suspend</button>
              		</a>
    			</td>
          	<?php endif; ?>
            </tr>
        <?php endforeach;?>
      
      </table>

    </div>


    <h3>Active Users</h3>

    <div class="promoTable">
      
      <table>

        <tr>
          <th>User ID</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Email</th>
          <th>State</th>
          <th>Suspend</th>
          <th>Edit User</th>
        </tr>
        
        <?php 
        foreach($users as $user) : ?>
            <tr>
            <?php if ($user['state'] == 1 && $user['isAdmin'] != 1) :?>
            	<td><?php echo($user['userID'])?></td>
          		<td><?php echo($user['firstName'])?></td>
          		<td><?php echo($user['lastName'])?></td>
          		<td><?php echo($user['email'])?></td>
          		<td><?php echo($user['state'])?></td>
          		<td>
          			<a href = "suspendUser.php?userID=<?php echo $user['userID']; ?>">
                		<button id="suspend" name="suspend">Suspend</button>
              		</a>
    			</td>
    			<td>
          			<a href = "editUser.php?userID=<?php echo $user['userID']; ?>">
                		<button id="edit" name="edit">Edit</button>
              		</a>
    			</td>
          	<?php endif; ?>
            </tr>
        <?php endforeach;?>
      
      </table>

    </div>

    <h3>Inactive Users</h3>

    <div class="promoTable">
      
      <table>

        <tr>
          <th>User ID</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Email</th>
          <th>State</th>
          <th>Activate</th>
          <th>Edit User</th>
        </tr>
        
        <?php 
        foreach($users as $user) : ?>
            <tr>
            <?php if ($user['state'] == 0 && $user['isAdmin'] != 1) :?>
            	<td><?php echo($user['userID'])?></td>
          		<td><?php echo($user['firstName'])?></td>
          		<td><?php echo($user['lastName'])?></td>
          		<td><?php echo($user['email'])?></td>
          		<td><?php echo($user['state'])?></td>
          		<td>
          			<a href = "activateUser.php?userID=<?php echo $user['userID']; ?>">
                		<button id="activate" name="activate">Activate</button>
              		</a>
    			</td>
    			<td>
          			<a href = "editUser.php?userID=<?php echo $user['userID']; ?>">
                		<button id="edit" name="edit">Edit</button>
              		</a>
    			</td>
          	<?php endif; ?>
            </tr>
        <?php endforeach;?>
      
      </table>

    </div>
    
    <h3>Suspended Users</h3>

    <div class="promoTable">
      
      <table>

        <tr>
          <th>User ID</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Email</th>
          <th>State</th>
          <th>Activate</th>
          <th>Edit User</th>
        </tr>
        
        <?php 
        foreach($users as $user) : ?>
            <tr>
            <?php if ($user['state'] == 2  && $user['isAdmin'] != 1) :?>
            	<td><?php echo($user['userID'])?></td>
          		<td><?php echo($user['firstName'])?></td>
          		<td><?php echo($user['lastName'])?></td>
          		<td><?php echo($user['email'])?></td>
          		<td><?php echo($user['state'])?></td>
          		<td>
          			<a href = "activateUser.php?userID=<?php echo $user['userID']; ?>">
                		<button id="activate" name="activate">Activate</button>
              		</a>
    			</td>
    			<td>
          			<a href = "editUser.php?userID=<?php echo $user['userID']; ?>">
                		<button id="edit" name="edit">Edit</button>
              		</a>
    			</td>
          	<?php endif; ?>
            </tr>
        <?php endforeach;?>
      
      </table>

    </div>
    


</body>

<style>

  * {
      margin: 0;
      padding: 0;
    }


    body {
      background-color: black;
      font-family: "Montserrat", sans-serif;
      color: white;
      margin-bottom: 50px;
    }


    h1 {
      /*used on homepage*/
      font-style: italic;
    }

    h3 {
      /*used on homepage & reg confirmation page*/
      font-size: 30px;
      text-align: center;
      margin-top: 30px;
    }


    .home {
      color: white;
      text-decoration: none;
    }

    .home:visited {
      color: white;
    }

  .navBar {
      display: inline-flex;
      flex-direction: row;
      width: 100%;
      justify-content: space-between;
      background: #040194;
      color: white;
      align-items: center;
      padding-bottom: 5px;
    }

    .leftSideNav {
      padding-left: 90px;
      display: inline-flex;
      flex-direction: row;
      align-items: center;
    }

    .rightSideNav {
      padding-right: 20px;
      display: inline-flex;
      flex-direction: row;
      align-items: center;
      gap: 10px;
    }

    .navBookMovie {
      text-decoration: none;
      color: white;
      margin-left: 50px;
    }


  .logoutButton {
    float: right;
    text-decoration: none;
    color: white;

  }

  .logoutButton:visited {
    color: white;
    text-decoration: none;
  }



  .adminTools {
    display: grid;

    justify-content: center;
    /*margin-bottom: 20px;*/
  }

  .manageForms {
    display: inline-flex;
    flex-direction: column;
    padding: 10px 70px 10px 70px;
  }

  .fields {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    margin-bottom: 20px;

  }

  input {
      font-size: 15px;
    }

    input[type=submit] {
      font-size: 20px;
      font-family: "Montserrat", sans-serif;
      width: 100px;
    }

  .promoTable {
    display: inline-flex;
    flex-direction: column;
    width: 100%;
    align-items: center;
    margin-top: 10px;
  }

  th, td {
    text-align: center;
    border-bottom: 1px solid;
    padding: 10px;
  }
  

</style>
</html>
