<?php
    require('database.php');
    session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Turbo Register</title>
	<!-- <link rel="stylesheet" href="registration.css"> -->
  	<link rel="preconnect" href="https://fonts.googleapis.com"> 
  	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
  	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
	
</head>
<body class="gradientBody">
	<div class="regLogContainer">
		<div class="regLogForm">

			<h3>Register for Turbo Theatres</h3>

			<form name="registrationForm" id="registrationForm" action="registrationValidation.php" method="POST">
				<div class="formFields">
					<div class="horizontalFields">
						<div class="outerField">
							<label for="fName">First Name *</label>
							<div class="field">
								<!-- <label for="fName">First Name *</label> -->
								<input type="text" name="fName" id="fName" placeholder="First Name" value="<?php if(isset($_COOKIE["fname"])) { echo $_COOKIE["fname"]; } ?>" required>
								<?php 
									if (isset($_SESSION['fnameFail'])) {
										echo $_SESSION['fnameFail'];
										unset($_SESSION['fnameFail']);
									}
								?>
							</div>
						</div>
						<div class="outerField">
							<label for="lName">Last Name *</label>
							<div class="field">
								<input type="text" name="lName" id="lName" placeholder="Last Name" value="<?php if(isset($_COOKIE["lname"])) { echo $_COOKIE["lname"]; } ?>" required>
								<?php 
									if (isset($_SESSION['lnameFail'])) {
										echo $_SESSION['lnameFail'];
										unset($_SESSION['lnameFail']);
									}
								?>
							</div>
						</div>
					</div>

					<div class="outerField">
						<label for="email">Email *</label>
						<div class="field">
							<!-- <label for="email">Email *</label> -->
							<input type="email" name="email" id="email" placeholder="Email" value="<?php if(isset($_COOKIE["email"])) { echo $_COOKIE["email"]; } ?>" required>
							<?php 
								if (isset($_SESSION['emailAlready'])) {
									echo $_SESSION['emailAlready'];
									unset($_SESSION['emailAlready']);
								}
							?>
						</div>
					</div>

					<div class="horizontalFields">
						<div class="outerField">
							<label for="password">Password *</label>
							<div class="field">
								<input type="password" name="password" id="password" placeholder="Password" required>
								<?php 
									if (isset($_SESSION['passwordFail'])) {
										echo $_SESSION['passwordFail'];
										unset($_SESSION['passwordFail']);
									}
								?>
							</div>
						</div>

						<div class="outerField">
							<label for="confirmPassword">Confirm Password *</label>
							<div class="field">
								<input type="password" name="confirmPassword" id="confirmPassword" placeholder="Password" required>
								<?php 
									if (isset($_SESSION['confirmPasswordFail'])) {
										echo $_SESSION['confirmPasswordFail'];
										unset($_SESSION['confirmPasswordFail']);
									}
								?>
							</div>
						</div>
					</div>

					<div class="outerField">
						<label for="mailingAddress">Mailing Address</label>
						<div class="field">
							<input type="text" name="mailAddress1" id="address1" placeholder="Address" value="<?php if(isset($_COOKIE["mailAddress1"])) { echo $_COOKIE["mailAddress1"]; } ?>" required>
							<input type="text" name="mailAddress2" id="address2" placeholder="Address 2">
						</div>
					
						<div class="field">
							<div class="addressDetails">
								<input type="text" name="mailCity" id="city" placeholder="City" value="<?php if(isset($_COOKIE["mailCity"])) { echo $_COOKIE["mailCity"]; } ?>" required>
								<?php 
									if (isset($_SESSION['mailCityFail'])) {
										echo $_SESSION['mailCityFail'];
										unset($_SESSION['mailCityFail']);
									}
								?>
							</div>
						</div>
						<div class="field">
							<div class="addressDetails">
								<input type="text" name="mailState" id="state" placeholder="State" value="<?php if(isset($_COOKIE["mailState"])) { echo $_COOKIE["mailState"]; } ?>" required>   <!-- could make dropdown to look nicer -->
								<?php 
									if (isset($_SESSION['mailStateFail'])) {
										echo $_SESSION['mailStateFail'];
										unset($_SESSION['mailStateFail']);
									}
								?>
							</div>
						</div>
							
						<div class="field">
							<input type="text" name="mailZip" id="zip" placeholder="Zip Code" value="<?php if(isset($_COOKIE["mailZip"])) { echo $_COOKIE["mailZip"]; } ?>" required> 
							<?php 
								if (isset($_SESSION['mailZipFail'])) {
									echo $_SESSION['mailZipFail'];
									unset($_SESSION['mailZipFail']);
								}
							?>
						</div>
					</div>

					<!-- payment info -->
					<div class="outerField">
						<label for="cardName">Name on Card</label>
						<div class="field">
							<input type="text" name="cardName" id="cardName" placeholder="Name" value="<?php if(isset($_COOKIE["cardName"])) { echo $_COOKIE["cardName"]; } ?>">
							<?php 
								if (isset($_SESSION['cardNameFail'])) {
									echo $_SESSION['cardNameFail'];
									unset($_SESSION['cardNameFail']);
								}
							?>
						</div>
					</div>

					<div class="outerField">
						<label for="cardNum">Card Number</label>
						<div class="field">
							<input type="text" name="cardNum" id="cardNum" placeholder="xxxx-xxxx-xxxx-xxxx" value="<?php if(isset($_COOKIE["cardNum"])) { echo $_COOKIE["cardNum"]; } ?>">
							<?php
								if (isset($_SESSION['emptyCard'])) {
									echo $_SESSION['emptyCard'];
									unset($_SESSION['emptyCard']);
								} else if (isset($_SESSION['cardNumFail'])) {
									echo $_SESSION['cardNumFail'];
									unset($_SESSION['cardNumFail']);
								}
							?>
						</div>
					</div>

					<div class="horizontalFields">
						<div class="outerField">
							<label for="expMon">Expiration Month</label>
							<div class="field">
								<input type="text" name="expMon" id="expMon" placeholder="XX" value="<?php if(isset($_COOKIE["expMonth"])) { echo $_COOKIE["expMonth"]; } ?>">
								<?php
									if (isset($_SESSION['emptyMonth'])) {
										echo $_SESSION['emptyMonth'];
										unset($_SESSION['emptyMonth']);
									} else if (isset($_SESSION['expMonthFail'])) {
										echo $_SESSION['expMonthFail'];
										unset($_SESSION['expMonthFail']);
									}
								?>
							</div>
						</div>
						<div class="outerField">
							<label for="expYear">Expiration Year</label>
							<div class="field">		
								<input type="text" name="expYear" id="expYear" placeholder="XXXX" value="<?php if(isset($_COOKIE["expYear"])) { echo $_COOKIE["expYear"]; } ?>">       <!-- make dates prettier -->
								<?php
									if (isset($_SESSION['emptyYear'])) {
										echo $_SESSION['emptyYear'];
										unset($_SESSION['emptyYear']);
									} else if (isset($_SESSION['expYearFail'])) {
										echo $_SESSION['expYearFail'];
										unset($_SESSION['expYearFail']);
									}
								?>
							</div>
						</div>
					</div>

					<div class="outerField">
						<label for="cvv">CVV</label>
						<div class="field">
							<input type="text" name="cvv" id="cvv" placeholder="XXX">
							<?php
								if (isset($_SESSION['emptyCvv'])) {
									echo $_SESSION['emptyCvv'];
									unset($_SESSION['emptyCvv']);
								} else if (isset($_SESSION['cvvFail'])) {
									echo $_SESSION['cvvFail'];
									unset($_SESSION['cvvFail']);
								}
							?>
						</div>
					</div>

					<div class="outerField">
						<label for="billingAddress">Billing Address</label>
						<div class="field">
							<input type="text" name="address1" id="address1" placeholder="Address" value="<?php if(isset($_COOKIE["address1"])) { echo $_COOKIE["address1"]; } ?>">
							<?php
								if (isset($_SESSION['emptyAddress1'])) {
									echo $_SESSION['emptyAddress1'];
									unset($_SESSION['emptyAddress1']);
								} else if (isset($_SESSION['address1Fail'])) {
									echo $_SESSION['address1Fail'];
									unset($_SESSION['address1Fail']);
								}
							?>
							<input type="text" name="address2" id="address2" placeholder="Address 2" value="<?php if(isset($_COOKIE["address2"])) { echo $_COOKIE["address2"]; } ?>">
						</div>
						<div class="field">
							<div class="addressDetails">
								<input type="text" name="city" id="city" placeholder="City" value="<?php if(isset($_COOKIE["city"])) { echo $_COOKIE["city"]; } ?>">
								<?php
								if (isset($_SESSION['emptyCity'])) {
									echo $_SESSION['emptyCity'];
									unset($_SESSION['emptyCity']);
								} else if (isset($_SESSION['cityFail'])) {
									echo $_SESSION['cityFail'];
									unset($_SESSION['cityFail']);
								}
							?>
							</div>
						</div>
						<div class="field">
							<div class="addressDetails">
								<input type="text" name="state" id="state" placeholder="State" value="<?php if(isset($_COOKIE["state"])) { echo $_COOKIE["state"]; } ?>">   <!-- could make dropdown to look nicer -->
								<?php
								if (isset($_SESSION['emptyState'])) {
									echo $_SESSION['emptyState'];
									unset($_SESSION['emptyState']);
								} else if (isset($_SESSION['stateFail'])) {
									echo $_SESSION['stateFail'];
									unset($_SESSION['stateFail']);
								}
							?>
							</div>
						</div>
							
						<div class="field">
							<input type="text" name="zip" id="zip" placeholder="Zip Code" value="<?php if(isset($_COOKIE["state"])) { echo $_COOKIE["state"]; } ?>"> 
							<?php
								if (isset($_SESSION['emptyZip'])) {
									echo $_SESSION['emptyZip'];
									unset($_SESSION['emptyZip']);
								} else if (isset($_SESSION['zipFail'])) {
									echo $_SESSION['zipFail'];
									unset($_SESSION['zipFail']);
								}
							?>
						</div>
					</div>

					<div class="checkField">
						<input class="checkInput" type="checkbox" name="billAddress" id="billAddress" value="1">      <!-- fix value -->
						<label for="billAddress">Billing address same as mailing address</label>
					</div>

					<div class="checkField">
						<input class="checkInput" type="checkbox" name="promotions" id="promotions" value="1">      <!-- fix value -->
						<label for="promotions">Sign up for promotions</label>
					</div>

					<div class="field">
						<input type="submit" name="submit" id="submit" value="Register">
						<h4>Already have an account? <a href="loginPage.php">Login</a></h4>
						<a class="homeL" href="homepage.php" class="homeButton">Home</a>
					</div>
				</div>	
			</form>
		</div>
	</div>
</body>

<style>
	* {
			margin: 0;
			padding: 0;
		}


		body {
			background-color: black;
			font-family: "Montserrat", sans-serif;
			color: white;
		}

		h3 {
			/*used on homepage & reg confirmation page*/
			font-size: 30px;
			text-align: center;
		}


		.gradientBody {
			background-image: linear-gradient(to right, black , #040194);
			
		}

		h4 {
			margin-bottom: 15px;
			margin-top: 10px;
		}


		.regLogContainer {
			display: inline-flex;
			flex-direction: column;
			align-items: center;
			text-align: center;
			color: black;
			width: 100%;
			height: 100%;

		}



		.regLogForm {
			display: inline-flex;
			flex-direction: column;
			background-color: white;
			border-radius: 10px;
			box-shadow: 5px 0px 10px #120d63, -5px -5px 10px #3a3494;
			align-items: center;
			width: 45%;
			margin-top: 40px;
			padding-top: 20px;
			padding-bottom: 60px;
			margin-bottom: 40px;

		}


		.formFields {
			display: inline-flex;
			flex-direction: column;
			gap: 20px;
			margin-top: 30px;
			align-items: flex-start;
		}

		.horizontalFields {
			display: inline-flex;
			flex-direction: row;
			gap: 10px;
		}

		.outerField {
			display: inline-flex;
			flex-direction: column;
			align-items: flex-start;
			font-size: 20px;
			gap: 5px;
		}

		/*.field {
			display: inline-flex;
			flex-direction: column;
			align-items: flex-start;
			gap: 10px;
			font-size: 20px;
		}*/


		.checkField {
			display: inline-flex;
			flex-direction: row;
			align-items: center;
			font-size: 18px;
		}


		input {
			height: 40px;
			width: 200px;
			font-size: 15px;
		}

		input[type=submit] {
			font-size: 20px;
			font-family: "Montserrat", sans-serif;
			margin-bottom: 20px;
			margin-top: 20px;
		}

		.forgot {
			display: inline-flex;
			flex-direction: column;
			width: 100%;
			align-items: center;
			gap: 10px;
			font-size: 15px;
		}


		.checkInput {
			height: 25px;
			width: 25px;
			margin-right: 10px;
		}


		.field p {
			visibility: hidden;
			font-size: 1px;
			color: red;


		}

		.field-error p {
			visibility: visible;
			font-size: 12px;
			color: red;

			/*margin: 0px 0px 0px 0px;*/
		}

		.field-valid p {
			visibility: hidden;
			font-size: 1px;

		}

		.field-valid input {
			border: 2px solid green;
		}

		#billAddress-checked {
			visibility: hidden;

		}

		/*billing address needs to be hidden when billing same as mailing checkbox is checked*/
</style>

</html>


