<?php 
include ("facade.php");

class EmailMaker {
    private $emailForgotPassword;
    private $emailConfirmation;
    private $emailPromotion;
    private $emailCheckout;
    
    public function EmailMaker($email, $link) {
        $this->emailForgotPassword = new EmailForgotPassword($email, $link);
        $this->emailConfirmation = new EmailConfirmation($email, $link);
        $this->emailPromotion = new EmailPromotion($email, $link);
        $this->emailCheckout = new EmailCheckout($email, $link);
    }
    
    public function sendForgotPassword() {
        $this->emailForgotPassword->sendEmail();
    }
    
    public function sendConfirmationEmail() {
        $this->emailConfirmation->sendEmail();
    }
    
    public function sendPromotion() {
        $this->emailPromotion->sendEmail();
    }
    
    public function sendCheckoutEmail() {
        $this->emailCheckout->sendEmail();
    }
}

?>
