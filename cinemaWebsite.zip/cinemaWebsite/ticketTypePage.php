<?php
    require('database.php');
    session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Choose Ticket Type</title>
	<!-- <link rel="stylesheet" href="projectStyleSheet.css"> -->
  	<link rel="preconnect" href="https://fonts.googleapis.com"> 
  	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
  	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
</head>
<body>

	<div class="navBar">
	  <div class="leftSideNav">
	    <a class="home" href="homepage.php">
	      <h1>Turbo <br> Theatres</h1>
	    </a>
	    <a href="searchResultsPage.php" class="navBookMovie">Get Tickets</a>
	  </div>

	  
	  
	    <!-- <a href="" class="homeButton">Turbo Theatres</a> -->
	    <!-- Right-sided navbar links. Hide them on small screens -->
	    <div class="rightSideNav">
      <form action="searchResultsPage.php" method="POST">
        <div class="searchForm">
          <div class="searchOptions">
            <input type="text" name="searchTerms" placeholder="Search...">
            <a href="searchResultsPage.php" class="aSearch">Advanced Search</a>
          </div>
          <input type="submit" name="search" value="Go">
          <!-- <p>&#x1F50D</p> -->
        </div>
      </form>

      <?php 
    if(isset($_SESSION['userID'])) {
      
      if(isset($_SESSION['admin'])) { 
        echo '<a href="adminHome.php" class="logoutButton">Admin Portal |</a>';
      }
      
      echo '<a href="editProfilePage.php" class="logoutButton">Edit Profile |</a>';
      echo '<a href="signout.php" class="logoutButton">Log Out</a>';
    } else { 
      echo '<a href="loginPage.php" class="loginButton">Log In |</a>';
      echo '<a href="registrationPage.php" class="signUpButton">Sign Up</a>';
    }?>

    </div>
  </div>
</div>

<?php
		
		if(isset($_GET['movieID'])&&isset($_GET['showingID'])){
			$showingID = $_GET['showingID'];
			$movieID = $_GET['movieID'];
			$reservedSeatIDs = $_GET['reservedSeatIDs'];
			$tickets = strlen($reservedSeatIDs)/2;

			$usersArray = $db->prepare("SELECT * FROM movies WHERE movieID = ".$movieID);
			$usersArray->execute();
			$results = $usersArray->get_result();
			$results = $results->fetch_array();
			echo "
			<div class='ticketMovieInfo'>
			    <img class='bookMovieImg' src='".$results['image']."'>
			    <div class='bookDetails'>
			    	<p class='bookMovieTitle'>".$results['title']."</p>
			        <p>".$results['rating']." | ".$results['genre']." | ".$results['runtime']. "mins</p>";
			$usersArray = $db->prepare("SELECT * FROM showings WHERE showingID = ".$showingID);
			$usersArray->execute();
			$results = $usersArray->get_result();
			$results = $results->fetch_array();
			$timestamp = $results['showDate'];
			$splitTimeStamp = explode(" ",$timestamp);//SRC: https://stackoverflow.com/questions/14457250/php-splitting-the-date-and-time-within-a-timestamp-value-in-mysql
			$date = $splitTimeStamp[0];
			$time = $splitTimeStamp[1];
			$time =  date('g:i a', strtotime($time));

			echo "
			        <p>".$date."</p>
			        <p>".$time."</p>
			    </div>
			</div>
			";
		}
	?>

	<div class="ticketSelection">
		<h3>Select Tickets</h3>
		<?php
		if(isset($_GET['message'])){
			echo "<h4>".$_GET['message']."</h4>";
		}
//header("location: ticketTypePage.php?reservedSeatIDs=".$reservedSeatIDs."&movieID=".$movieID."&showingID=".$showingID);

/*
MovieInfo -> Click on Showing -> Select Seats -> (Reserve Selected Seats) -> Select Ticket Types -> Go to checkout -> (Final seat availability check right as payment goes through)

//Reserve seat:
Check if reservation exists. If reservation is valid, return "Seat unavailable".
If reservation is expired, delete previous reservation, and create new reservation.*/





						echo "<form name='ticketTypeForm' method='POST' action='ticketTypeValidation.php?showingID=".$showingID."&movieID=".$movieID."&reservedSeatIDs=".$reservedSeatIDs."'>"
					?>
		 


			<div class="ticketFields">

			

				<div class="field">

					<label for="adult">Adult</label>
					<input type="number" name="adult" id="adult" value = "0" placeholder="0">

				</div>

				<div class="field">

					<label for="child">Child</label>
					<input type="number" name="child" id="child" value = "0" placeholder="0">

				</div>

				<div class="field">

					<label for="senior">Senior</label>
					<input type="number" name="senior" id="senior" value = "0" placeholder="0">

				</div>

				<div class="field">
					<input class="formSub" type='submit' value='Next'>
				</div>
				<!--
				<div class="field">
					<input type="submit" value="Next">
				</div>-->
			
		</form>
	</div>

</body>

<style>


* {
	margin: 0;
	padding: 0;
}


body {
	background-color: black;
	font-family: "Montserrat", sans-serif;
	color: white;
}

.home {
      color: white;
      text-decoration: none;
    }

    .home:visited {
      color: white;
    }


h1 {
	/*used on homepage*/
	font-style: italic;
}

h3 {
	/*used on homepage & reg confirmation page*/
	font-size: 30px;
	text-align: center;
	}


  .navBar {
    /*padding: 20px 10px;*/
    display: inline-flex;
    flex-direction: row;
    width: 100%;
    justify-content: space-between;
    /*background: #08014a;*/

    background-image: linear-gradient(to right, black , #040194);

    /*background: #040194;*/
    color: white;
    align-items: center;
    padding-bottom: 5px;

    /*box-shadow: 0px 5px black;*/
  }

  .leftSideNav {
    padding-left: 90px;
    display: inline-flex;
    flex-direction: row;
    align-items: center;
  }

  .navBookMovie {
    text-decoration: none;
    color: white;
    margin-left: 50px;
  }

.rightSideNav {
    padding-right: 20px;
    display: inline-flex;
    flex-direction: row;
    align-items: center;
    gap: 10px;
  }

  .rightSideNav input[type=text] {
    float: right;
    padding: 4px 4px 4px 15px;
    border: none;
    /*margin-right: 50px;*/
    font-family: "Montserrat", sans-serif; 
    border-radius: 4px;
    /*background-color: #3f34d1;*/
    background-color: #292791;
    color: white;

  }

.searchForm {
    display: inline-flex;
    flex-direction: row;
    margin-right: 50px;
    gap: 10px;
    margin-top: 10px;

  }

  .searchOptions {
    display: inline-flex;
    flex-direction: column;
    gap: 10px;
  }

  .searchForm input[type=submit] {
    height: 47px;
    width: 47px;
    font-family: "Montserrat", sans-serif; 
    border-radius: 4px;
    font-size: 15px;
    /*float: left;*/
  }

  .aSearch {
    font-size: 12px;
    /*margin-right: 50px;*/
    /*text-decoration: none;*/
    color: white;
    margin-left: 10px;
  }

  .aSearch:visited {
    /*text-decoration: none;*/
    color: white;
  }


.loginButton {
	float: right;
	text-decoration: none;
	color: white;

}

.loginButton:visited {
	color: white;
	text-decoration: none;
}


.signUpButton {
	float: right;
	text-decoration: none;
	color: white;
	margin-right: 10px;

}

.signUpButton:visited {
	color: white;
	text-decoration: none;
}

.logoutButton {
	float: right;
	text-decoration: none;
	color: white;

}

.logoutButton:visited {
	color: white;
	text-decoration: none;
}

	input {
	height: 40px;
	width: 200px;
	font-size: 15px;
}





.ticketMovieInfo {
	display: inline-flex;
	flex-direction: row;
	gap: 30px;
	justify-content: center;
	width: 100%;
	background-color: white;
	color: black;
	padding: 30px 0px 30px 0px;

}


.bookMovieImg {
	width: 150px;
	height: auto;
}

.bookDetails {
	display: inline-flex;
	flex-direction: column;
	gap: 20px;
}

.bookMovieTitle {
	font-size: 30px;
}



.ticketSelection {
	display: inline-flex;
	flex-direction: column;
	width: 100%;
	justify-content: center;
	margin-bottom: 40px;
	margin-top: 20px;


}




/*#ticketTypeForm {
	text-align: center;
}*/






.ticketFields {
	display: inline-flex;
	flex-direction: column;
	gap: 20px;
	margin-top: 30px;
	width: 100%;
	align-items: flex-start;
	justify-content: center;
}

.field {
	display: inline-flex;
	flex-direction: column;
	align-items: flex-start;
	gap: 10px;
	font-size: 20px;
	align-self: center;
}





/*input[type=submit] {
		align-self: center;
		padding: 20px;
		width: 100px;
		font-size: 90px;
		margin-left: 52px;
		margin-bottom: 50px;
	}*/




	input[type=submit] {
			font-size: 20px;
			font-family: "Montserrat", sans-serif;
			margin-bottom: 20px;
			/*margin-top: 20px;*/
		}

		.formSub {
			margin-top: 20px;
		}
	
</style>


</html>








