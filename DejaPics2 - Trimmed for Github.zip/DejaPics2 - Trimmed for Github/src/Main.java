import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Scanner;

public class Main {


    private static ArrayList<BufferedImage> miniImages = new ArrayList<>();
    private static float[] imagesWeights;
    private static String targetImgURL = "\\targetPic";
    private static String sourceImagesURL = "\\sourceImages";
    private static String destinationURL = "\\resultImage";
    private static String projectDirectory = "p";
    private static int[][] segmentIDMap;
    private static BufferedImage targetImg;
    private static final float weightIncreaseFactor = 67;//These two numbers determine the scaling and recovery rates of the weights which handicap selection of images which have recently been used
    private static final float weightDecreaseFactor = 1.5F;
    private static final int duplicateSegmentSpacing = 9;//Sets the ideal space you want between segments having duplicate images. Increasing this will decrease result likeness to the original, possibly exponentially.
    private static final int scaleFactor = 100;//The main adjustable parameter, determines how many images will be used to recreate the original. The total number of patches will be equal to the square of this number

    public static void main(String[] args){
        Scanner console = new Scanner(System.in);
        System.out.println("Welcome to DejaPics! Please enter a project name:\n");
        projectDirectory = projectDirectory+console.next();
        sourceImagesURL = projectDirectory+sourceImagesURL;
        targetImgURL = projectDirectory+targetImgURL;
        destinationURL = projectDirectory+destinationURL;
        System.out.println(sourceImagesURL);
        System.out.println(targetImgURL);
        System.out.println(destinationURL);
        try {
            createDirectories(new String[] {targetImgURL,sourceImagesURL,destinationURL});
            tellUserToPlaceFiles(console);
            miniImages = loadImagesFromFiles(getFiles(sourceImagesURL,"png","jpg","jpeg"));
            imagesWeights = new float[miniImages.size()];
            Arrays.fill(imagesWeights, 1.0F);
            File targetImgPath = getFiles(targetImgURL,"png","jpg","jpeg").get(0);
            targetImg = ImageIO.read(targetImgPath);
            BufferedImage result = patchwork();
            //displayImage(result);
            String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
            ImageIO.write(result,"jpg",new File("resultImage"+timeStamp+".jpg"));//destinationURL+"\\resultImage.png"));
        } catch (IOException e) {
            e.printStackTrace();
            crash();
        }

    }

    public static void crash(){

    }

    public static void tellUserToPlaceFiles(Scanner console){
        System.out.println("Please place source images in the subfolder "+sourceImagesURL+", and the image you want to recreate in "+targetImgURL);
        System.out.println("When finished, type something and hit enter");
        String done = console.next();
    }

    public static void createDirectories(String[] directories){//example of a usable string: /subfolder/subfolder2
        for(int i = 0;i<directories.length;i++){
            System.out.println(directories[i]);
            try {
                new File(directories[i]).mkdirs();
            }catch(Exception e){
                e.printStackTrace();
            }

        }
    }

    public static BufferedImage patchwork() throws IOException {
        BufferedImage result= resizeImg(targetImg,targetImg.getWidth()*scaleFactor,targetImg.getHeight()*scaleFactor);//resizes the image we want to recreate to the result size
        scaleMiniImages();//scales all mini images to a uniform size
        int widthIterationsNeeded = result.getWidth()/miniImages.get(0).getWidth();
        int heightIterationsNeeded = result.getHeight()/miniImages.get(0).getHeight();
        segmentIDMap = new int[widthIterationsNeeded][heightIterationsNeeded];
        int patchWidth = (result.getWidth()-(result.getWidth()%widthIterationsNeeded))/widthIterationsNeeded;
        int patchHeight = (result.getHeight()-(result.getHeight()%heightIterationsNeeded))/heightIterationsNeeded;
        int totalIterationsNeeded = widthIterationsNeeded*heightIterationsNeeded;
        int progressCounter = 0;
        int bestImgIndex = 0;
        for(int x = 0;x<widthIterationsNeeded; x++){
            for(int y = 0;y<heightIterationsNeeded; y++){
                progressCounter++;
                System.out.println("Patching "+ progressCounter + "/"+totalIterationsNeeded);//((x+1)*(y+1)) + "/"+totalIterationsNeeded);
                BufferedImage sourceSegment = copyImgSection(result,x*patchWidth,y*patchHeight,patchWidth,patchHeight);
                bestImgIndex = findBestImage(sourceSegment,miniImages,x,y);
                segmentIDMap[x][y] = bestImgIndex+1;
                BufferedImage bestSegment = miniImages.get(bestImgIndex);
                result = pasteSegmentToImg(result,bestSegment,x*patchWidth,y*patchHeight,patchWidth,patchHeight);
            }
        }

        return result;
    }

    public static double distanceToNearestOccurance(int id, int posX, int posY){
        double distance = 999999999;
        double newDistance = 0;
        for(int x = 0; x<segmentIDMap.length; x++){
            for(int y = 0; y<segmentIDMap[x].length; y++) {
                if(segmentIDMap[x][y]==id) {
                    newDistance = Math.sqrt((y-posY)*(y-posY) + (x-posX)*(x-posX));
                    if(newDistance<distance){
                        distance=newDistance;
                    }
                }
            }
        }
        //distance = sqrt((y2 - y1) * (y2 - y1) + (x2 - x1) * (x2 - x1))
        return distance;
    }

    public static int comparePics(BufferedImage img1, BufferedImage img2) {
        int score = 0;
        int rgb1;
        int rgb2;
        int blueSimilarity;
        int redSimilarity;
        int greenSimilarity;
        for (int x = 0; x < img1.getWidth(); x++) {
            for (int y = 0; y < img1.getHeight(); y++) {
                rgb1 = img1.getRGB(x, y);
                rgb2 = img2.getRGB(x, y);
                redSimilarity = 100 - (100 * (Math.abs(((rgb1 >> 16) & 0x000000FF) - ((rgb2 >> 16) & 0x000000FF))) / 255);//redSimilarity = 100 - % diff in red values
                greenSimilarity = 100 - (100 * (Math.abs(((rgb1 >> 8) & 0x000000FF) - ((rgb2 >> 8) & 0x000000FF))) / 255);//greenSimilarity = 100 - % diff in green values
                blueSimilarity = 100 - (100 * (Math.abs(((rgb1) & 0x000000FF) - ((rgb2) & 0x000000FF))) / 255);//blueSimilarity = 100 - % diff in blue values
                score = score + redSimilarity + greenSimilarity + blueSimilarity;
            }
        }
        return score;
    }

    public static int findBestImage(BufferedImage exampleImg, ArrayList<BufferedImage> images, int x, int y){
        int bestImgIndex = 0;
        //BufferedImage bestImage = null;
        int bestScore = 0;
        int newScore;
        double rawDistWeight;
        double distWeight = 1;
        BufferedImage newImage;
        //System.out.println("****************");
        for(int i = 0; i<images.size(); i++) {
            newImage = images.get(i);
            newScore = comparePics(exampleImg, newImage);
            distWeight = distanceToNearestOccurance(i+1,x,y);
            rawDistWeight=distWeight;
            distWeight = duplicateSegmentSpacing-distWeight;//the constant the distance is subtracted from is the distance you ideally want between duplicate tiles
            if(distWeight<1){
                distWeight=1;
            }
            newScore = (int)(newScore/distWeight);
            if (newScore > bestScore) {
                //System.out.println("Raw DistWeight for "+x+","+y+" is "+rawDistWeight);
                //System.out.println("DistWeight for "+x+","+y+" is "+distWeight);
                bestImgIndex = i;
                bestScore = newScore;
                //bestImage = newImage;
            }
        }
        //incrementWeight(bestImgIndex);
        //decrementWeights();
        return bestImgIndex;
    }

    public static void incrementWeight(int i){
        imagesWeights[i] = imagesWeights[i]*weightIncreaseFactor;
    }

    public static void decrementWeights(){
        float newWeight = 1;

        for(int i = 0;i<imagesWeights.length;i++){
            newWeight = ((imagesWeights[i]-1)/weightDecreaseFactor)+1;
            imagesWeights[i]=newWeight;
        }
    }

    public static BufferedImage copyImgSection(BufferedImage sourceImg, int xStart, int yStart, int width, int height){
        //System.out.println(xStart+","+yStart+","+width+","+height);
        BufferedImage resultSegment = new BufferedImage(width,height,sourceImg.getType());
        int xHolder = 0;
        int yHolder = 0;
        //System.out.println(width+","+xStart+","+sourceImg.getWidth());
        for(int x = 0; x<width;x++){
            for(int y = 0; y<height;y++){
                xHolder = x+xStart;
                yHolder = y+yStart;
                //System.out.println("Accessing pixel "+xHolder+","+yHolder+" of sourceImg with dimensions "+sourceImg.getWidth()+","+sourceImg.getHeight());
                resultSegment.setRGB(x,y,sourceImg.getRGB(xStart+x,yStart+y));
            }
        }
        return resultSegment;
    }

    public static BufferedImage pasteSegmentToImg(BufferedImage mainImg, BufferedImage segment, int xStart, int yStart, int width, int height){
        for(int x = 0;x<width;x++){
            for(int y = 0;y<height;y++){
                mainImg.setRGB(xStart+x,yStart+y,segment.getRGB(x,y));//copy corresponding pixel from the segment to the main image
            }
        }
        return mainImg;
    }

    public static ArrayList<File> getFiles(String URL, String ftype1, String ftype2, String ftype3){
        System.out.println("Getfiles searching :"+URL+":");
        File folder = new File(URL);
        ArrayList<File> files = new ArrayList<File>();
        for(File file : folder.listFiles()){
            if(file.getName().endsWith(ftype1) || file.getName().endsWith(ftype2) || file.getName().endsWith(ftype3)){
                files.add(file);
            }
        }
        System.out.println(files.size()+" files of type "+ftype1+","+ftype2+", or "+ftype3+" found in "+URL);
        for(int i = 0;i<files.size();i++){
            System.out.println(files.get(i));
        }
        return files;
    }

    public static ArrayList<BufferedImage> loadImagesFromFiles(ArrayList<File> files){
        ArrayList<BufferedImage> images = new ArrayList<>();
        for(int i = 0; i<files.size(); i++){
            try {
                images.add(ImageIO.read(files.get(i)));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return images;
    }

    public static void scaleMiniImages(){
        for(int i = 0; i<miniImages.size();i++){
            miniImages.set(i,resizeImg(miniImages.get(i),targetImg.getWidth(),targetImg.getHeight()));
        }
    }

    public static BufferedImage resizeImg(BufferedImage img, int newWidth, int newHeight){
        BufferedImage resizedImg = new BufferedImage(newWidth, newHeight, img.getType());
        Graphics2D g = resizedImg.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(img, 0, 0, newWidth, newHeight, 0, 0, img.getWidth(), img.getHeight(), null);
        g.dispose();
        return resizedImg;
    }

    public static void displayImage(BufferedImage img) throws IOException {
        ImageIcon icon=new ImageIcon(img);
        JFrame frame=new JFrame();
        frame.setLayout(new FlowLayout());
        frame.setSize(200,300);
        JLabel lbl=new JLabel();
        lbl.setIcon(icon);
        frame.add(lbl);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}