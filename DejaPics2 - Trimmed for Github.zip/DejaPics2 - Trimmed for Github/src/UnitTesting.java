import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

public class UnitTesting {

    public static float[] imagesWeights;
    public static float weightIncreaseFactor = 4;
    public static float weightDecreaseFactor = 2;
    private static int[][] segmentIDMap;

    public static void main(String[] args){
        /*imagesWeights = new float[1];
        Arrays.fill(imagesWeights,1.0F);
        for(int i = 0;i<imagesWeights.length;i++){
            incrementWeight(i);
        }
        progressWeightDecay();
        */
        segmentIDMap = new int[5][5];
        segmentIDMap[2][2]=2;
        System.out.println("Distance: "+distanceToNearestOccurance(2,4,4));
    }

    public static double distanceToNearestOccurance(int id, int posX, int posY){
        double distance = 999999999;
        double newDistance = 0;
        for(int x = 0; x<segmentIDMap.length; x++){
            for(int y = 0; y<segmentIDMap[x].length; y++) {
                if(segmentIDMap[x][y]==id) {
                    newDistance = Math.sqrt((y-posY)*(y-posY) + (x-posX)*(x-posX));
                    if(newDistance<distance){
                        distance=newDistance;
                    }
                }
            }
        }
        //distance = sqrt((y2 - y1) * (y2 - y1) + (x2 - x1) * (x2 - x1))
        return distance;
    }

    public static void printWeights(){
        for(int i = 0; i<imagesWeights.length;i++){
            System.out.println(imagesWeights[i]);
        }
    }

    public static void createDirectories(String[] directories){//example of a usable string: /subfolder/subfolder2
        for(int i = 0;i<directories.length;i++){
            try {
                new File(directories[i]).mkdirs();
            }catch(Exception e){
                e.printStackTrace();
            }

        }
    }

    public static void incrementWeight(int i){
        imagesWeights[i] = imagesWeights[i]*weightIncreaseFactor;
    }

    public static void progressWeightDecay(){
        for(int x = 0; x<10;x++){
            decrementWeights();
            printWeights();
        }
    }

    public static void decrementWeights(){
        float newWeight = 1;

        for(int i = 0;i<imagesWeights.length;i++){
            newWeight = ((imagesWeights[i]-1)/weightDecreaseFactor)+1;
            imagesWeights[i]=newWeight;
        }
    }

    public static ArrayList<File> getFiles(File folder, String ftype1, String ftype2){
        ArrayList<File> files = new ArrayList<File>();
        for(File file : folder.listFiles()){
            if(file.getName().endsWith(ftype1) || file.getName().endsWith(ftype2)){
                files.add(file);
            }
        }
        return files;
    }

    public static void testIterationCalc(int resultWidth, int resultHeight, int segmentWidth, int segmentHeight){
        int widthIterationsNeeded = resultWidth/segmentWidth;
        int heightIterationsNeeded = resultHeight/segmentHeight;
        int patchWidth = (resultWidth-(resultWidth%widthIterationsNeeded))/widthIterationsNeeded;
        int patchHeight = (resultHeight-(resultHeight%heightIterationsNeeded))/heightIterationsNeeded;
        int totalIterationsNeeded = widthIterationsNeeded*heightIterationsNeeded;
        System.out.println("Width iterations needed:"+widthIterationsNeeded);
        System.out.println("Height iterations needed:"+heightIterationsNeeded);
        System.out.println("Patch width needed:"+patchWidth);
        System.out.println("Patch height needed:"+patchHeight);
    }

}
