<?php
    // Set target directory to store the file.
    session_start();
    $target_dir = "notesFiles/subjectFolders/" . $_POST['subject'] ."/";// produces "/notesFiles/subjectFolders/SUBJ/"

    //$target_dir = realpath($target_dir);

    // Construct absolute path for the target file. 
       // Construct absolute path for the target file. 
    $t = time();
    $target_file = $target_dir . $_SESSION['username'] . "-" . date("Y-m-d",$t)."-". $t . basename($_FILES['fileToUpload']['name']);

    // 1 === Upload is successful
    $uploadOk = 1;

    // Other information needed for database.
    $fileType = (string) strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $posts_filePath = (string) basename($_FILES['fileToUpload']['name']);
    $subject = (string) $_POST['subject'];
    $classNumber = htmlspecialchars($_POST['classNumber']);

    // Connect to the database.
    $user = 'root';
    $pass = '';
    $db = 'notepassuserbase';
    $db = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");
    $username = $_SESSION['username'];
    $authorID = mysqli_query($db, "SELECT * FROM users WHERE username='$username';");
    $row = $authorID->fetch_assoc();
    $authorID = $row['ID'];
    //If class notes go to doesn't exist in db yet, add it.
    $sql = "SELECT * FROM classes WHERE subject='$subject' AND classNumber='$classNumber';";
    $result = mysqli_query($db,$sql);
    if (mysqli_num_rows($result) == 0) {
        $sql = "INSERT INTO classes (subject,classNumber)
                         VALUES('$subject','$classNumber');";
    }else{echo "subject exists";}
    // Add the file to the database.
    $insert = mysqli_query($db, "INSERT INTO posts (authorID, rating, filePath, fileType, subject, classNumber)
                                 VALUES('$authorID',0,'$target_file','$fileType','$subject','$classNumber');");
    
    // Fail upload: File already exists in the file-structure.
    if(file_exists($target_file)){
        echo "This note already exists.";
        $uploadOk = 0;
    }
 
    if($uploadOk == 0){
        echo "Error uploading file.";
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], getcwd()."/".$target_file)) {
            if($insert){
                $db->close();
                header("location:../notepass/myNotes.php");
                exit();
            } else echo "Error uploading to the database.";
        }
    }
?>