<?php
   session_start();
  $user = 'root';
  $pass = '';
  $db = 'notepassuserbase';

  $db = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");
   if($_SESSION['login']==TRUE && isset($_SESSION['username'])){

   }else{
      header("location: index.html");
      exit();
   }
   $username = $_SESSION['username'];
   $postID = $_GET['postID'];
   $sql = "SELECT * FROM posts WHERE ID = $postID;";
   $result = mysqli_query($db,$sql);
   $post = $result->fetch_assoc();
   $fileType = $post['fileType'];
   $fileURL = $post['filePath'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>
   Note Viewer
</title>

<!--<link rel="stylesheet" href="css/noteViewerStyles.css">-->


</head>
<body>


<div class="divContainer">
  <div class="divChild", id="title">
     <p><a href="home.php", id="whiteBGLink">Home</a></p>
  </div>
  <div class="divChild">
   <p><a href="myNotes.php">My Notes</a></p>

  <div class="divChild", id="stacked">
   <p><a href="editAccount.php">My Account</a></p>
  </div>

  </div>

  <div id="bannerFooterContainer">
    
  </div>
  

</div><!--End of sidebar content-->


<div class="contentWindow">
    <div class="searchBar">

     <form action="classSearch.php" method="GET">
     
        <label>Search for a class:</label>
        <input type="text" name="classID">
        <input type="submit" name ="submit" value="submit" class="btn z-depth-0">
     
   </form>
   </div>
   <!--<div id="pdfContainer">-->
      <iframe src=<?php echo getcwd() . $fileURL ?>></iframe>
   
   <div class="ratingWindow">
      <h2>Are these notes helpful?</h1>
      <div class="ratingOption">
         <p><a href="upvote.php?postID=41">Yes!</a></p>
      </div>
      <div class="ratingOption", id="stacked2">
         <p><a href="downvote.php?postID=41">Not really.</a></p>
      </div>
   </div>
</div>

   

</body>
</html>
