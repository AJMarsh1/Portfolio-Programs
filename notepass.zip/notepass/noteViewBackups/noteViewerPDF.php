<?php
   session_start();
  $user = 'root';
  $pass = '';
  $db = 'notepassuserbase';

  $db = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");
   if($_SESSION['login']==TRUE && isset($_SESSION['username'])){

   }else{
      header("location: index.html");
      exit();
   }
   $username = $_SESSION['username'];
   $postID = $_GET['postID'];
   $sql = "SELECT * FROM posts WHERE ID = $postID;";
   $result = mysqli_query($db,$sql);
   $post = $result->fetch_assoc();
   echo $post;
   $fileType = $post['fileType'];
   $fileURL = $post['filePath'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>
   Note Viewer
</title>

<!--<link rel="stylesheet" href="css/noteViewerStyles.css">-->


</head>
<body>


<div class="divContainer">
  <div class="divChild", id="title">
     <p><a href="home.php", id="whiteBGLink">Home</a></p>
  </div>
  <div class="divChild">
   <p><a href="myNotes.php">My Notes</a></p>

  <div class="divChild", id="stacked">
   <p><a href="editAccount.php">My Account</a></p>
  </div>

  </div>

  <div id="bannerFooterContainer">
    
  </div>
  

</div><!--End of sidebar content-->


<div class="contentWindow">
    <div class="searchBar">

     <form action="classSearch.php" method="GET">
     
        <label>Search for a class:</label>
        <input type="text" name="classID">
        <input type="submit" name ="submit" value="submit" class="btn z-depth-0">
     
   </form>
   </div>
   <!--<div id="pdfContainer">-->
   <a target="_blank" href="C:\Users\Josiah\xxamp\htdocs\notepass/notesFiles/subjectFolders/AAEC/Josiah-2021-12-14-1639440173samplePDF.pdf" title="">
     <iframe src="C:\Users\Josiah\xxamp\htdocs\notepass/notesFiles/subjectFolders/AAEC/Josiah-2021-12-14-1639440173samplePDF.pdf" type="application/pdf" width=80% height=100%></iframe>
<!--"C:\Users\Josiah\xxamp\htdocs\notepass/notesFiles/subjectFolders/AAEC/Josiah-2021-12-14-1639440173samplePDF.pdf"-->
   <!--<?php echo getcwd() . $fileURL;?>-->
   <div class="ratingWindow">
      <h2>Are these notes helpful?</h1>
      <div class="ratingOption">
         <p><a href="upvote.php?postID="<?php echo $postID;?>>Yes!</a></p>
      </div>
      <div class="ratingOption", id="stacked2">
         <p><a href="downvote.php?postID="<?php echo $postID;?>>Not really.</a></p>
      </div>
   </div>
</div>

   

</body>
</html>
