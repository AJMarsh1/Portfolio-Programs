SET @old_autocommit=@@autocommit;

/*create the database and select it for use*/
DROP DATABASE IF EXISTS `notepassuserbase`;
CREATE DATABASE `notepassuserbase` DEFAULT CHARACTER SET utf8mb4;
USE `notepassuserbase`;


/*Table structure for table `users`*/
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `username` char(32) NOT NULL DEFAULT '',
  `email` char(32) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `authoredPostIDs` char(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`)
) DEFAULT CHARSET=utf8mb4;

/*Initialize a basic user account*/
set autocommit=0;
INSERT INTO `users` VALUES (1,'Josiah','theflyingpenguin@bellsouth.net','password','');
commit;

/*Table structure for table `posts`*/
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `authorID` int NOT NULL DEFAULT 0,
  `rating` int NOT NULL DEFAULT 0,
  `filePath` char(128) NOT NULL DEFAULT '',
  `fileType` char(8) NOT NULL DEFAULT '',/*'pdf','docx', etc.*/
  `subject` char(8) NOT NULL DEFAULT '',/*example: CSCI*/
  `classNumber` int(4) NOT NULL DEFAULT 0,/*example: 4200*/
  PRIMARY KEY (`ID`)
) DEFAULT CHARSET=utf8mb4;

/*Table structure for table `classes`*/
DROP TABLE IF EXISTS `classes`;
CREATE TABLE `classes` (
  `subject` char(4) NOT NULL DEFAULT '',
  `classNumber` int(4) NOT NULL DEFAULT 0
) DEFAULT CHARSET=utf8mb4;

/*Initialize a basic post*/
set autocommit=0;
INSERT INTO users (ID,username,email,password,authoredPostIDs) VALUES(NULL,'Josiah','theflyingpenguin@bellsouth.net','password','');
INSERT INTO classes (subject,classNumber) VALUES('CSCI','1302');
INSERT INTO posts (ID,authorID,rating,filePath,fileType,subject,classNumber) VALUES(NULL,'Josiah','99','none','none','CSCI','1302');
commit;


SET autocommit=@old_autocommit;