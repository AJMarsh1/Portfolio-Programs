This was a group project from my web programming class.

It is nowhere near my best work, as it was my first website I ever built. I did about 70% of the work
on this particular project, with the other group members pitching in at some key areas in the last few days.

The code is generally unorganized, and some pages are not well designed for scaling. However, it was
a lot of work and I learned a lot doing it, particularly around basic HTML/CSS, mySQL, and server file
management. I also learned a good amount about UI/UX, and think the website is user friendly with the
exception of the search functionality, which I did a much better job of implementing a year later in the
cinema project.

If I redid this project, I would probably change more than I would keep. The file structure is pretty
well done, and not all of the mySQL structuring is bad, but other than that and some page designs,
I would probably scrap the rest of what I did and start over.