<!DOCTYPE html>
<?php
	$user = 'root';
	$pass = '';
	$db = 'notepassuserbase';
	$db = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");
	echo "Connected successfully";

	session_start();
	$username = $_SESSION['username'];
	$email = $_SESSION['email'];
	$message= '';
	
	//when user chooses to update email
	if(isset($_POST['updateEmail'])){
		$emailIn = htmlspecialchars($_POST['email']);
		$validInput = true;
	
		//checks for blank input
		if(empty($emailIn)){
			$message= 'Email cannot be blank. Please try again.';
			$validInput = false;
		}
		
		//checks for duplicate input
		$emailCheck = $db->prepare("SELECT email
									FROM users 
									WHERE email = '$emailIn'");
		$emailCheck->execute();
		$check = $emailCheck->fetch();
		if($check){
			$message= 'This email already exists. Please try again. ';
			$validInput = false;
		}
		//updates database
		if($validInput == true){
			$query = "UPDATE users
						SET email = '$emailIn' 
						WHERE username = '$username'";
			if ($db->query($query) === TRUE) {
				$db->close();
				$message= 'Email updated successfully';
			} 
			else {
				$db->close();
				echo 'Error updating email in database.';
				exit();
			}
		}
		//input is invalid
		else{
		}
	}
	
	
	//When user chooses to update username
	if(isset($_POST['updateUsername'])){
		$usernameIn = htmlspecialchars($_POST['username']);
		$validInput = true;
		
		//checks for blank input
		if(empty($usernameIn)){
			$message= 'Username cannot be blank. Please try again.';
			$validInput = false;
		}
		
		//checks for duplicate input
		$userCheck = $db->prepare("SELECT username
									FROM users 
									WHERE username = '$usernameIn'");
		$userCheck->execute();
		$check = $userCheck->fetch();
		if($check){
			$message='This username already exists. Please try again.';
			$validInput = false;
		}
		
		//updates database
		if($validInput == true){
			$query = "UPDATE users 
						SET username = '$usernameIn' 
						WHERE email = '$email'";
			if ($db->query($query) === TRUE) {
				$_SESSION['username'] = $usernameIn;
				$message= 'Username updated successfully';
				$db->close();
			} 
			else {
				$db->close();
				echo 'Error updating username in database.';
				exit();
			}
		}
		//input is invalid
		else{
		}
	}
	
	//When user chooses to update password
	if(isset($_POST['updatePassword'])){
		$passwordIn = htmlspecialchars($_POST['password']);
		$confPasswordIn = htmlspecialchars($_POST['confirmPassword']);
		$validInput = true;
		
		//checks for blank input
		if(empty($passwordIn)|| empty($confPasswordIn)){
			$message= 'Password cannot be blank. Please try again.';
			$validInput = false;
		}
		
		//checks for invalid passwords
		if($passwordIn != $confPasswordIn){
			$message= 'Passwords do not match. Please try again.';
			$validInput = false;
		}
		
		//updates database
		if($validInput == true){		
			$query = "UPDATE users 
						SET password = '$passwordIn' 
						WHERE username = '$username'";
			if ($db->query($query) === TRUE) {
				$db->close();
				$message= 'Password updated successfully';
			} 
			else {
				$db->close();
				echo 'Error updating password.';
				exit();
			}
		}
		//input is invalid
		else{
		}
	}
?>

<html lang="en">
<head>
<title>
   Edit Account
</title>

<link rel="stylesheet" href="css/loginPage.css">

</head>
<body>


<div class="backgroundDiv1">
  <div class="confirmContainer">

   <h2><?php echo $message;?> </h2>
   <h1><a href="editAccount.php">Return to Account</a></h1>

  </div>

</div>

</body>
</html>