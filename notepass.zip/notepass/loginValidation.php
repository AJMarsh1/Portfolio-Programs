 <?php
	$user = 'root';
	$pass = '';
	$db = 'notepassuserbase';
  
	$db = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");

	
	if(isset($_POST['submit'])){
		$email = htmlspecialchars($_POST['email']);
		$password = htmlspecialchars($_POST['password']);
		$username = " ";
		$userID = 0;
		$validInput = true;
		$message ='';
	
		//checks if email is empty
		if(empty($email)){
			$message = 'Email cannot be empty. Please try again.';
			$validInput = false;
		}
		//checks if password is empty
		if(empty($password)){
			$message = 'Password cannot be empty. Please try again.';
			$validInput = false;
		}
     
		session_start(); 
		$_SESSION['login'] = TRUE;
		if(isset($_SESSION['sessionNum'])){
			$_SESSION['sessionNum'] += 1;
		}	
		else{
			$_SESSION['sessionNum'] = 1;
		}
		
		//query database for user information
		if($validInput == true){
			$query = "SELECT username, email, password 
						FROM users 
						WHERE email = ? AND password = ?";
			$statement = $db->prepare($query); 
			$statement->bind_param('ss', $email, $password);
			$statement->execute(); 
			$statement->bind_result($username, $email, $password);
			$statement->store_result();
			
			//if rows==1, a user with the matching information exists
			if($statement->num_rows == 1) {	
				if($statement->fetch()){
					$_SESSION['username'] = $username;
					$_SESSION['email'] = $email;
					$db->close();
					header("Location: home.php");
					exit();	
				}
			}
			//rows==0, so no user exists for that combination.
			else {
				$message = 'Wrong Email/Password Combination. Please try Again.';
				$db->close();
			}
		}
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>
   Login
</title>

<link rel="stylesheet" href="css/loginPage.css">


</head>
<body>


<div class="backgroundDiv1">
  <div class="confirmContainer">

   <h2><?php echo $message;?></h2>
   <h1><a href="index.html">Return to Login</a></h1>

  </div>

  

</div><!--End of sidebar content-->

</body>
</html>
