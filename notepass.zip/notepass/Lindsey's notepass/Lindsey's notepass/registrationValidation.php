<!DOCTYPE html>

<!--If the form has been submitted...-->
<?php
	$user = 'root';
	$pass = '';
	$db = 'notepassuserbase';
  
	$db = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");

	if(isset($_POST['submit'])){
		$email = htmlspecialchars($_POST['email']);
		$password = htmlspecialchars($_POST['password']);
		$confirmPassword = htmlspecialchars($_POST['confirmPassword']);
		$username = htmlspecialchars($_POST['username']);
		$validInput = true;
		$message='';
		$registered = false;
		
		//check if email is empty
		if(empty($email)){
			$message.= 'Email is required. Please try again. ';
			$validInput = false;
		}
		//check if username is empty
		if(empty($username)){
			$message.= 'Username is required. Please try again. ';
			$validInput = false;
		} 
		
		//check if email or username already exists
		$userCheck = $db->prepare("SELECT email, username 
									FROM users 
									WHERE username = '$username' OR email = '$email'");
		$userCheck->execute();
		$user = $userCheck->fetch();
		if($user){
			$message.= 'This username or email already exists. Please try again. ';
			$validInput = false;
		}
	
		//check if password is empty
		if(empty($password)){
			$message.= 'Password is required. Please try again.';
			$validInput = false;
		}
		//check if passwords match
		if($password != $confirmPassword){
			$message.= 'Passwords do not match. Please try again.';
			$validInput = false;
		}

		if($validInput == true){
			//Prepared statement, parameter binding, and execution
			$null = 0;
			$statement = $db->prepare("INSERT INTO users VALUES (?,?,?,?,?)");
			$statement->bind_param("issss",$null,$username,$email,$password,$null);
			$statement->execute();

			//Check that account was created
			$usernameCheck = mysqli_query($db,"SELECT * FROM users WHERE username ='".$username."';");
			if (empty($usernameCheck)) {
				echo "Error creating account: " . $db->error;
			} 
			else {
				$registered = true;
				
			}
			$db->close();
		}
		else{
			$db->close();
			
		}
	}
 
?>

<html lang="en">
<head>
<title>
   Register
</title>

<link rel="stylesheet" href="css/loginPage.css">


</head>
<body>


<div class="backgroundDiv1">
  <div class="confirmContainer">
	<!--HTML content depends on if user is registered or not-->
	<?php if($registered){?>
		 <h2>Registered as <?php echo $username ?> with email <?php echo $email ?> </h2>
		 <h1><a href="index.html">Go to Login</a></h1>
	<?php } else { ?>
		<h2><?php echo $message;?></h2>
		<h1><a href="registerPage.html">Return to Registration</a></h1>
	<?php } ?>

  </div>

   

</div>

</body>
</html>

