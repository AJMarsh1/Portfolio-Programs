<?php
	session_start();
	$user = 'root';
	$pass = '';
	$db = 'notepassuserbase';
	$db = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");
  
    if(!isset($_SESSION['username'])) {
        header("Location: home.php"); 
    }
	
	$username = $_SESSION['username'];
	
	
	//retrieve user information from database to display in form
    $query = "SELECT username, email, password FROM users WHERE username = '$username'";
    $statement = $db->prepare($query);
	$statement->execute();
	$statement->bind_result($username, $email, $password);
	$statement->store_result();
    $user = $statement->fetch();
	$db->close();
	
?>

<!DOCTYPE html>
<html lang="en">

<head>
<title>
   Notepass
</title>
	<link rel="stylesheet" href="css/accountStyle.css">
</head>

<body>

<!-- sidebar content-->
<div class="divContainer">
	<div class="divChild", id="title">
		<a href="home.php"><img src="img/NotePass.jpg" alt="NotePass logo" class="logo" width="150" height="95"></a>
	</div>
	<div class="divChild">
		<p><a href="test2.html">My Notes</a></p>
		<div class="divChild", id="stacked">
			<p><a href="editAccount.html">My Account</a></p>
		</div>
	</div>

	<div id="bannerFooterContainer">

	</div>
  

</div><!--End of sidebar content-->


<!-- Account Information container-->
<div class="contentWindow">
 	<div class="accountContainer">
		<h1>Hi, <?php echo $username;?>!</h1>
		<hr class="mainBorder"/>
		
		<h2>Account Information</h2>
		<form class="white" action="editAccountValidation.php" method="POST">
		
			<div class="stacked">
				<label>Email:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
				<input type="email" name="email" value= "<?php echo $email;?>">
				<br><br>
				
				<div class="stacked">
					<input type="submit" name ="updateEmail" value="update email" class="btn z-depth-0">
					<br><br><hr class="smallBorder" /><br>
					
					<div class="stacked">		
						<label>Username:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
						<input type="text" name="username" value="<?php echo $username;?>">
						<br><br>
						
						<div class="stacked">
							<input type="submit" name ="updateUsername" value="update username" class="btn z-depth-0">
							<br><br>	<hr class="smallBorder"/>	
							
							<div class="stacked">
								<h3>Change Password:</h3>
								<label>Password:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
								<input type="password" name="password" placeholder="password">
								<br><br>
								
								<div class="stacked">
									<label>Confirm Password:&nbsp&nbsp</label>
									<input type="password" name="confirmPassword" placeholder="password">
									<br><br>	
									
									<div class="stacked">
										<input type="submit" name ="updatePassword" value="update password" class="btn z-depth-0">
									</div>
								</div>
							</div>
						</div>	
					</div>
				</div>
			</div>
		</form>
	</div>   
 </div>

</body>
</html>