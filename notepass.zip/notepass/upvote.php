<?php

  session_start();
  $user = 'root';
  $pass = '';
  $db = 'notepassuserbase';

  $db = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");
   if($_SESSION['login']==TRUE && isset($_SESSION['username'])){

   }else{
      header("location: index.html");
      exit();
   }
   $username = $_SESSION['username'];
   $postID = $_GET['postID'];
   $sql = "SELECT * FROM posts WHERE ID = $postID;";
   $result = mysqli_query($db,$sql);
   $post = $result->fetch_assoc();
   $fileType = $post['fileType'];
   $rating = $post['rating'];
   $newRating = $rating + 1;

   $sql = "UPDATE posts
	SET rating = $newRating
	WHERE ID = $postID;";
	mysqli_query($db,$sql);
   if($fileType="pdf"){
   	header("location: noteViewerPDF.php?postID=$postID");
   }else{
   	header("location: noteViewerDOC.php?postID=$postID");
   }



?>