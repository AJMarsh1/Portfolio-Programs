<?php
   session_start();
   if($_SESSION['login']==TRUE && isset($_SESSION['username'])){

   }else{
      header("location: index.html");
      exit();
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>
   Home
</title>

<link rel="stylesheet" href="css/menuStyles.css">


</head>
<body>


<div class="divContainer">
  <div class="divChild", id="title">
     <p><a href="test2.html", id="whiteBGLink">Home</a></p>
  </div>
  <div class="divChild">
   <p><a href="test2.html">My Notes</a></p>

  <div class="divChild", id="stacked">
   <p><a href="test2.html">My Account</a></p>
  </div>

  </div>

  <div id="bannerFooterContainer">
    
  </div>
  

</div><!--End of sidebar content-->


<div class="contentWindow">
    <div class="searchBar">

     <form action="classSearch.php" method="GET">
     
        <label>Search for a class:</label>
        <input type="text" name="classID">
        <input type="submit" name ="submit" value="submit" class="btn z-depth-0">
     
   </form>
   </div>
   
</div>

   

</body>
</html>