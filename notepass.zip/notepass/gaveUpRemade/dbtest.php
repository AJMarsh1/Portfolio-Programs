<?php
  $user = 'root';
  $pass = '';
  $db = 'notepassuserbase';
  
  $db = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");
  echo "Connected successfully";


  $sql = 'CREATE TABLE users (
  username VARCHAR(30) PRIMARY KEY NOT NULL,
  password VARCHAR(30) NOT NULL,
  email VARCHAR(50) NOT NULL,
  reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  )';

  if ($db->query($sql) === TRUE) {
  echo "Table users created successfully";
} else {
  echo "Error creating table: " . $db->error;
}

$sql = "INSERT INTO users (username, password, email, reg_date)
      VALUES ('ajosiahmarsh', 'badpassword', 'ajm36242@uga.edu', CURRENT_TIMESTAMP())";
if ($db->query($sql) === TRUE) {
  echo "User entry created successfully";
} else {
  echo "Error creating user row: " . $db->error;
}

$sql = "SELECT username, email, password FROM users";
$result = $db->query($sql);
echo "Table:";
if ($result->num_rows > 0) {
    // output data of each row

    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["username"]. " - Name: " . $row["email"]. " " . $row["password"]. "<br>";
    }
} else {
    echo "0 results";
}

$db->close();

?>