<?php
   session_start();
   if($_SESSION['login']==TRUE){

   }else{
      header("location: index.html");
      exit();
   }

   // Connect to database.
   $user = 'root';
   $pass = '';
   $db = 'notepassuserbase';
   $db = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");

   // Get username from session.
   $user = $_SESSION['username'];

   // Construct query for recieving user's notes from database.
   $sql = 
        "SELECT users.username, posts.subject, posts.filePath
        FROM users
        INNER JOIN posts
        ON users.ID = posts.authorID
        WHERE users.username = '$user' 
        ORDER BY posts.subject;";

   // Query and close databse.
   $result = $db->query($sql);
   $db->close();
?>

<html>
    <head>
        <title>
            My Notes
        </title>
        <style>
            /*body {
                font-family: arial, sans-serif;
            }

            table {
                border-collapse: collapse;
                width: 100%;
            }

            td, th {
                border: 1px solid #dddddd;
                text-align: left;
                padding: 8px;
            }

            tr:nth-child(even) {
                background-color: #dddddd;
            }*/
        </style>

        <!-- BS5 -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
        <!-- BS5 -->
    </head>

    <body>
        <!--Navbar-->
        <nav class="navbar navbar-expand-sm navbar-dark" style = "background-color:red;">
            <div class="container-fluid">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="addNewNotes.php">Add New Notes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="myNotes.php">My Notes</a>
                    </li>
                </ul>
            </div>
        </nav>
        <!--Navbar-->

        <div class="container-fluid mt-3">

        <h1>My Notes</h1>

        <table class="table table-secondary">
            <thead><tr>
                <th>Username</th>
                <th>Subject</th>
                <th>Note</th>
                <th>Delete</th>
            </tr></thead>
            
            <!--DISPLAY ROWS-->
            <?php
                if($result->num_rows > 0){
                    while($row = $result->fetch_assoc()){
            ?>
                        <tr>
                        <td> <?php echo $row["username"];?> </td>
                        <td> <?php echo $row["subject"];?> </td>
                        <td> <a href="<?php echo getcwd().$row["filePath"];
                        //echo "../notesFiles/subjectFolders/".$row["subject"]."/".$row["filePath"];
                        ?>"> <?php 
                        echo $row["filePath"];?> </a></td>
                        <td> <a href="delete.php?file=<?php echo $row['filePath'];?>">Delete</a></td>
                        </tr>
            <?php
                    } //end while
                } //end if
            ?>
            <!--END DISPLAY ROWS-->
        </table>

        <!--toast-->
            <?php if(isset($_GET['debug'])) { ?>
            <div class="toast show">
                <div class="toast-header">
                    Note deleted
                    <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
                </div>
                <div class="toast-body">
                    <?php echo $_GET['debug'];?>
                </div>
            </div>
            <?php } ?>
        <!--toast-->
        </div>
    </body>
</html>