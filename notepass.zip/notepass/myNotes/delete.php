<?php
   // Access the db.
   $user = 'root';
   $pass = '';
   $db = 'notepassuserbase';
   $db = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");

   // $file is passed to delete.php from myNotes.php.
   // $file contains information about a file including its filePath in the db and its subjectFolders subfolder.
   // $file contents follow the template: 'filePath.pdf@CSCI'.
   $file = $_GET['file'];
   
   // delimit $file using '@'.
   $contents = explode("@", $file);
   
   // $filePath_db is used to delete the file within the db .
   $filePath_db = $contents[0];

   // $target is used to delete the file from its location in htdocs.
   $target = "../notesFiles/subjectFolders/".$contents[1]."/".$contents[0];

   // delete the file from the database.
   $delete = mysqli_query($db, "DELETE FROM posts WHERE filePath = '$filePath_db'");
   if($delete){
        // delete the file from the directory
        $debug_message="$filePath_db deleted!";
        if(!unlink($target)) {
            $debug_message = "Error deleting $filePath_db from $target.".$contents[1];
        }   
        $db->close();
        header("location:myNotes.php?debug=$debug_message");
        exit();
   } else {
       echo "Error deleting $file";
   }
?>